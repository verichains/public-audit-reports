# (Changed) function ExecutorWithTimelock.executeTransaction(address,uint256,string,bytes,uint256,bool)
✓ Document
✘ Code
```solidity
@@ -26,7 +26,7 @@
     bool success;
     bytes memory resultData;
     if (withDelegatecall) {
-      require(msg.value >= value, 'NOT_ENOUGH_MSG_VALUE');
+      require(msg.value >= value, "NOT_ENOUGH_MSG_VALUE");
       // solium-disable-next-line security/no-call-value
       (success, resultData) = target.delegatecall(callData);
     } else {
```
# (Match) contract SafeMath inherits
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.setDelay(uint256)
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.<receive>()
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock._validateDelay(uint256)
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.isProposalOverGracePeriod(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.isActionQueued(bytes32)
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.getDelay()
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.getPendingAdmin()
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.getAdmin()
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.cancelTransaction(address,uint256,string,bytes,uint256,bool)
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.queueTransaction(address,uint256,string,bytes,uint256,bool)
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.setPendingAdmin(address)
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.acceptAdmin()
✓ Document
✓ Code
# (Match) modifier ExecutorWithTimelock.onlyPendingAdmin
✓ Document
✓ Code
# (Match) function IProposalValidator.validateCreatorOfProposal(contract IAaveGovernanceV2,address,uint256)
✓ Document
✓ Code
# (Match) modifier ExecutorWithTimelock.onlyTimelock
✓ Document
✓ Code
# (Match) modifier ExecutorWithTimelock.onlyAdmin
✓ Document
✓ Code
# (Match) function ExecutorWithTimelock.<constructor>(address,uint256,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) variable ExecutorWithTimelock._queuedTransactions
✓ Document
✓ Code
# (Match) variable ExecutorWithTimelock._delay
✓ Document
✓ Code
# (Match) variable ExecutorWithTimelock._pendingAdmin
✓ Document
✓ Code
# (Match) variable ExecutorWithTimelock._admin
✓ Document
✓ Code
# (Match) variable ExecutorWithTimelock.MAXIMUM_DELAY
✓ Document
✓ Code
# (Match) variable ExecutorWithTimelock.MINIMUM_DELAY
✓ Document
✓ Code
# (Match) variable ExecutorWithTimelock.GRACE_PERIOD
✓ Document
✓ Code
# (Match) ExecutorWithTimelock(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) contract ExecutorWithTimelock inherits
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.cancelTransaction(address,uint256,string,bytes,uint256,bool)
✓ Document
✓ Code
# (Match) contract IProposalValidator inherits
✓ Document
✓ Code
# (Match) function IProposalValidator.validateProposalCancellation(contract IAaveGovernanceV2,address,uint256)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.queueTransaction(address,uint256,string,bytes,uint256,bool)
✓ Document
✓ Code
# (Match) variable ProposalValidator.VOTE_DIFFERENTIAL
✓ Document
✓ Code
# (Match) contract Executor inherits
✓ Document
✓ Code
# (Match) function ProposalValidator.isVoteDifferentialValid(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function ProposalValidator.isQuorumValid(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function ProposalValidator.getMinimumVotingPowerNeeded(uint256)
✓ Document
✓ Code
# (Match) function ProposalValidator.isProposalPassed(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function ProposalValidator.getMinimumPropositionPowerNeeded(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function ProposalValidator.isPropositionPowerEnough(contract IAaveGovernanceV2,address,uint256)
✓ Document
✓ Code
# (Match) function ProposalValidator.validateProposalCancellation(contract IAaveGovernanceV2,address,uint256)
✓ Document
✓ Code
# (Match) function ProposalValidator.validateCreatorOfProposal(contract IAaveGovernanceV2,address,uint256)
✓ Document
✓ Code
# (Match) function ProposalValidator.<constructor>(uint256,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) variable ProposalValidator.ONE_HUNDRED_WITH_PRECISION
✓ Document
✓ Code
# (Match) variable ProposalValidator.MINIMUM_QUORUM
✓ Document
✓ Code
# (Match) variable ProposalValidator.VOTING_DURATION
✓ Document
✓ Code
# (Match) function IProposalValidator.isPropositionPowerEnough(contract IAaveGovernanceV2,address,uint256)
✓ Document
✓ Code
# (Match) variable ProposalValidator.PROPOSITION_THRESHOLD
✓ Document
✓ Code
# (Match) ProposalValidator(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) contract ProposalValidator inherits
✓ Document
✓ Code
# (Match) function IProposalValidator.ONE_HUNDRED_WITH_PRECISION()
✓ Document
✓ Code
# (Match) function IProposalValidator.MINIMUM_QUORUM()
✓ Document
✓ Code
# (Match) function IProposalValidator.VOTE_DIFFERENTIAL()
✓ Document
✓ Code
# (Match) function IProposalValidator.VOTING_DURATION()
✓ Document
✓ Code
# (Match) function IProposalValidator.PROPOSITION_THRESHOLD()
✓ Document
✓ Code
# (Match) function IProposalValidator.getMinimumVotingPowerNeeded(uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.isVoteDifferentialValid(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.isQuorumValid(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.isProposalPassed(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.getMinimumPropositionPowerNeeded(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.executeTransaction(address,uint256,string,bytes,uint256,bool)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.MAXIMUM_DELAY()
✓ Document
✓ Code
# (Match) function SafeMath.add(uint256,uint256)
✓ Document
✓ Code
# (Match) struct IAaveGovernanceV2.Vote
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.create(contract IExecutorWithTimelock,address[],uint256[],string[],bytes[],bool[],bytes32)
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ExecutorUnauthorized
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ExecutorAuthorized
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.VotingDelayChanged
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.GovernanceStrategyChanged
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.VoteEmitted
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ProposalExecuted
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ProposalQueued
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ProposalCanceled
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ProposalCreated
✓ Document
✓ Code
# (Match) struct IAaveGovernanceV2.ProposalWithoutVotes
✓ Document
✓ Code
# (Match) struct IAaveGovernanceV2.Proposal
✓ Document
✓ Code
# (Match) enum IAaveGovernanceV2.ProposalState
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.queue(uint256)
✓ Document
✓ Code
# (Match) contract IAaveGovernanceV2 inherits
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getVotingPowerAt(address,uint256)
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getTotalVotingSupplyAt(uint256)
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getTotalPropositionSupplyAt(uint256)
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getPropositionPowerAt(address,uint256)
✓ Document
✓ Code
# (Match) contract IGovernanceStrategy inherits
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.mul(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.cancel(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.execute(uint256)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.MINIMUM_DELAY()
✓ Document
✓ Code
# (Match) contract IExecutorWithTimelock inherits
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.GRACE_PERIOD()
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.isProposalOverGracePeriod(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.isActionQueued(bytes32)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.getDelay()
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.getPendingAdmin()
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.getAdmin()
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.ExecutedAction
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.CancelledAction
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.QueuedAction
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.NewDelay
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.NewAdmin
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.NewPendingAdmin
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getProposalState(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.submitVote(uint256,bool)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getVoteOnProposal(uint256,address)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getProposalById(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getProposalsCount()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getGuardian()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.isExecutorAuthorized(address)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getVotingDelay()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getGovernanceStrategy()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.__abdicate()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.unauthorizeExecutors(address[])
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.authorizeExecutors(address[])
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.setVotingDelay(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.setGovernanceStrategy(address)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.submitVoteBySignature(uint256,bool,uint8,bytes32,bytes32)
✓ Document
✓ Code
# (Match) function Executor.<constructor>(address,uint256,uint256,uint256,uint256,uint256,uint256,uint256,uint256)
✓ Document
✓ Code

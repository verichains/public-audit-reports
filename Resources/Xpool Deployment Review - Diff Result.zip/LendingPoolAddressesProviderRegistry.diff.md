# (Match) contract Context inherits
✓ Document
✓ Code
# (Match) variable Errors.RL_STABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASH_LOAN_EXECUTOR_RETURN
✓ Document
✓ Code
# (Match) variable Errors.LP_NO_MORE_RESERVES_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.LP_IS_PAUSED
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_MUST_BE_AN_ATOKEN
✓ Document
✓ Code
# (Match) variable Errors.LP_REENTRANCY_NOT_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_EQUAL_ASSETS_TO_SWAP
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_COLLATERAL_SWAP
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_BURN_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_REPAY_WITH_COLLATERAL
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_MINT_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.MATH_DIVISION_BY_ZERO
✓ Document
✓ Code
# (Match) variable Errors.MATH_ADDITION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.MATH_MULTIPLICATION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASHLOAN_MODE
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NO_ERRORS
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NOT_ENOUGH_LIQUIDITY_TO_LIQUIDATE
✓ Document
✓ Code
# (Match) variable Errors.LPCM_SPECIFIED_CURRENCY_NOT_BORROWED_BY_USER
✓ Document
✓ Code
# (Match) variable Errors.LPCM_COLLATERAL_CANNOT_BE_LIQUIDATED
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LTV
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_BONUS
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_PROVIDER_NOT_REGISTERED
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProviderRegistry.getAddressesProvidersList()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry.getAddressesProviderIdByAddress(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry.unregisterAddressesProvider(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry.registerAddressesProvider(address,uint256)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry.getAddressesProvidersList()
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProviderRegistry._addressesProvidersList
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProviderRegistry._addressesProviders
✓ Document
✓ Code
# (Match) contract LendingPoolAddressesProviderRegistry inherits
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProviderRegistry.unregisterAddressesProvider(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProviderRegistry.registerAddressesProvider(address,uint256)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProviderRegistry.getAddressesProviderIdByAddress(address)
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProviderRegistry.AddressesProviderUnregistered
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_DECIMALS
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProviderRegistry.AddressesProviderRegistered
✓ Document
✓ Code
# (Match) contract ILendingPoolAddressesProviderRegistry inherits
✓ Document
✓ Code
# (Match) enum Errors.CollateralManagerErrors
✓ Document
✓ Code
# (Match) variable Errors.SDT_BURN_EXCEEDS_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.SDT_STABLE_DEBT_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_CONTRACT
✓ Document
✓ Code
# (Match) variable Errors.UL_INVALID_INDEX
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PARAMS_LENGTH
✓ Document
✓ Code
# (Match) variable Errors.VL_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_RESERVE_FACTOR
✓ Document
✓ Code
# (Match) variable Errors.LPCM_HEALTH_FACTOR_NOT_BELOW_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.LPC_CALLER_NOT_EMERGENCY_ADMIN
✓ Document
✓ Code
# (Match) function Context._msgSender()
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_CANNOT_COVER_NEW_BORROW
✓ Document
✓ Code
# (Match) variable Errors.VL_HEALTH_FACTOR_LOWER_THAN_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_BALANCE_IS_0
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_INTEREST_RATE_MODE_SELECTED
✓ Document
✓ Code
# (Match) variable Errors.VL_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) variable Errors.VL_TRANSFER_NOT_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.VL_NOT_ENOUGH_AVAILABLE_USER_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.VL_CURRENT_AVAILABLE_LIQUIDITY_NOT_ENOUGH
✓ Document
✓ Code
# (Match) variable Errors.VL_RESERVE_FROZEN
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_ACTIVE_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.BORROW_ALLOWANCE_NOT_ENOUGH
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_SAME_AS_BORROWING_CURRENCY
✓ Document
✓ Code
# (Match) variable Errors.CALLER_NOT_POOL_ADMIN
✓ Document
✓ Code
# (Match) contract Errors inherits
✓ Document
✓ Code
# (Match) function Ownable.transferOwnership(address)
✓ Document
✓ Code
# (Match) function Ownable.renounceOwnership()
✓ Document
✓ Code
# (Match) modifier Ownable.onlyOwner
✓ Document
✓ Code
# (Match) function Ownable.owner()
✓ Document
✓ Code
# (Match) function Ownable.<constructor>()
✓ Document
✓ Code
# (Match) event Ownable.OwnershipTransferred
✓ Document
✓ Code
# (Match) variable Ownable._owner
✓ Document
✓ Code
# (Match) contract Ownable inherits
✓ Document
✓ Code
# (Match) function Context._msgData()
✓ Document
✓ Code
# (Match) variable Errors.VL_STABLE_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) variable Errors.VL_AMOUNT_BIGGER_THAN_MAX_LOAN_SIZE_STABLE
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_CONFIGURATION
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ATOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_RESERVE_LIQUIDITY_NOT_0
✓ Document
✓ Code
# (Match) variable Errors.RL_RESERVE_ALREADY_INITIALIZED
✓ Document
✓ Code
# (Match) variable Errors.CT_TRANSFER_AMOUNT_NOT_GT_0
✓ Document
✓ Code
# (Match) variable Errors.CT_CANNOT_GIVE_ALLOWANCE_TO_HIMSELF
✓ Document
✓ Code
# (Match) variable Errors.CT_CALLER_MUST_BE_LENDING_POOL
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_NOT_LENDING_POOL_CONFIGURATOR
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_DEBT_OF_SELECTED_TYPE
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PROTOCOL_ACTUAL_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.LP_REQUESTED_AMOUNT_TOO_SMALL
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_LIQUIDITY_TO_BORROW
✓ Document
✓ Code
# (Match) variable Errors.LP_LIQUIDATION_CALL_FAILED
✓ Document
✓ Code
# (Match) variable Errors.LP_INTEREST_RATE_REBALANCE_CONDITIONS_NOT_MET
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_STABLE_BORROW_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.VL_DEPOSIT_ALREADY_IN_USE
✓ Document
✓ Code
# (Match) variable Errors.VL_UNDERLYING_BALANCE_NOT_GREATER_THAN_0
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_VARIABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_STABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_EXPLICIT_AMOUNT_TO_REPAY_ON_BEHALF
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry._addToAddressesProvidersList(address)
✓ Document
✓ Code

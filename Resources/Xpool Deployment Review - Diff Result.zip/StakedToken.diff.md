# (Added) contract StakedAaveV11
```solidity
 @title StakedAave
 @notice StakedToken with AAVE token as staked token
 @author Aave*
```
```solidity
contract StakedAaveV11 is StakedTokenV11
```
# (Added) event StakedTokenV11.NewLockReward
```solidity
event NewLockReward(address indexed lockContract, address indexed receiver);
```
# (Added) function StakedTokenV11.<constructor>(contract IERC20,contract IERC20,uint256,uint256,address,address,uint128,string,string,uint8)
```solidity
constructor(
    IERC20 stakedToken,
    IERC20 rewardToken,
    uint256 cooldownSeconds,
    uint256 unstakeWindow,
    address rewardsVault,
    address emissionManager,
    uint128 distributionDuration,
    string memory name,
    string memory symbol,
    uint8 decimals
  )
    public
    ERC20WithSnapshot(name, symbol, decimals)
    AaveDistributionManager(emissionManager, distributionDuration)
  {
    STAKED_TOKEN = stakedToken;
    REWARD_TOKEN = rewardToken;
    COOLDOWN_SECONDS = cooldownSeconds;
    UNSTAKE_WINDOW = unstakeWindow;
    REWARDS_VAULT = rewardsVault;
  }
```
# (Added) contract ERC20WithSnapshot
```solidity
 @title ERC20WithSnapshot
 @notice ERC20 including snapshots of balances on transfer-related actions
 @author Aave*
```
```solidity
contract ERC20WithSnapshot is ERC20
```
# (Added) ERC20WithSnapshot(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Added) contract TokenTimeLockV2
```solidity
contract TokenTimeLockV2
```
# (Added) TokenTimeLockV2(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Added) function ERC20.<constructor>(string,string,uint8)
```solidity
constructor(
    string memory name,
    string memory symbol,
    uint8 decimals
  ) public {
    _name = name;
    _symbol = symbol;
    _decimals = decimals;
  }
```
# (Added) function ERC20._setName(string)
```solidity
function _setName(string memory newName) internal {
    _name = newName;
  }
```
# (Added) function ERC20._setSymbol(string)
```solidity
function _setSymbol(string memory newSymbol) internal {
    _symbol = newSymbol;
  }
```
# (Added) function ERC20._setDecimals(uint8)
```solidity
function _setDecimals(uint8 newDecimals) internal {
    _decimals = newDecimals;
  }
```
# (Added) contract IERC20Detailed
```solidity
 @dev Interface for ERC20 including metadata*
```
```solidity
interface IERC20Detailed is IERC20
```
# (Removed) contract IGovernancePowerDelegationToken
```solidity
interface IGovernancePowerDelegationToken
```
# (Removed) ERC20(using Address for address)
```solidity
using Address for address;
```
# (Removed) function ERC20.<constructor>(string,string)
```solidity
 @dev Sets the values for {name} and {symbol}, initializes {decimals} with
 a default value of 18.
 To select a different value for {decimals}, use {_setupDecimals}.
 All three of these values are immutable: they can only be set once during
 construction.
```
```solidity
constructor(string memory name, string memory symbol) public {
    _name = name;
    _symbol = symbol;
    _decimals = 18;
  }
```
# (Removed) function ERC20._setupDecimals(uint8)
```solidity
 @dev Sets {decimals} to a value other than the default one of 18.
 WARNING: This function should only be called from the constructor. Most
 applications that interact with token contracts will not expect
 {decimals} to ever change, and may work incorrectly if it does.
```
```solidity
function _setupDecimals(uint8 decimals_) internal {
    _decimals = decimals_;
  }
```
# (Removed) contract GovernancePowerDelegationERC20
```solidity
 @notice implementation of the AAVE token contract
 @author Aave
```
```solidity
abstract contract GovernancePowerDelegationERC20 is ERC20, IGovernancePowerDelegationToken
```
# (Removed) GovernancePowerDelegationERC20(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Removed) contract GovernancePowerWithSnapshot
```solidity
 @title ERC20WithSnapshot
 @notice ERC20 including snapshots of balances on transfer-related actions
 @author Aave*
```
```solidity
abstract contract GovernancePowerWithSnapshot is GovernancePowerDelegationERC20
```
# (Removed) GovernancePowerWithSnapshot(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Removed) variable StakedTokenV11._votingDelegates
```solidity
@dev To see the voting mappings, go to GovernancePowerWithSnapshot.sol
```
```solidity
mapping(address => address) internal _votingDelegates
```
# (Removed) variable StakedTokenV11._propositionPowerSnapshots
```solidity
mapping(address => mapping(uint256 => Snapshot)) internal _propositionPowerSnapshots
```
# (Removed) variable StakedTokenV11._propositionPowerSnapshotsCounts
```solidity
mapping(address => uint256) internal _propositionPowerSnapshotsCounts
```
# (Removed) variable StakedTokenV11._propositionPowerDelegates
```solidity
mapping(address => address) internal _propositionPowerDelegates
```
# (Removed) variable StakedTokenV11.DOMAIN_SEPARATOR
```solidity
bytes32 public DOMAIN_SEPARATOR
```
# (Removed) variable StakedTokenV11.EIP712_REVISION
```solidity
bytes public constant EIP712_REVISION = bytes('1')
```
# (Removed) variable StakedTokenV11.EIP712_DOMAIN
```solidity
bytes32 internal constant EIP712_DOMAIN =
    keccak256('EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)')
```
# (Removed) variable StakedTokenV11.PERMIT_TYPEHASH
```solidity
bytes32 public constant PERMIT_TYPEHASH =
    keccak256('Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)')
```
# (Removed) variable StakedTokenV11._nonces
```solidity
@dev owner => next valid nonce to submit with permit()
```
```solidity
mapping(address => uint256) public _nonces
```
# (Removed) function StakedTokenV11.<constructor>(contract IERC20,contract IERC20,uint256,uint256,address,address,uint128,string,string,uint8,address)
```solidity
constructor(
    IERC20 stakedToken,
    IERC20 rewardToken,
    uint256 cooldownSeconds,
    uint256 unstakeWindow,
    address rewardsVault,
    address emissionManager,
    uint128 distributionDuration,
    string memory name,
    string memory symbol,
    uint8 decimals,
    address governance
  ) public ERC20(name, symbol) AaveDistributionManager(emissionManager, distributionDuration) {
    STAKED_TOKEN = stakedToken;
    REWARD_TOKEN = rewardToken;
    COOLDOWN_SECONDS = cooldownSeconds;
    UNSTAKE_WINDOW = unstakeWindow;
    REWARDS_VAULT = rewardsVault;
    _aaveGovernance = ITransferHook(governance);
    ERC20._setupDecimals(decimals);
  }
```
# (Removed) function StakedTokenV11.permit(address,address,uint256,uint256,uint8,bytes32,bytes32)
```solidity
 @dev implements the permit function as for https://github.com/ethereum/EIPs/blob/8a34d644aacf0f9f8f00815307fd7dd5da07655f/EIPS/eip-2612.md
 @param owner the owner of the funds
 @param spender the spender
 @param value the amount
 @param deadline the deadline timestamp, type(uint256).max for no deadline
 @param v signature param
 @param s signature param
 @param r signature param
```
```solidity
function permit(
    address owner,
    address spender,
    uint256 value,
    uint256 deadline,
    uint8 v,
    bytes32 r,
    bytes32 s
  ) external {
    require(owner != address(0), 'INVALID_OWNER');
    //solium-disable-next-line
    require(block.timestamp <= deadline, 'INVALID_EXPIRATION');
    uint256 currentValidNonce = _nonces[owner];
    bytes32 digest =
      keccak256(
        abi.encodePacked(
          '\x19\x01',
          DOMAIN_SEPARATOR,
          keccak256(abi.encode(PERMIT_TYPEHASH, owner, spender, value, currentValidNonce, deadline))
        )
      );

    require(owner == ecrecover(digest, v, r, s), 'INVALID_SIGNATURE');
    _nonces[owner] = currentValidNonce.add(1);
    _approve(owner, spender, value);
  }
```
# (Removed) function StakedTokenV11._beforeTokenTransfer(address,address,uint256)
```solidity
 @dev Writes a snapshot before any operation involving transfer of value: _transfer, _mint and _burn
 - On _transfer, it writes snapshots for both "from" and "to"
 - On _mint, only for _to
 - On _burn, only for _from
 @param from the from address
 @param to the to address
 @param amount the amount to transfer
```
```solidity
function _beforeTokenTransfer(
    address from,
    address to,
    uint256 amount
  ) internal override {
    address votingFromDelegatee = _votingDelegates[from];
    address votingToDelegatee = _votingDelegates[to];

    if (votingFromDelegatee == address(0)) {
      votingFromDelegatee = from;
    }
    if (votingToDelegatee == address(0)) {
      votingToDelegatee = to;
    }

    _moveDelegatesByType(
      votingFromDelegatee,
      votingToDelegatee,
      amount,
      DelegationType.VOTING_POWER
    );

    address propPowerFromDelegatee = _propositionPowerDelegates[from];
    address propPowerToDelegatee = _propositionPowerDelegates[to];

    if (propPowerFromDelegatee == address(0)) {
      propPowerFromDelegatee = from;
    }
    if (propPowerToDelegatee == address(0)) {
      propPowerToDelegatee = to;
    }

    _moveDelegatesByType(
      propPowerFromDelegatee,
      propPowerToDelegatee,
      amount,
      DelegationType.PROPOSITION_POWER
    );

    // caching the aave governance address to avoid multiple state loads
    ITransferHook aaveGovernance = _aaveGovernance;
    if (aaveGovernance != ITransferHook(0)) {
      aaveGovernance.onTransfer(from, to, amount);
    }
  }
```
# (Removed) function StakedTokenV11._getDelegationDataByType(enum IGovernancePowerDelegationToken.DelegationType)
```solidity
function _getDelegationDataByType(DelegationType delegationType)
    internal
    view
    override
    returns (
      mapping(address => mapping(uint256 => Snapshot)) storage, //snapshots
      mapping(address => uint256) storage, //snapshots count
      mapping(address => address) storage //delegatees list
    )
  {
    if (delegationType == DelegationType.VOTING_POWER) {
      return (_votingSnapshots, _votingSnapshotsCounts, _votingDelegates);
    } else {
      return (
        _propositionPowerSnapshots,
        _propositionPowerSnapshotsCounts,
        _propositionPowerDelegates
      );
    }
  }
```
# (Removed) function StakedTokenV11.delegateByTypeBySig(address,enum IGovernancePowerDelegationToken.DelegationType,uint256,uint256,uint8,bytes32,bytes32)
```solidity
 @dev Delegates power from signatory to `delegatee`
 @param delegatee The address to delegate votes to
 @param delegationType the type of delegation (VOTING_POWER, PROPOSITION_POWER)
 @param nonce The contract state required to match the signature
 @param expiry The time at which to expire the signature
 @param v The recovery byte of the signature
 @param r Half of the ECDSA signature pair
 @param s Half of the ECDSA signature pair
```
```solidity
function delegateByTypeBySig(
    address delegatee,
    DelegationType delegationType,
    uint256 nonce,
    uint256 expiry,
    uint8 v,
    bytes32 r,
    bytes32 s
  ) public {
    bytes32 structHash =
      keccak256(
        abi.encode(DELEGATE_BY_TYPE_TYPEHASH, delegatee, uint256(delegationType), nonce, expiry)
      );
    bytes32 digest = keccak256(abi.encodePacked('\x19\x01', DOMAIN_SEPARATOR, structHash));
    address signatory = ecrecover(digest, v, r, s);
    require(signatory != address(0), 'INVALID_SIGNATURE');
    require(nonce == _nonces[signatory]++, 'INVALID_NONCE');
    require(block.timestamp <= expiry, 'INVALID_EXPIRATION');
    _delegateByType(signatory, delegatee, delegationType);
  }
```
# (Removed) function StakedTokenV11.delegateBySig(address,uint256,uint256,uint8,bytes32,bytes32)
```solidity
 @dev Delegates power from signatory to `delegatee`
 @param delegatee The address to delegate votes to
 @param nonce The contract state required to match the signature
 @param expiry The time at which to expire the signature
 @param v The recovery byte of the signature
 @param r Half of the ECDSA signature pair
 @param s Half of the ECDSA signature pair
```
```solidity
function delegateBySig(
    address delegatee,
    uint256 nonce,
    uint256 expiry,
    uint8 v,
    bytes32 r,
    bytes32 s
  ) public {
    bytes32 structHash = keccak256(abi.encode(DELEGATE_TYPEHASH, delegatee, nonce, expiry));
    bytes32 digest = keccak256(abi.encodePacked('\x19\x01', DOMAIN_SEPARATOR, structHash));
    address signatory = ecrecover(digest, v, r, s);
    require(signatory != address(0), 'INVALID_SIGNATURE');
    require(nonce == _nonces[signatory]++, 'INVALID_NONCE');
    require(block.timestamp <= expiry, 'INVALID_EXPIRATION');
    _delegateByType(signatory, delegatee, DelegationType.VOTING_POWER);
    _delegateByType(signatory, delegatee, DelegationType.PROPOSITION_POWER);
  }
```
# (Changed) function ERC20.symbol()
✘ Document
```solidity
@@ -1,2 +1 @@
- @dev Returns the symbol of the token, usually a shorter version of the
- name.
+ @return the symbol of the token*
```
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function symbol() public view returns (string memory) {
+function symbol() public view override returns (string memory) {
     return _symbol;
   }
```
# (Changed) function ERC20._mint(address,uint256)
✘ Document
```solidity
@@ -1,5 +1 @@
-@dev Creates `amount` tokens and assigns them to `account`, increasing
- the total supply.
- Emits a {Transfer} event with `from` set to the zero address.
- Requirements
- - `to` cannot be the zero address.
+
```
✓ Code
# (Changed) contract ERC20 inherits
✘ Document
```solidity
@@ -1,17 +1,3 @@
- @dev Implementation of the {IERC20} interface.
- This implementation is agnostic to the way tokens are created. This means
- that a supply mechanism has to be added in a derived contract using {_mint}.
- For a generic mechanism see {ERC20PresetMinterPauser}.
- TIP: For a detailed writeup see our guide
- https://forum.zeppelin.solutions/t/how-to-implement-erc20-supply-mechanisms/226[How
- to implement supply mechanisms].
- We have followed general OpenZeppelin guidelines: functions revert instead
- of returning `false` on failure. This behavior is nonetheless conventional
- and does not conflict with the expectations of ERC20 applications.
- Additionally, an {Approval} event is emitted on calls to {transferFrom}.
- This allows applications to reconstruct the allowance for all accounts just
- by listening to said events. Other implementations of the EIP may not emit
- these events, as it isn't required by the specification.
- Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
- functions have been added to mitigate the well-known issues around setting
- allowances. See {IERC20-approve}.
+ @title ERC20
+ @notice Basic ERC20 implementation
+ @author Aave*
```
✘ Code
```solidity
@@ -1 +1 @@
-contract ERC20 is Context, IERC20
+contract ERC20 is Context, IERC20, IERC20Detailed
```
# (Changed) function ERC20._beforeTokenTransfer(address,address,uint256)
✘ Document
```solidity
@@ -1,9 +1 @@
- @dev Hook that is called before any transfer of tokens. This includes
- minting and burning.
- Calling conditions:
- - when `from` and `to` are both non-zero, `amount` of ``from``'s tokens
- will be to transferred to `to`.
- - when `from` is zero, `amount` tokens will be minted for `to`.
- - when `to` is zero, `amount` of ``from``'s tokens will be burned.
- - `from` and `to` are never both zero.
- To learn more about hooks, head to xref:ROOT:extending-contracts.adoc#using-hooks[Using Hooks].
+
```
✓ Code
# (Changed) function ERC20._approve(address,address,uint256)
✘ Document
```solidity
@@ -1,7 +1 @@
- @dev Sets `amount` as the allowance of `spender` over the `owner`s tokens.
- This is internal function is equivalent to `approve`, and can be used to
- e.g. set automatic allowances for certain subsystems, etc.
- Emits an {Approval} event.
- Requirements:
- - `owner` cannot be the zero address.
- - `spender` cannot be the zero address.
+
```
✓ Code
# (Changed) contract StakedTokenV11 inherits
✓ Document
✘ Code
```solidity
@@ -1,5 +1,5 @@
-contract StakedTokenV2Rev3 is
+contract StakedTokenV11 is
   IStakedAave,
-  GovernancePowerWithSnapshot,
+  ERC20WithSnapshot,
   VersionedInitializable,
   AaveDistributionManager
```
# (Changed) function ERC20._burn(address,uint256)
✘ Document
```solidity
@@ -1,6 +1 @@
- @dev Destroys `amount` tokens from `account`, reducing the
- total supply.
- Emits a {Transfer} event with `to` set to the zero address.
- Requirements
- - `account` cannot be the zero address.
- - `account` must have at least `amount` tokens.
+
```
✓ Code
# (Changed) variable ERC20._name
✓ Document
✘ Code
```solidity
@@ -1 +1 @@
-string internal _name
+string private _name
```
# (Changed) variable ERC20._symbol
✓ Document
✘ Code
```solidity
@@ -1 +1 @@
-string internal _symbol
+string private _symbol
```
# (Changed) function ERC20.name()
✘ Document
```solidity
@@ -1 +1 @@
- @dev Returns the name of the token.
+ @return the name of the token*
```
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function name() public view returns (string memory) {
+function name() public view override returns (string memory) {
     return _name;
   }
```
# (Changed) function ERC20.decreaseAllowance(address,uint256)
✘ Document
```solidity
@@ -1,8 +1,4 @@
- @dev Atomically decreases the allowance granted to `spender` by the caller.
- This is an alternative to {approve} that can be used as a mitigation for
- problems described in {IERC20-approve}.
- Emits an {Approval} event indicating the updated allowance.
- Requirements:
- - `spender` cannot be the zero address.
- - `spender` must have allowance for the caller of at least
- `subtractedValue`.
+ @dev decreases the allowance of spender to spend msg.sender tokens
+ @param spender the user allowed to spend on behalf of msg.sender
+ @param subtractedValue the amount being subtracted to the allowance
+ @return true*
```
✓ Code
# (Changed) function ERC20._transfer(address,address,uint256)
✘ Document
```solidity
@@ -1,8 +1 @@
- @dev Moves tokens `amount` from `sender` to `recipient`.
- This is internal function is equivalent to {transfer}, and can be used to
- e.g. implement automatic token fees, slashing mechanisms, etc.
- Emits a {Transfer} event.
- Requirements:
- - `sender` cannot be the zero address.
- - `recipient` cannot be the zero address.
- - `sender` must have a balance of at least `amount`.
+
```
✓ Code
# (Changed) function ERC20.decimals()
✘ Document
```solidity
@@ -1,9 +1 @@
- @dev Returns the number of decimals used to get its user representation.
- For example, if `decimals` equals `2`, a balance of `505` tokens should
- be displayed to a user as `5,05` (`505 / 10 ** 2`).
- Tokens usually opt for a value of 18, imitating the relationship between
- Ether and Wei. This is the value {ERC20} uses, unless {_setupDecimals} is
- called.
- NOTE: This information is only used for _display_ purposes: it in
- no way affects any of the arithmetic of the contract, including
- {IERC20-balanceOf} and {IERC20-transfer}.
+ @return the decimals of the token*
```
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function decimals() public view returns (uint8) {
+function decimals() public view override returns (uint8) {
     return _decimals;
   }
```
# (Changed) function ERC20.totalSupply()
✘ Document
```solidity
@@ -1 +1 @@
- @dev See {IERC20-totalSupply}.
+ @return the total supply of the token*
```
✓ Code
# (Changed) function ERC20.balanceOf(address)
✘ Document
```solidity
@@ -1 +1 @@
- @dev See {IERC20-balanceOf}.
+ @return the balance of the token*
```
✓ Code
# (Changed) function ERC20.transfer(address,uint256)
✘ Document
```solidity
@@ -1,4 +1,4 @@
- @dev See {IERC20-transfer}.
- Requirements:
- - `recipient` cannot be the zero address.
- - the caller must have a balance of at least `amount`.
+ @dev executes a transfer of tokens from msg.sender to recipient
+ @param recipient the recipient of the tokens
+ @param amount the amount of tokens being transferred
+ @return true if the transfer succeeds, false otherwise*
```
✓ Code
# (Changed) function ERC20.allowance(address,address)
✘ Document
```solidity
@@ -1 +1,4 @@
- @dev See {IERC20-allowance}.
+ @dev returns the allowance of spender on the tokens owned by owner
+ @param owner the owner of the tokens
+ @param spender the user allowed to spend the owner's tokens
+ @return the amount of owner's tokens spender is allowed to spend*
```
✓ Code
# (Changed) function ERC20.approve(address,uint256)
✘ Document
```solidity
@@ -1,3 +1,3 @@
- @dev See {IERC20-approve}.
- Requirements:
- - `spender` cannot be the zero address.
+ @dev allows spender to spend the tokens owned by msg.sender
+ @param spender the user allowed to spend msg.sender tokens
+ @return true*
```
✓ Code
# (Changed) function ERC20.transferFrom(address,address,uint256)
✘ Document
```solidity
@@ -1,8 +1,5 @@
- @dev See {IERC20-transferFrom}.
- Emits an {Approval} event indicating the updated allowance. This is not
- required by the EIP. See the note at the beginning of {ERC20};
- Requirements:
- - `sender` and `recipient` cannot be the zero address.
- - `sender` must have a balance of at least `amount`.
- - the caller must have allowance for ``sender``'s tokens of at least
- `amount`.
+ @dev executes a transfer of token from sender to recipient, if msg.sender is allowed to do so
+ @param sender the owner of the tokens
+ @param recipient the recipient of the tokens
+ @param amount the amount of tokens being transferred
+ @return true if the transfer succeeds, false otherwise*
```
✓ Code
# (Changed) variable StakedTokenV11.REVISION
✘ Document
```solidity
@@ -1 +1 @@
-@dev Start of Storage layout from StakedToken v1
+
```
✘ Code
```solidity
@@ -1 +1 @@
-uint256 public constant REVISION = 3
+uint256 public constant REVISION = 2
```
# (Changed) function ERC20.increaseAllowance(address,uint256)
✘ Document
```solidity
@@ -1,6 +1,4 @@
- @dev Atomically increases the allowance granted to `spender` by the caller.
- This is an alternative to {approve} that can be used as a mitigation for
- problems described in {IERC20-approve}.
- Emits an {Approval} event indicating the updated allowance.
- Requirements:
- - `spender` cannot be the zero address.
+ @dev increases the allowance of spender to spend msg.sender tokens
+ @param spender the user allowed to spend on behalf of msg.sender
+ @param addedValue the amount being added to the allowance
+ @return true*
```
✓ Code
# (Changed) function StakedTokenV11.initialize()
✓ Document
✘ Code
```solidity
@@ -1,22 +1,3 @@
-function initialize() external initializer {
-    uint256 chainId;
-
-    //solium-disable-next-line
-    assembly {
-      chainId := chainid()
-    }
-
-    DOMAIN_SEPARATOR = keccak256(
-      abi.encode(
-        EIP712_DOMAIN,
-        keccak256(bytes(name())),
-        keccak256(EIP712_REVISION),
-        chainId,
-        address(this)
-      )
-    );
-
-    // Update lastUpdateTimestamp of stkAave to reward users since the end of the prior staking period
-    AssetData storage assetData = assets[address(this)];
-    assetData.lastUpdateTimestamp = 1620594720;
+function initialize(
+  ) external initializer {
   }
```
# (Changed) function StakedTokenV11.getNextCooldownTimestamp(uint256,uint256,address,uint256)
✓ Document
✘ Code
```solidity
@@ -3,7 +3,7 @@
     uint256 amountToReceive,
     address toAddress,
     uint256 toBalance
-  ) public view returns (uint256) {
+  ) public returns (uint256) {
     uint256 toCooldownTimestamp = stakersCooldowns[toAddress];
     if (toCooldownTimestamp == 0) {
       return 0;
@@ -29,5 +29,7 @@
           .div(amountToReceive.add(toBalance));
       }
     }
+    stakersCooldowns[toAddress] = toCooldownTimestamp;
+
     return toCooldownTimestamp;
   }
```
# (Changed) function StakedTokenV11.claimRewards(address,uint256)
✓ Document
✘ Code
```solidity
@@ -2,10 +2,15 @@
     uint256 newTotalRewards =
       _updateCurrentUnclaimedRewards(msg.sender, balanceOf(msg.sender), false);
     uint256 amountToClaim = (amount == type(uint256).max) ? newTotalRewards : amount;
-
+    require(amountToClaim > 0, 'ZERO_CLAIM_AMOUNT');
     stakerRewardsToClaim[msg.sender] = newTotalRewards.sub(amountToClaim, 'INVALID_AMOUNT');
-
-    REWARD_TOKEN.safeTransferFrom(REWARDS_VAULT, to, amountToClaim);
-
+    uint256 directReturn = amountToClaim / 5;
+    uint256 lockAmount = amountToClaim.sub(directReturn);
+    REWARD_TOKEN.safeTransferFrom(REWARDS_VAULT, to, directReturn);
+    if (lockAmount > 0) {
+      TokenTimeLockV2 claimContract = new TokenTimeLockV2(address(REWARD_TOKEN), to, 365 days);
+      REWARD_TOKEN.safeTransferFrom(REWARDS_VAULT, address(claimContract), lockAmount);
+      emit NewLockReward(address(claimContract), to);
+    }
     emit RewardsClaimed(msg.sender, to, amountToClaim);
   }
```
# (Match) function AaveDistributionManager._claimRewards(address,struct DistributionTypes.UserStakeInput[])
✓ Document
✓ Code
# (Match) function IAaveDistributionManager.configureAssets(struct DistributionTypes.AssetConfigInput[])
✓ Document
✓ Code
# (Match) contract AaveDistributionManager inherits
✓ Document
✓ Code
# (Match) AaveDistributionManager(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) struct AaveDistributionManager.AssetData
✓ Document
✓ Code
# (Match) variable AaveDistributionManager.DISTRIBUTION_END
✓ Document
✓ Code
# (Match) variable AaveDistributionManager.EMISSION_MANAGER
✓ Document
✓ Code
# (Match) variable AaveDistributionManager.PRECISION
✓ Document
✓ Code
# (Match) function AaveDistributionManager._getRewards(uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) variable AaveDistributionManager.assets
✓ Document
✓ Code
# (Match) event AaveDistributionManager.AssetConfigUpdated
✓ Document
✓ Code
# (Match) event AaveDistributionManager.AssetIndexUpdated
✓ Document
✓ Code
# (Match) event AaveDistributionManager.UserIndexUpdated
✓ Document
✓ Code
# (Match) function AaveDistributionManager.<constructor>(address,uint256)
✓ Document
✓ Code
# (Match) function AaveDistributionManager.configureAssets(struct DistributionTypes.AssetConfigInput[])
✓ Document
✓ Code
# (Match) function AaveDistributionManager._updateAssetStateInternal(address,struct AaveDistributionManager.AssetData,uint256)
✓ Document
✓ Code
# (Match) function AaveDistributionManager._updateUserAssetInternal(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function AaveDistributionManager._getUnclaimedRewards(address,struct DistributionTypes.UserStakeInput[])
✓ Document
✓ Code
# (Match) contract Context inherits
✓ Document
✓ Code
# (Match) variable VersionedInitializable.______gap
✓ Document
✓ Code
# (Match) event StakedTokenV11.Redeem
✓ Document
✓ Code
# (Match) function StakedTokenV11.getTotalRewardsBalance(address)
✓ Document
✓ Code
# (Match) function StakedTokenV11._updateCurrentUnclaimedRewards(address,uint256,bool)
✓ Document
✓ Code
# (Match) function StakedTokenV11._transfer(address,address,uint256)
✓ Document
✓ Code
# (Match) function StakedTokenV11.cooldown()
✓ Document
✓ Code
# (Match) function StakedTokenV11.redeem(address,uint256)
✓ Document
✓ Code
# (Match) function StakedTokenV11.stake(address,uint256)
✓ Document
✓ Code
# (Match) event StakedTokenV11.Cooldown
✓ Document
✓ Code
# (Match) event StakedTokenV11.RewardsClaimed
✓ Document
✓ Code
# (Match) event StakedTokenV11.RewardsAccrued
✓ Document
✓ Code
# (Match) event StakedTokenV11.Staked
✓ Document
✓ Code
# (Match) function AaveDistributionManager._getAssetIndex(uint256,uint256,uint128,uint256)
✓ Document
✓ Code
# (Match) variable StakedTokenV11.stakersCooldowns
✓ Document
✓ Code
# (Match) variable StakedTokenV11.stakerRewardsToClaim
✓ Document
✓ Code
# (Match) variable StakedTokenV11.REWARDS_VAULT
✓ Document
✓ Code
# (Match) variable StakedTokenV11.UNSTAKE_WINDOW
✓ Document
✓ Code
# (Match) variable StakedTokenV11.COOLDOWN_SECONDS
✓ Document
✓ Code
# (Match) variable StakedTokenV11.REWARD_TOKEN
✓ Document
✓ Code
# (Match) variable StakedTokenV11.STAKED_TOKEN
✓ Document
✓ Code
# (Match) StakedTokenV11(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) StakedTokenV11(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) function AaveDistributionManager.getUserAssetData(address,address)
✓ Document
✓ Code
# (Match) contract IAaveDistributionManager inherits
✓ Document
✓ Code
# (Match) contract SafeERC20 inherits
✓ Document
✓ Code
# (Match) function VersionedInitializable.getRevision()
✓ Document
✓ Code
# (Match) function SafeMath.add(uint256,uint256)
✓ Document
✓ Code
# (Match) function Address.isContract(address)
✓ Document
✓ Code
# (Match) contract Address inherits
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.mul(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256)
✓ Document
✓ Code
# (Match) contract SafeMath inherits
✓ Document
✓ Code
# (Match) ERC20(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) event IERC20.Approval
✓ Document
✓ Code
# (Match) event IERC20.Transfer
✓ Document
✓ Code
# (Match) function IERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.allowance(address,address)
✓ Document
✓ Code
# (Match) function IERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) function IERC20.totalSupply()
✓ Document
✓ Code
# (Match) contract IERC20 inherits
✓ Document
✓ Code
# (Match) function Context._msgData()
✓ Document
✓ Code
# (Match) function Address.sendValue(address payable,uint256)
✓ Document
✓ Code
# (Match) variable ERC20._balances
✓ Document
✓ Code
# (Match) modifier VersionedInitializable.initializer
✓ Document
✓ Code
# (Match) struct DistributionTypes.UserStakeInput
✓ Document
✓ Code
# (Match) variable VersionedInitializable.lastInitializedRevision
✓ Document
✓ Code
# (Match) contract VersionedInitializable inherits
✓ Document
✓ Code
# (Match) function SafeERC20.callOptionalReturn(contract IERC20,bytes)
✓ Document
✓ Code
# (Match) function SafeERC20.safeApprove(contract IERC20,address,uint256)
✓ Document
✓ Code
# (Match) function SafeERC20.safeTransferFrom(contract IERC20,address,address,uint256)
✓ Document
✓ Code
# (Match) function SafeERC20.safeTransfer(contract IERC20,address,uint256)
✓ Document
✓ Code
# (Match) SafeERC20(using Address for address)
✓ Document
✓ Code
# (Match) SafeERC20(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) function Context._msgSender()
✓ Document
✓ Code
# (Match) struct DistributionTypes.AssetConfigInput
✓ Document
✓ Code
# (Match) variable ERC20._allowances
✓ Document
✓ Code
# (Match) contract DistributionTypes inherits
✓ Document
✓ Code
# (Match) function ITransferHook.onTransfer(address,address,uint256)
✓ Document
✓ Code
# (Match) contract ITransferHook inherits
✓ Document
✓ Code
# (Match) function IStakedAave.claimRewards(address,uint256)
✓ Document
✓ Code
# (Match) function IStakedAave.cooldown()
✓ Document
✓ Code
# (Match) function IStakedAave.redeem(address,uint256)
✓ Document
✓ Code
# (Match) function IStakedAave.stake(address,uint256)
✓ Document
✓ Code
# (Match) contract IStakedAave inherits
✓ Document
✓ Code
# (Match) variable ERC20._decimals
✓ Document
✓ Code
# (Match) variable ERC20._totalSupply
✓ Document
✓ Code
# (Match) function StakedTokenV11.getRevision()
✓ Document
✓ Code

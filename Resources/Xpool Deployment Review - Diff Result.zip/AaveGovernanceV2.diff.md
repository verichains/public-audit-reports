# (Match) function getChainId<freeFunction>()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.unauthorizeExecutors(address[])
✓ Document
✓ Code
# (Match) variable AaveGovernanceV2._votingDelay
✓ Document
✓ Code
# (Match) variable AaveGovernanceV2._governanceStrategy
✓ Document
✓ Code
# (Match) AaveGovernanceV2(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) contract AaveGovernanceV2 inherits
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getProposalState(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getVoteOnProposal(uint256,address)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getProposalById(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getProposalsCount()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getGuardian()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.isExecutorAuthorized(address)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getVotingDelay()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.getGovernanceStrategy()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.__abdicate()
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.authorizeExecutors(address[])
✓ Document
✓ Code
# (Match) variable AaveGovernanceV2._proposals
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.setVotingDelay(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.setGovernanceStrategy(address)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.submitVoteBySignature(uint256,bool,uint8,bytes32,bytes32)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.submitVote(uint256,bool)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.execute(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.queue(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.cancel(uint256)
✓ Document
✓ Code
# (Match) function IAaveGovernanceV2.create(contract IExecutorWithTimelock,address[],uint256[],string[],bytes[],bool[],bytes32)
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ExecutorUnauthorized
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ExecutorAuthorized
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.VotingDelayChanged
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.GovernanceStrategyChanged
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.VoteEmitted
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ProposalExecuted
✓ Document
✓ Code
# (Match) variable AaveGovernanceV2._proposalsCount
✓ Document
✓ Code
# (Match) variable AaveGovernanceV2._authorizedExecutors
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ProposalCanceled
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.unauthorizeExecutors(address[])
✓ Document
✓ Code
# (Match) function AaveGovernanceV2._authorizeExecutor(address)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2._setVotingDelay(uint256)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2._setGovernanceStrategy(address)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2._submitVote(address,uint256,bool)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2._queueOrRevert(contract IExecutorWithTimelock,address,uint256,string,bytes,uint256,bool)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.getProposalState(uint256)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.getVoteOnProposal(uint256,address)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.getProposalById(uint256)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.getProposalsCount()
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.getGuardian()
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.isExecutorAuthorized(address)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.getVotingDelay()
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.getGovernanceStrategy()
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.__abdicate()
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.authorizeExecutors(address[])
✓ Document
✓ Code
# (Match) variable AaveGovernanceV2._guardian
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.setVotingDelay(uint256)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.setGovernanceStrategy(address)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.submitVoteBySignature(uint256,bool,uint8,bytes32,bytes32)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.submitVote(uint256,bool)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.execute(uint256)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.queue(uint256)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.cancel(uint256)
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.create(contract IExecutorWithTimelock,address[],uint256[],string[],bytes[],bool[],bytes32)
✓ Document
✓ Code
# (Match) struct AaveGovernanceV2.CreateVars
✓ Document
✓ Code
# (Match) function AaveGovernanceV2.<constructor>(address,uint256,address,address[])
✓ Document
✓ Code
# (Match) modifier AaveGovernanceV2.onlyGuardian
✓ Document
✓ Code
# (Match) variable AaveGovernanceV2.NAME
✓ Document
✓ Code
# (Match) variable AaveGovernanceV2.VOTE_EMITTED_TYPEHASH
✓ Document
✓ Code
# (Match) variable AaveGovernanceV2.DOMAIN_TYPEHASH
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ProposalQueued
✓ Document
✓ Code
# (Match) event IAaveGovernanceV2.ProposalCreated
✓ Document
✓ Code
# (Match) function isContract<freeFunction>(address)
✓ Document
✓ Code
# (Match) function SafeMath.mul(uint256,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.isQuorumValid(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.isProposalPassed(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.getMinimumPropositionPowerNeeded(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.isPropositionPowerEnough(contract IAaveGovernanceV2,address,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.validateProposalCancellation(contract IAaveGovernanceV2,address,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.validateCreatorOfProposal(contract IAaveGovernanceV2,address,uint256)
✓ Document
✓ Code
# (Match) contract IProposalValidator inherits
✓ Document
✓ Code
# (Match) function IVotingStrategy.getVotingPowerAt(address,uint256)
✓ Document
✓ Code
# (Match) contract IVotingStrategy inherits
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function IProposalValidator.getMinimumVotingPowerNeeded(uint256)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.add(uint256,uint256)
✓ Document
✓ Code
# (Match) contract SafeMath inherits
✓ Document
✓ Code
# (Match) function Ownable.transferOwnership(address)
✓ Document
✓ Code
# (Match) function Ownable.renounceOwnership()
✓ Document
✓ Code
# (Match) modifier Ownable.onlyOwner
✓ Document
✓ Code
# (Match) function Ownable.owner()
✓ Document
✓ Code
# (Match) function Ownable.<constructor>()
✓ Document
✓ Code
# (Match) event Ownable.OwnershipTransferred
✓ Document
✓ Code
# (Match) variable Ownable._owner
✓ Document
✓ Code
# (Match) contract Ownable inherits
✓ Document
✓ Code
# (Match) function Context._msgData()
✓ Document
✓ Code
# (Match) function Context._msgSender()
✓ Document
✓ Code
# (Match) contract Context inherits
✓ Document
✓ Code
# (Match) function IProposalValidator.isVoteDifferentialValid(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IProposalValidator.PROPOSITION_THRESHOLD()
✓ Document
✓ Code
# (Match) struct IAaveGovernanceV2.ProposalWithoutVotes
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.getAdmin()
✓ Document
✓ Code
# (Match) struct IAaveGovernanceV2.Proposal
✓ Document
✓ Code
# (Match) struct IAaveGovernanceV2.Vote
✓ Document
✓ Code
# (Match) enum IAaveGovernanceV2.ProposalState
✓ Document
✓ Code
# (Match) contract IAaveGovernanceV2 inherits
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.cancelTransaction(address,uint256,string,bytes,uint256,bool)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.executeTransaction(address,uint256,string,bytes,uint256,bool)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.queueTransaction(address,uint256,string,bytes,uint256,bool)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.MAXIMUM_DELAY()
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.MINIMUM_DELAY()
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.GRACE_PERIOD()
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.isProposalOverGracePeriod(contract IAaveGovernanceV2,uint256)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.isActionQueued(bytes32)
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.getDelay()
✓ Document
✓ Code
# (Match) function IExecutorWithTimelock.getPendingAdmin()
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.ExecutedAction
✓ Document
✓ Code
# (Match) function IProposalValidator.VOTING_DURATION()
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.CancelledAction
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.QueuedAction
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.NewDelay
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.NewAdmin
✓ Document
✓ Code
# (Match) event IExecutorWithTimelock.NewPendingAdmin
✓ Document
✓ Code
# (Match) contract IExecutorWithTimelock inherits
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getVotingPowerAt(address,uint256)
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getTotalVotingSupplyAt(uint256)
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getTotalPropositionSupplyAt(uint256)
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getPropositionPowerAt(address,uint256)
✓ Document
✓ Code
# (Match) contract IGovernanceStrategy inherits
✓ Document
✓ Code
# (Match) function IProposalValidator.ONE_HUNDRED_WITH_PRECISION()
✓ Document
✓ Code
# (Match) function IProposalValidator.MINIMUM_QUORUM()
✓ Document
✓ Code
# (Match) function IProposalValidator.VOTE_DIFFERENTIAL()
✓ Document
✓ Code
# (Match) function AaveGovernanceV2._unauthorizeExecutor(address)
✓ Document
✓ Code

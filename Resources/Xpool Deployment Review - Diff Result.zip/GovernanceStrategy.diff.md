# (Match) contract IERC20 inherits
✓ Document
✓ Code
# (Match) contract GovernanceStrategy inherits
✓ Document
✓ Code
# (Match) function GovernanceStrategy.getVotingPowerAt(address,uint256)
✓ Document
✓ Code
# (Match) function GovernanceStrategy.getPropositionPowerAt(address,uint256)
✓ Document
✓ Code
# (Match) function GovernanceStrategy.getTotalVotingSupplyAt(uint256)
✓ Document
✓ Code
# (Match) function GovernanceStrategy.getTotalPropositionSupplyAt(uint256)
✓ Document
✓ Code
# (Match) function GovernanceStrategy.<constructor>(address,address)
✓ Document
✓ Code
# (Match) variable GovernanceStrategy.STK_AAVE
✓ Document
✓ Code
# (Match) variable GovernanceStrategy.AAVE
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getVotingPowerAt(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.totalSupplyAt(uint256)
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getTotalVotingSupplyAt(uint256)
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getTotalPropositionSupplyAt(uint256)
✓ Document
✓ Code
# (Match) function IGovernanceStrategy.getPropositionPowerAt(address,uint256)
✓ Document
✓ Code
# (Match) contract IGovernanceStrategy inherits
✓ Document
✓ Code
# (Match) function IGovernancePowerDelegationToken.getPowerAtBlock(address,uint256,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) enum IGovernancePowerDelegationToken.DelegationType
✓ Document
✓ Code
# (Match) contract IGovernancePowerDelegationToken inherits
✓ Document
✓ Code
# (Match) function IERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) function GovernanceStrategy._getPowerByTypeAt(address,uint256,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code

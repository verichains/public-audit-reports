# (Added) contract XpoolTokenV1
```solidity
 @notice implementation of the Xpool token contract
 @author Xpool
```
```solidity
contract XpoolTokenV1 is GovernancePowerDelegationERC20, VersionedInitializable
```
# (Added) XpoolTokenV1(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Removed) contract SafeERC20
```solidity
 @title SafeERC20
 @dev From https://github.com/OpenZeppelin/openzeppelin-contracts
 Wrappers around ERC20 operations that throw on failure (when the token
 contract returns false). Tokens that return no value (and instead revert or
 throw on failure) are also supported, non-reverting calls are assumed to be
 successful.
 To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
 which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
```
```solidity
library SafeERC20
```
# (Removed) SafeERC20(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Removed) SafeERC20(using Address for address)
```solidity
using Address for address;
```
# (Removed) contract AaveTokenV2
```solidity
 @notice implementation of the AAVE token contract
 @author Aave
```
```solidity
contract AaveTokenV2 is GovernancePowerDelegationERC20, VersionedInitializable
```
# (Removed) AaveTokenV2(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Changed) function SafeMath.add(uint256,uint256)
✓ Document
✘ Code
```solidity
@@ -1,6 +1,6 @@
 function add(uint256 a, uint256 b) internal pure returns (uint256) {
     uint256 c = a + b;
-    require(c >= a, 'SafeMath: addition overflow');
+        require(c >= a, "SafeMath: addition overflow");
 
     return c;
   }
```
# (Changed) contract IERC20 inherits
✘ Document
```solidity
@@ -1,2 +1 @@
  @dev Interface of the ERC20 standard as defined in the EIP.
- From https://github.com/OpenZeppelin/openzeppelin-contracts
```
✓ Code
# (Changed) function SafeMath.mul(uint256,uint256)
✓ Document
✘ Code
```solidity
@@ -7,7 +7,7 @@
     }
 
     uint256 c = a * b;
-    require(c / a == b, 'SafeMath: multiplication overflow');
+        require(c / a == b, "SafeMath: multiplication overflow");
 
     return c;
   }
```
# (Changed) modifier VersionedInitializable.initializer
✓ Document
✘ Code
```solidity
@@ -1,8 +1,9 @@
 modifier initializer() {
     uint256 revision = getRevision();
-    require(revision > lastInitializedRevision, 'Contract instance has already been initialized');
+        require(revision > lastInitializedRevision, "Contract instance has already been initialized");
 
     lastInitializedRevision = revision;
 
     _;
+
   }
```
# (Changed) function SafeMath.sub(uint256,uint256)
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
 function sub(uint256 a, uint256 b) internal pure returns (uint256) {
-    return sub(a, b, 'SafeMath: subtraction overflow');
+        return sub(a, b, "SafeMath: subtraction overflow");
   }
```
# (Changed) contract SafeMath inherits
✘ Document
```solidity
@@ -1,5 +1,4 @@
- @dev From https://github.com/OpenZeppelin/openzeppelin-contracts
- Wrappers over Solidity's arithmetic operations with added overflow
+ @dev Wrappers over Solidity's arithmetic operations with added overflow
  checks.
  Arithmetic operations in Solidity wrap on overflow. This can easily result
  in bugs, because programmers usually assume that an overflow raises an
```
✓ Code
# (Changed) contract Address inherits
✘ Document
```solidity
@@ -1,2 +1 @@
  @dev Collection of functions related to the address type
- From https://github.com/OpenZeppelin/openzeppelin-contracts
```
✓ Code
# (Changed) contract GovernancePowerDelegationERC20 inherits
✘ Document
```solidity
@@ -1,2 +1,2 @@
- @notice implementation of the AAVE token contract
- @author Aave
+ @notice implementation of the Xpool token contract
+ @author Xpool
```
✓ Code
# (Changed) function Address.sendValue(address payable,uint256)
✓ Document
✘ Code
```solidity
@@ -1,7 +1,7 @@
 function sendValue(address payable recipient, uint256 amount) internal {
-    require(address(this).balance >= amount, 'Address: insufficient balance');
+        require(address(this).balance >= amount, "Address: insufficient balance");
 
     // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
-    (bool success, ) = recipient.call{value: amount}('');
-    require(success, 'Address: unable to send value, recipient may have reverted');
+        (bool success, ) = recipient.call{ value: amount }("");
+        require(success, "Address: unable to send value, recipient may have reverted");
   }
```
# (Changed) function SafeMath.mod(uint256,uint256)
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
 function mod(uint256 a, uint256 b) internal pure returns (uint256) {
-    return mod(a, b, 'SafeMath: modulo by zero');
+        return mod(a, b, "SafeMath: modulo by zero");
   }
```
# (Changed) function SafeMath.div(uint256,uint256)
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
 function div(uint256 a, uint256 b) internal pure returns (uint256) {
-    return div(a, b, 'SafeMath: division by zero');
+        return div(a, b, "SafeMath: division by zero");
   }
```
# (Changed) function GovernancePowerDelegationERC20.totalSupplyAt(uint256)
✘ Document
```solidity
@@ -1,4 +1,4 @@
  @dev returns the total supply at a certain block number
  used by the voting strategy contracts to calculate the total votes needed for threshold/quorum
- In this initial implementation with no AAVE minting, simply returns the current supply
- A snapshots mapping will need to be added in case a mint function is added to the AAVE token in the future*
+ In this initial implementation with no XPO minting, simply returns the current supply
+ A snapshots mapping will need to be added in case a mint function is added to the XPO token in the future*
```
✓ Code
# (Changed) contract Context inherits
✘ Document
```solidity
@@ -1,8 +1 @@
- @dev From https://github.com/OpenZeppelin/openzeppelin-contracts
- Provides information about the current execution context, including the
- sender of the transaction and its data. While these are generally available
- via msg.sender and msg.data, they should not be accessed in such a direct
- manner, since when dealing with GSN meta-transactions the account sending and
- paying for execution may not be the actual sender (as far as an application
- is concerned).
- This contract is only required for intermediate, library-like contracts.
+
```
✓ Code
# (Changed) function GovernancePowerDelegationERC20._getDelegationDataByType(enum IGovernancePowerDelegationToken.DelegationType)
✘ Document
```solidity
@@ -1,5 +1,5 @@
  @dev returns the delegation data (snapshot, snapshotsCount, list of delegates) by delegation type
  NOTE: Ideal implementation would have mapped this in a struct by delegation type. Unfortunately,
- the AAVE token and StakeToken already include a mapping for the snapshots, so we require contracts
+ the XPO token and StakeToken already include a mapping for the snapshots, so we require contracts
  who inherit from this to provide access to the delegation data by overriding this method.
  @param delegationType the type of delegation*
```
✓ Code
# (Match) function ERC20.increaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) function ERC20.allowance(address,address)
✓ Document
✓ Code
# (Match) function ERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) contract VersionedInitializable inherits
✓ Document
✓ Code
# (Match) function ERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) function ERC20._mint(address,uint256)
✓ Document
✓ Code
# (Match) function ITransferHook.onTransfer(address,address,uint256)
✓ Document
✓ Code
# (Match) function ERC20._burn(address,uint256)
✓ Document
✓ Code
# (Match) function ERC20.decreaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) contract ITransferHook inherits
✓ Document
✓ Code
# (Match) function ERC20._beforeTokenTransfer(address,address,uint256)
✓ Document
✓ Code
# (Match) function ERC20._setupDecimals(uint8)
✓ Document
✓ Code
# (Match) function ERC20._transfer(address,address,uint256)
✓ Document
✓ Code
# (Match) function ERC20._approve(address,address,uint256)
✓ Document
✓ Code
# (Match) contract IGovernancePowerDelegationToken inherits
✓ Document
✓ Code
# (Match) variable VersionedInitializable.lastInitializedRevision
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20.getDelegateeByType(address,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20._writeSnapshot(mapping(address => mapping(uint256 => struct GovernancePowerDelegationERC20.Snapshot)),mapping(address => uint256),address,uint128,uint128)
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20._searchByBlockNumber(mapping(address => mapping(uint256 => struct GovernancePowerDelegationERC20.Snapshot)),mapping(address => uint256),address,uint256)
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20._moveDelegatesByType(address,address,uint256,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20._delegateByType(address,address,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20.getPowerAtBlock(address,uint256,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20.getPowerCurrent(address,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20.delegate(address)
✓ Document
✓ Code
# (Match) function ERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20.delegateByType(address,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) struct GovernancePowerDelegationERC20.Snapshot
✓ Document
✓ Code
# (Match) variable GovernancePowerDelegationERC20.DELEGATE_TYPEHASH
✓ Document
✓ Code
# (Match) variable GovernancePowerDelegationERC20.DELEGATE_BY_TYPE_TYPEHASH
✓ Document
✓ Code
# (Match) GovernancePowerDelegationERC20(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) variable VersionedInitializable.______gap
✓ Document
✓ Code
# (Match) function VersionedInitializable.getRevision()
✓ Document
✓ Code
# (Match) function ERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) variable ERC20._decimals
✓ Document
✓ Code
# (Match) function ERC20.totalSupply()
✓ Document
✓ Code
# (Match) function Context._msgSender()
✓ Document
✓ Code
# (Match) function IERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.allowance(address,address)
✓ Document
✓ Code
# (Match) function IERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) function IERC20.totalSupply()
✓ Document
✓ Code
# (Match) function Context._msgData()
✓ Document
✓ Code
# (Match) function IGovernancePowerDelegationToken.totalSupplyAt(uint256)
✓ Document
✓ Code
# (Match) event IERC20.Transfer
✓ Document
✓ Code
# (Match) function IGovernancePowerDelegationToken.getPowerAtBlock(address,uint256,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) function IGovernancePowerDelegationToken.getPowerCurrent(address,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) function IGovernancePowerDelegationToken.getDelegateeByType(address,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) function IGovernancePowerDelegationToken.delegate(address)
✓ Document
✓ Code
# (Match) function IGovernancePowerDelegationToken.delegateByType(address,enum IGovernancePowerDelegationToken.DelegationType)
✓ Document
✓ Code
# (Match) event IGovernancePowerDelegationToken.DelegatedPowerChanged
✓ Document
✓ Code
# (Match) event IGovernancePowerDelegationToken.DelegateChanged
✓ Document
✓ Code
# (Match) function IERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) event IERC20.Approval
✓ Document
✓ Code
# (Match) function ERC20.decimals()
✓ Document
✓ Code
# (Match) variable ERC20._totalSupply
✓ Document
✓ Code
# (Match) function ERC20.symbol()
✓ Document
✓ Code
# (Match) function ERC20.name()
✓ Document
✓ Code
# (Match) function ERC20.<constructor>(string,string)
✓ Document
✓ Code
# (Match) enum IGovernancePowerDelegationToken.DelegationType
✓ Document
✓ Code
# (Match) variable ERC20._symbol
✓ Document
✓ Code
# (Match) variable ERC20._name
✓ Document
✓ Code
# (Match) variable ERC20._allowances
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256,string)
✓ Document
✓ Code
# (Match) variable ERC20._balances
✓ Document
✓ Code
# (Match) ERC20(using Address for address)
✓ Document
✓ Code
# (Match) ERC20(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) contract ERC20 inherits
✓ Document
✓ Code
# (Match) function Address.isContract(address)
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function GovernancePowerDelegationERC20._getDelegatee(address,mapping(address => address))
✓ Document
✓ Code

# (Changed) contract VersionedInitializable inherits
✘ Document
```solidity
@@ -1,5 +1,5 @@
  @title VersionedInitializable
- @dev Helper contract to support initializer functions. To use it, replace
+ @dev Helper contract to implement initializer functions. To use it, replace
  the constructor with a function that has the `initializer` modifier.
  WARNING: Unlike constructors, initializer functions must be manually
  invoked. This applies both to deploying an Initializable contract, as well
```
✓ Code
# (Changed) function VersionedInitializable.getRevision()
✘ Document
```solidity
@@ -1,2 +1,2 @@
-@dev returns the revision number of the contract.
- Needs to be defined in the inherited class as a constant.
+ @dev returns the revision number of the contract
+ Needs to be defined in the inherited class as a constant.*
```
✘ Code
```solidity
@@ -1 +1 @@
-function getRevision() internal virtual pure returns (uint256);
+function getRevision() internal pure virtual returns (uint256);
```
# (Changed) function VersionedInitializable.isConstructor()
✘ Document
```solidity
@@ -1 +1 @@
-@dev Returns true if and only if the function is running in the constructor
+ @dev Returns true if and only if the function is running in the constructor*
```
✓ Code
# (Changed) function AaveCollector.getRevision()
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function getRevision() internal override pure returns (uint256) {
+function getRevision() internal pure override returns (uint256) {
     return REVISION;
   }
```
# (Match) variable VersionedInitializable.lastInitializedRevision
✓ Document
✓ Code
# (Match) variable VersionedInitializable.initializing
✓ Document
✓ Code
# (Match) modifier VersionedInitializable.initializer
✓ Document
✓ Code
# (Match) variable VersionedInitializable.______gap
✓ Document
✓ Code
# (Match) contract AaveCollector inherits
✓ Document
✓ Code
# (Match) variable AaveCollector.REVISION
✓ Document
✓ Code
# (Match) function AaveCollector.initialize()
✓ Document
✓ Code

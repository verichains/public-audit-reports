# (Changed) function Proxy._implementation()
✓ Document
✘ Code
```solidity
@@ -1 +1 @@
-function _implementation() internal virtual view returns (address);
+function _implementation() internal view virtual returns (address);
```
# (Changed) function BaseUpgradeabilityProxy._implementation()
✓ Document
✘ Code
```solidity
@@ -1,4 +1,4 @@
-function _implementation() internal override view returns (address impl) {
+function _implementation() internal view override returns (address impl) {
     bytes32 slot = IMPLEMENTATION_SLOT;
     //solium-disable-next-line
     assembly {
```
# (Changed) function Context._msgData()
✓ Document
✘ Code
```solidity
@@ -1,4 +1,4 @@
-function _msgData() internal virtual view returns (bytes memory) {
+function _msgData() internal view virtual returns (bytes memory) {
     this; // silence state mutability warning without generating bytecode - see https://github.com/ethereum/solidity/issues/2691
     return msg.data;
   }
```
# (Changed) function Context._msgSender()
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function _msgSender() internal virtual view returns (address payable) {
+function _msgSender() internal view virtual returns (address payable) {
     return msg.sender;
   }
```
# (Match) function Proxy._fallback()
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.MarketIdSet
✓ Document
✓ Code
# (Match) contract ILendingPoolAddressesProvider inherits
✓ Document
✓ Code
# (Match) function InitializableUpgradeabilityProxy.initialize(address,bytes)
✓ Document
✓ Code
# (Match) contract InitializableUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) function Address.sendValue(address payable,uint256)
✓ Document
✓ Code
# (Match) function Address.isContract(address)
✓ Document
✓ Code
# (Match) contract Address inherits
✓ Document
✓ Code
# (Match) contract LendingPoolAddressesProvider inherits
✓ Document
✓ Code
# (Match) function Proxy._willFallback()
✓ Document
✓ Code
# (Match) function Proxy._delegate(address)
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.EmergencyAdminUpdated
✓ Document
✓ Code
# (Match) function Proxy.<fallback>()
✓ Document
✓ Code
# (Match) contract Proxy inherits
✓ Document
✓ Code
# (Match) function BaseUpgradeabilityProxy._setImplementation(address)
✓ Document
✓ Code
# (Match) function BaseUpgradeabilityProxy._upgradeTo(address)
✓ Document
✓ Code
# (Match) variable BaseUpgradeabilityProxy.IMPLEMENTATION_SLOT
✓ Document
✓ Code
# (Match) event BaseUpgradeabilityProxy.Upgraded
✓ Document
✓ Code
# (Match) contract BaseUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ConfigurationAdminUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolConfiguratorUpdated
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.upgradeToAndCall(address,bytes)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolConfigurator()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingRateOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPriceOracle(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPriceOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setEmergencyAdmin(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getEmergencyAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPoolAdmin(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPoolAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolCollateralManager(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolCollateralManager()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolConfiguratorImpl(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolImpl(address)
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolCollateralManagerUpdated
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPool()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getAddress(bytes32)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddressAsProxy(bytes32,address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddress(bytes32,address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setMarketId(string)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getMarketId()
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.AddressSet
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ProxyCreated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingRateOracleUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.PriceOracleUpdated
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy._willFallback()
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.implementation()
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.upgradeTo(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setAddressAsProxy(bytes32,address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getPoolAdmin()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setLendingPoolCollateralManager(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getLendingPoolCollateralManager()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setLendingPoolConfiguratorImpl(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getLendingPoolConfigurator()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setLendingPoolImpl(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getLendingPool()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getAddress(bytes32)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setAddress(bytes32,address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setMarketId(string)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getEmergencyAdmin()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getMarketId()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.<constructor>(string)
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.LENDING_RATE_ORACLE
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.PRICE_ORACLE
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.LENDING_POOL_COLLATERAL_MANAGER
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.EMERGENCY_ADMIN
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.POOL_ADMIN
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.LENDING_POOL_CONFIGURATOR
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.LENDING_POOL
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider._addresses
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setPoolAdmin(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setEmergencyAdmin(address)
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider._marketId
✓ Document
✓ Code
# (Match) function Ownable.renounceOwnership()
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.admin()
✓ Document
✓ Code
# (Match) modifier BaseImmutableAdminUpgradeabilityProxy.ifAdmin
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.<constructor>(address)
✓ Document
✓ Code
# (Match) variable BaseImmutableAdminUpgradeabilityProxy.ADMIN
✓ Document
✓ Code
# (Match) contract BaseImmutableAdminUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) function InitializableImmutableAdminUpgradeabilityProxy._willFallback()
✓ Document
✓ Code
# (Match) function InitializableImmutableAdminUpgradeabilityProxy.<constructor>(address)
✓ Document
✓ Code
# (Match) contract InitializableImmutableAdminUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) contract Context inherits
✓ Document
✓ Code
# (Match) function Ownable.transferOwnership(address)
✓ Document
✓ Code
# (Match) modifier Ownable.onlyOwner
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getPriceOracle()
✓ Document
✓ Code
# (Match) function Ownable.owner()
✓ Document
✓ Code
# (Match) function Ownable.<constructor>()
✓ Document
✓ Code
# (Match) event Ownable.OwnershipTransferred
✓ Document
✓ Code
# (Match) variable Ownable._owner
✓ Document
✓ Code
# (Match) contract Ownable inherits
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider._setMarketId(string)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider._updateImpl(bytes32,address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setLendingRateOracle(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getLendingRateOracle()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setPriceOracle(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingRateOracle(address)
✓ Document
✓ Code

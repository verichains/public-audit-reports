# (Changed) function StableDebtToken._burn(address,uint256,uint256)
✓ Document
✘ Code
```solidity
@@ -7,6 +7,6 @@
     _balances[account] = oldAccountBalance.sub(amount, Errors.SDT_BURN_EXCEEDS_BALANCE);
 
     if (address(_incentivesController) != address(0)) {
-      _incentivesController.handleAction(account, oldTotalSupply, oldAccountBalance);
+      _incentivesController.handleAction(account, oldAccountBalance, oldTotalSupply);
     }
   }
```
# (Changed) function Context._msgSender()
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function _msgSender() internal virtual view returns (address payable) {
+function _msgSender() internal view virtual returns (address payable) {
     return msg.sender;
   }
```
# (Changed) function Context._msgData()
✓ Document
✘ Code
```solidity
@@ -1,4 +1,4 @@
-function _msgData() internal virtual view returns (bytes memory) {
+function _msgData() internal view virtual returns (bytes memory) {
     this; // silence state mutability warning without generating bytecode - see https://github.com/ethereum/solidity/issues/2691
     return msg.data;
   }
```
# (Changed) function IncentivizedERC20._burn(address,uint256)
✓ Document
✘ Code
```solidity
@@ -10,6 +10,6 @@
     _balances[account] = oldAccountBalance.sub(amount, 'ERC20: burn amount exceeds balance');
 
     if (address(_incentivesController) != address(0)) {
-      _incentivesController.handleAction(account, oldTotalSupply, oldAccountBalance);
+      _incentivesController.handleAction(account, oldAccountBalance, oldTotalSupply);
     }
   }
```
# (Changed) function IncentivizedERC20._mint(address,uint256)
✓ Document
✘ Code
```solidity
@@ -10,6 +10,6 @@
     _balances[account] = oldAccountBalance.add(amount);
 
     if (address(_incentivesController) != address(0)) {
-      _incentivesController.handleAction(account, oldTotalSupply, oldAccountBalance);
+      _incentivesController.handleAction(account, oldAccountBalance, oldTotalSupply);
     }
   }
```
# (Changed) function IncentivizedERC20._transfer(address,address,uint256)
✓ Document
✘ Code
```solidity
@@ -15,9 +15,9 @@
 
     if (address(_incentivesController) != address(0)) {
       uint256 currentTotalSupply = _totalSupply;
-      _incentivesController.handleAction(sender, currentTotalSupply, oldSenderBalance);
+      _incentivesController.handleAction(sender, oldSenderBalance, currentTotalSupply);
       if (sender != recipient) {
-        _incentivesController.handleAction(recipient, currentTotalSupply, oldRecipientBalance);
+        _incentivesController.handleAction(recipient, oldRecipientBalance, currentTotalSupply);
       }
     }
   }
```
# (Changed) variable IncentivizedERC20._incentivesController
✓ Document
✘ Code
```solidity
@@ -1 +1 @@
-IAaveIncentivesController internal immutable _incentivesController
+IAaveIncentivesController internal _incentivesController
```
# (Changed) function StableDebtToken._mint(address,uint256,uint256)
✓ Document
✘ Code
```solidity
@@ -7,6 +7,6 @@
     _balances[account] = oldAccountBalance.add(amount);
 
     if (address(_incentivesController) != address(0)) {
-      _incentivesController.handleAction(account, oldTotalSupply, oldAccountBalance);
+      _incentivesController.handleAction(account, oldAccountBalance, oldTotalSupply);
     }
   }
```
# (Match) variable Errors.VL_NO_STABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.LP_INTEREST_RATE_REBALANCE_CONDITIONS_NOT_MET
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_STABLE_BORROW_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.VL_DEPOSIT_ALREADY_IN_USE
✓ Document
✓ Code
# (Match) variable Errors.VL_UNDERLYING_BALANCE_NOT_GREATER_THAN_0
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_VARIABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) contract StableDebtToken inherits
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_EXPLICIT_AMOUNT_TO_REPAY_ON_BEHALF
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_DEBT_OF_SELECTED_TYPE
✓ Document
✓ Code
# (Match) variable Errors.VL_AMOUNT_BIGGER_THAN_MAX_LOAN_SIZE_STABLE
✓ Document
✓ Code
# (Match) variable Errors.VL_STABLE_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_CANNOT_COVER_NEW_BORROW
✓ Document
✓ Code
# (Match) variable Errors.VL_HEALTH_FACTOR_LOWER_THAN_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_BALANCE_IS_0
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_SAME_AS_BORROWING_CURRENCY
✓ Document
✓ Code
# (Match) variable Errors.LP_REQUESTED_AMOUNT_TOO_SMALL
✓ Document
✓ Code
# (Match) variable Errors.LP_LIQUIDATION_CALL_FAILED
✓ Document
✓ Code
# (Match) variable Errors.RL_RESERVE_ALREADY_INITIALIZED
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ATOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_RESERVE_LIQUIDITY_NOT_0
✓ Document
✓ Code
# (Match) variable Errors.CT_TRANSFER_AMOUNT_NOT_GT_0
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_LIQUIDITY_TO_BORROW
✓ Document
✓ Code
# (Match) variable Errors.CT_CANNOT_GIVE_ALLOWANCE_TO_HIMSELF
✓ Document
✓ Code
# (Match) variable Errors.CT_CALLER_MUST_BE_LENDING_POOL
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_NOT_LENDING_POOL_CONFIGURATOR
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PROTOCOL_ACTUAL_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.VL_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_INTEREST_RATE_MODE_SELECTED
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_ACTIVE_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_TRANSFER_NOT_ALLOWED
✓ Document
✓ Code
# (Match) function SafeMath.add(uint256,uint256)
✓ Document
✓ Code
# (Match) contract IERC20 inherits
✓ Document
✓ Code
# (Match) function IERC20.totalSupply()
✓ Document
✓ Code
# (Match) function IERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) function IERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.allowance(address,address)
✓ Document
✓ Code
# (Match) function IERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) event IERC20.Transfer
✓ Document
✓ Code
# (Match) event IERC20.Approval
✓ Document
✓ Code
# (Match) contract IERC20Detailed inherits
✓ Document
✓ Code
# (Match) function IERC20Detailed.name()
✓ Document
✓ Code
# (Match) function IERC20Detailed.symbol()
✓ Document
✓ Code
# (Match) function IERC20Detailed.decimals()
✓ Document
✓ Code
# (Match) contract SafeMath inherits
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256)
✓ Document
✓ Code
# (Match) variable Errors.VL_NOT_ENOUGH_AVAILABLE_USER_BALANCE
✓ Document
✓ Code
# (Match) contract Errors inherits
✓ Document
✓ Code
# (Match) variable Errors.VL_CURRENT_AVAILABLE_LIQUIDITY_NOT_ENOUGH
✓ Document
✓ Code
# (Match) variable Errors.VL_RESERVE_FROZEN
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_CONFIGURATION
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.BORROW_ALLOWANCE_NOT_ENOUGH
✓ Document
✓ Code
# (Match) variable Errors.CALLER_NOT_POOL_ADMIN
✓ Document
✓ Code
# (Match) function IAaveIncentivesController.handleAction(address,uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256,string)
✓ Document
✓ Code
# (Match) contract IAaveIncentivesController inherits
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.mul(uint256,uint256)
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_PROVIDER_NOT_REGISTERED
✓ Document
✓ Code
# (Match) variable Errors.LPC_CALLER_NOT_EMERGENCY_ADMIN
✓ Document
✓ Code
# (Match) variable WadRayMath.WAD
✓ Document
✓ Code
# (Match) function WadRayMath.wad()
✓ Document
✓ Code
# (Match) function WadRayMath.ray()
✓ Document
✓ Code
# (Match) variable WadRayMath.WAD_RAY_RATIO
✓ Document
✓ Code
# (Match) variable WadRayMath.halfRAY
✓ Document
✓ Code
# (Match) variable WadRayMath.RAY
✓ Document
✓ Code
# (Match) variable WadRayMath.halfWAD
✓ Document
✓ Code
# (Match) contract WadRayMath inherits
✓ Document
✓ Code
# (Match) function WadRayMath.halfWad()
✓ Document
✓ Code
# (Match) function MathUtils.calculateCompoundedInterest(uint256,uint40)
✓ Document
✓ Code
# (Match) function MathUtils.calculateCompoundedInterest(uint256,uint40,uint256)
✓ Document
✓ Code
# (Match) function MathUtils.calculateLinearInterest(uint256,uint40)
✓ Document
✓ Code
# (Match) variable MathUtils.SECONDS_PER_YEAR
✓ Document
✓ Code
# (Match) MathUtils(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) MathUtils(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.halfRay()
✓ Document
✓ Code
# (Match) function WadRayMath.wadMul(uint256,uint256)
✓ Document
✓ Code
# (Match) enum Errors.CollateralManagerErrors
✓ Document
✓ Code
# (Match) function IStableDebtToken.burn(address,uint256)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getTotalSupplyAndAvgRate()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getTotalSupplyLastUpdated()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getSupplyData()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getUserLastUpdated(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getUserStableRate(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getAverageStableRate()
✓ Document
✓ Code
# (Match) function IStableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.wadDiv(uint256,uint256)
✓ Document
✓ Code
# (Match) event IStableDebtToken.Burn
✓ Document
✓ Code
# (Match) event IStableDebtToken.Mint
✓ Document
✓ Code
# (Match) contract IStableDebtToken inherits
✓ Document
✓ Code
# (Match) function WadRayMath.wadToRay(uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.rayToWad(uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.rayDiv(uint256,uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.rayMul(uint256,uint256)
✓ Document
✓ Code
# (Match) contract MathUtils inherits
✓ Document
✓ Code
# (Match) variable Errors.SDT_BURN_EXCEEDS_BALANCE
✓ Document
✓ Code
# (Match) function IncentivizedERC20._beforeTokenTransfer(address,address,uint256)
✓ Document
✓ Code
# (Match) variable Errors.MATH_DIVISION_BY_ZERO
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_MINT_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.RL_STABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.MATH_ADDITION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_BURN_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.MATH_MULTIPLICATION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASHLOAN_MODE
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NO_ERRORS
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NOT_ENOUGH_LIQUIDITY_TO_LIQUIDATE
✓ Document
✓ Code
# (Match) variable Errors.LPCM_SPECIFIED_CURRENCY_NOT_BORROWED_BY_USER
✓ Document
✓ Code
# (Match) variable Errors.LPCM_COLLATERAL_CANNOT_BE_LIQUIDATED
✓ Document
✓ Code
# (Match) variable Errors.LPCM_HEALTH_FACTOR_NOT_BELOW_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_REPAY_WITH_COLLATERAL
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_COLLATERAL_SWAP
✓ Document
✓ Code
# (Match) variable Errors.SDT_STABLE_DEBT_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_DECIMALS
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_CONTRACT
✓ Document
✓ Code
# (Match) variable Errors.UL_INVALID_INDEX
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PARAMS_LENGTH
✓ Document
✓ Code
# (Match) variable Errors.VL_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_RESERVE_FACTOR
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_BONUS
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_EQUAL_ASSETS_TO_SWAP
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LTV
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASH_LOAN_EXECUTOR_RETURN
✓ Document
✓ Code
# (Match) variable Errors.LP_NO_MORE_RESERVES_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.LP_IS_PAUSED
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_MUST_BE_AN_ATOKEN
✓ Document
✓ Code
# (Match) variable Errors.LP_REENTRANCY_NOT_ALLOWED
✓ Document
✓ Code
# (Match) contract Context inherits
✓ Document
✓ Code
# (Match) function IncentivizedERC20._approve(address,address,uint256)
✓ Document
✓ Code
# (Match) function IncentivizedERC20._setDecimals(uint8)
✓ Document
✓ Code
# (Match) event ILendingPool.ReserveUsedAsCollateralDisabled
✓ Document
✓ Code
# (Match) event ILendingPool.ReserveDataUpdated
✓ Document
✓ Code
# (Match) event ILendingPool.LiquidationCall
✓ Document
✓ Code
# (Match) event ILendingPool.Unpaused
✓ Document
✓ Code
# (Match) event ILendingPool.Paused
✓ Document
✓ Code
# (Match) event ILendingPool.FlashLoan
✓ Document
✓ Code
# (Match) event ILendingPool.RebalanceStableBorrowRate
✓ Document
✓ Code
# (Match) event ILendingPool.ReserveUsedAsCollateralEnabled
✓ Document
✓ Code
# (Match) function ILendingPool.withdraw(address,uint256,address)
✓ Document
✓ Code
# (Match) event ILendingPool.Swap
✓ Document
✓ Code
# (Match) event ILendingPool.Repay
✓ Document
✓ Code
# (Match) event ILendingPool.Borrow
✓ Document
✓ Code
# (Match) event ILendingPool.Withdraw
✓ Document
✓ Code
# (Match) event ILendingPool.Deposit
✓ Document
✓ Code
# (Match) contract ILendingPool inherits
✓ Document
✓ Code
# (Match) function ILendingPool.deposit(address,uint256,address,uint16)
✓ Document
✓ Code
# (Match) function ILendingPool.borrow(address,uint256,uint256,uint16,address)
✓ Document
✓ Code
# (Match) function DebtTokenBase.decreaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) function ILendingPool.setReserveInterestRateStrategyAddress(address,address)
✓ Document
✓ Code
# (Match) function ILendingPool.getReserveData(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getReserveNormalizedVariableDebt(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getReserveNormalizedIncome(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getUserConfiguration(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getConfiguration(address)
✓ Document
✓ Code
# (Match) function ILendingPool.setConfiguration(address,uint256)
✓ Document
✓ Code
# (Match) function ILendingPool.initReserve(address,address,address,address,address)
✓ Document
✓ Code
# (Match) function ILendingPool.repay(address,uint256,uint256,address)
✓ Document
✓ Code
# (Match) function ILendingPool.getUserAccountData(address)
✓ Document
✓ Code
# (Match) function ILendingPool.flashLoan(address,address[],uint256[],uint256[],address,bytes,uint16)
✓ Document
✓ Code
# (Match) function ILendingPool.liquidationCall(address,address,address,uint256,bool)
✓ Document
✓ Code
# (Match) function ILendingPool.setUserUseReserveAsCollateral(address,bool)
✓ Document
✓ Code
# (Match) function ILendingPool.rebalanceStableBorrowRate(address,address)
✓ Document
✓ Code
# (Match) function ILendingPool.swapBorrowRateMode(address,uint256)
✓ Document
✓ Code
# (Match) function DebtTokenBase._decreaseBorrowAllowance(address,address,uint256)
✓ Document
✓ Code
# (Match) function DebtTokenBase.increaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) function ILendingPool.getReservesList()
✓ Document
✓ Code
# (Match) function StableDebtToken.getAverageStableRate()
✓ Document
✓ Code
# (Match) function StableDebtToken.burn(address,uint256)
✓ Document
✓ Code
# (Match) function StableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) struct StableDebtToken.MintLocalVars
✓ Document
✓ Code
# (Match) function StableDebtToken.balanceOf(address)
✓ Document
✓ Code
# (Match) function StableDebtToken.getUserStableRate(address)
✓ Document
✓ Code
# (Match) function StableDebtToken.getUserLastUpdated(address)
✓ Document
✓ Code
# (Match) function StableDebtToken.getRevision()
✓ Document
✓ Code
# (Match) function StableDebtToken.getSupplyData()
✓ Document
✓ Code
# (Match) function StableDebtToken.<constructor>(address,address,string,string,address)
✓ Document
✓ Code
# (Match) variable StableDebtToken._totalSupplyTimestamp
✓ Document
✓ Code
# (Match) variable StableDebtToken._usersStableRate
✓ Document
✓ Code
# (Match) variable StableDebtToken._timestamps
✓ Document
✓ Code
# (Match) variable StableDebtToken._avgStableRate
✓ Document
✓ Code
# (Match) variable StableDebtToken.DEBT_TOKEN_REVISION
✓ Document
✓ Code
# (Match) function StableDebtToken._calculateBalanceIncrease(address)
✓ Document
✓ Code
# (Match) function StableDebtToken.getTotalSupplyAndAvgRate()
✓ Document
✓ Code
# (Match) function DebtTokenBase.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) function DebtTokenBase.<constructor>(address,address,string,string,address)
✓ Document
✓ Code
# (Match) function DebtTokenBase.approve(address,uint256)
✓ Document
✓ Code
# (Match) function DebtTokenBase.allowance(address,address)
✓ Document
✓ Code
# (Match) function DebtTokenBase.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function DebtTokenBase.borrowAllowance(address,address)
✓ Document
✓ Code
# (Match) function DebtTokenBase.approveDelegation(address,uint256)
✓ Document
✓ Code
# (Match) function DebtTokenBase.initialize(uint8,string,string)
✓ Document
✓ Code
# (Match) modifier DebtTokenBase.onlyLendingPool
✓ Document
✓ Code
# (Match) function StableDebtToken.totalSupply()
✓ Document
✓ Code
# (Match) variable DebtTokenBase._borrowAllowances
✓ Document
✓ Code
# (Match) variable DebtTokenBase.POOL
✓ Document
✓ Code
# (Match) variable DebtTokenBase.UNDERLYING_ASSET_ADDRESS
✓ Document
✓ Code
# (Match) contract DebtTokenBase inherits
✓ Document
✓ Code
# (Match) function StableDebtToken._calcTotalSupply(uint256)
✓ Document
✓ Code
# (Match) function StableDebtToken.principalBalanceOf(address)
✓ Document
✓ Code
# (Match) function StableDebtToken.getTotalSupplyLastUpdated()
✓ Document
✓ Code
# (Match) function ILendingPool.finalizeTransfer(address,address,address,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function ILendingPool.getAddressesProvider()
✓ Document
✓ Code
# (Match) function IncentivizedERC20._setSymbol(string)
✓ Document
✓ Code
# (Match) function VersionedInitializable.getRevision()
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._allowances
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._balances
✓ Document
✓ Code
# (Match) IncentivizedERC20(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) contract IncentivizedERC20 inherits
✓ Document
✓ Code
# (Match) variable VersionedInitializable.______gap
✓ Document
✓ Code
# (Match) function VersionedInitializable.isConstructor()
✓ Document
✓ Code
# (Match) modifier VersionedInitializable.initializer
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._name
✓ Document
✓ Code
# (Match) variable VersionedInitializable.initializing
✓ Document
✓ Code
# (Match) variable VersionedInitializable.lastInitializedRevision
✓ Document
✓ Code
# (Match) contract VersionedInitializable inherits
✓ Document
✓ Code
# (Match) function ICreditDelegationToken.borrowAllowance(address,address)
✓ Document
✓ Code
# (Match) function ICreditDelegationToken.approveDelegation(address,uint256)
✓ Document
✓ Code
# (Match) event ICreditDelegationToken.BorrowAllowanceDelegated
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._totalSupply
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._symbol
✓ Document
✓ Code
# (Match) enum DataTypes.InterestRateMode
✓ Document
✓ Code
# (Match) function IncentivizedERC20.allowance(address,address)
✓ Document
✓ Code
# (Match) function IncentivizedERC20._setName(string)
✓ Document
✓ Code
# (Match) StableDebtToken(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.decreaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.increaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._decimals
✓ Document
✓ Code
# (Match) function IncentivizedERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.totalSupply()
✓ Document
✓ Code
# (Match) function IncentivizedERC20.decimals()
✓ Document
✓ Code
# (Match) function IncentivizedERC20.symbol()
✓ Document
✓ Code
# (Match) function IncentivizedERC20.name()
✓ Document
✓ Code
# (Match) function IncentivizedERC20.<constructor>(string,string,uint8,address)
✓ Document
✓ Code
# (Match) contract ICreditDelegationToken inherits
✓ Document
✓ Code
# (Match) struct DataTypes.UserConfigurationMap
✓ Document
✓ Code
# (Match) function ILendingPool.setPause(bool)
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolCollateralManagerUpdated
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setMarketId(string)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getMarketId()
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.AddressSet
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ProxyCreated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingRateOracleUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.PriceOracleUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolConfiguratorUpdated
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddressAsProxy(bytes32,address)
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.EmergencyAdminUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ConfigurationAdminUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.MarketIdSet
✓ Document
✓ Code
# (Match) contract ILendingPoolAddressesProvider inherits
✓ Document
✓ Code
# (Match) function ILendingPool.paused()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddress(bytes32,address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getAddress(bytes32)
✓ Document
✓ Code
# (Match) struct DataTypes.ReserveConfigurationMap
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setEmergencyAdmin(address)
✓ Document
✓ Code
# (Match) struct DataTypes.ReserveData
✓ Document
✓ Code
# (Match) contract DataTypes inherits
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingRateOracle(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingRateOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPriceOracle(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPriceOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getEmergencyAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPool()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPoolAdmin(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPoolAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolCollateralManager(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolCollateralManager()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolConfiguratorImpl(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolConfigurator()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolImpl(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.principalBalanceOf(address)
✓ Document
✓ Code

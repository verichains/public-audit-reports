# (Match) contract AaveProtocolDataProvider inherits
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_BALANCE_IS_0
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getParamsMemory(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getFlagsMemory(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) contract Errors inherits
✓ Document
✓ Code
# (Match) variable Errors.CALLER_NOT_POOL_ADMIN
✓ Document
✓ Code
# (Match) variable Errors.BORROW_ALLOWANCE_NOT_ENOUGH
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_ACTIVE_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_RESERVE_FROZEN
✓ Document
✓ Code
# (Match) variable Errors.VL_CURRENT_AVAILABLE_LIQUIDITY_NOT_ENOUGH
✓ Document
✓ Code
# (Match) variable Errors.VL_NOT_ENOUGH_AVAILABLE_USER_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.VL_TRANSFER_NOT_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.VL_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_INTEREST_RATE_MODE_SELECTED
✓ Document
✓ Code
# (Match) variable Errors.VL_HEALTH_FACTOR_LOWER_THAN_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getFlags(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_CANNOT_COVER_NEW_BORROW
✓ Document
✓ Code
# (Match) variable Errors.VL_STABLE_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_SAME_AS_BORROWING_CURRENCY
✓ Document
✓ Code
# (Match) variable Errors.VL_AMOUNT_BIGGER_THAN_MAX_LOAN_SIZE_STABLE
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_DEBT_OF_SELECTED_TYPE
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_EXPLICIT_AMOUNT_TO_REPAY_ON_BEHALF
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_STABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_VARIABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_UNDERLYING_BALANCE_NOT_GREATER_THAN_0
✓ Document
✓ Code
# (Match) variable Errors.VL_DEPOSIT_ALREADY_IN_USE
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_STABLE_BORROW_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.LP_INTEREST_RATE_REBALANCE_CONDITIONS_NOT_MET
✓ Document
✓ Code
# (Match) variable Errors.LP_LIQUIDATION_CALL_FAILED
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getParams(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getReserveFactor(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) variable Errors.LP_REQUESTED_AMOUNT_TOO_SMALL
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getLtv(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_BONUS_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.RESERVE_DECIMALS_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.IS_ACTIVE_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.IS_FROZEN_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.BORROWING_ENABLED_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.STABLE_BORROWING_ENABLED_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.RESERVE_FACTOR_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_LTV
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_LIQUIDATION_BONUS
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_DECIMALS
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_RESERVE_FACTOR
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setLtv(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setLiquidationThreshold(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setReserveFactor(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getLiquidationThreshold(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setLiquidationBonus(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getLiquidationBonus(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setDecimals(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getDecimals(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setActive(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getActive(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setFrozen(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getFrozen(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setBorrowingEnabled(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getBorrowingEnabled(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setStableRateBorrowingEnabled(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getStableRateBorrowingEnabled(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_LIQUIDITY_TO_BORROW
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PROTOCOL_ACTUAL_BALANCE
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.RESERVE_FACTOR_MASK
✓ Document
✓ Code
# (Match) variable Errors.VL_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_COLLATERAL_SWAP
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_EQUAL_ASSETS_TO_SWAP
✓ Document
✓ Code
# (Match) variable Errors.LP_REENTRANCY_NOT_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_MUST_BE_AN_ATOKEN
✓ Document
✓ Code
# (Match) variable Errors.LP_IS_PAUSED
✓ Document
✓ Code
# (Match) variable Errors.LP_NO_MORE_RESERVES_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASH_LOAN_EXECUTOR_RETURN
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LTV
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_BONUS
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_DECIMALS
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_RESERVE_FACTOR
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PARAMS_LENGTH
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_REPAY_WITH_COLLATERAL
✓ Document
✓ Code
# (Match) variable Errors.UL_INVALID_INDEX
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_CONTRACT
✓ Document
✓ Code
# (Match) variable Errors.SDT_STABLE_DEBT_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.SDT_BURN_EXCEEDS_BALANCE
✓ Document
✓ Code
# (Match) enum Errors.CollateralManagerErrors
✓ Document
✓ Code
# (Match) contract UserConfiguration inherits
✓ Document
✓ Code
# (Match) variable UserConfiguration.BORROWING_MASK
✓ Document
✓ Code
# (Match) function UserConfiguration.setBorrowing(struct DataTypes.UserConfigurationMap,uint256,bool)
✓ Document
✓ Code
# (Match) function UserConfiguration.setUsingAsCollateral(struct DataTypes.UserConfigurationMap,uint256,bool)
✓ Document
✓ Code
# (Match) function UserConfiguration.isUsingAsCollateralOrBorrowing(struct DataTypes.UserConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function UserConfiguration.isBorrowing(struct DataTypes.UserConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function UserConfiguration.isUsingAsCollateral(struct DataTypes.UserConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function UserConfiguration.isBorrowingAny(struct DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_BURN_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_MINT_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_NOT_LENDING_POOL_CONFIGURATOR
✓ Document
✓ Code
# (Match) variable Errors.LPC_CALLER_NOT_EMERGENCY_ADMIN
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable Errors.CT_CALLER_MUST_BE_LENDING_POOL
✓ Document
✓ Code
# (Match) variable Errors.CT_CANNOT_GIVE_ALLOWANCE_TO_HIMSELF
✓ Document
✓ Code
# (Match) variable Errors.CT_TRANSFER_AMOUNT_NOT_GT_0
✓ Document
✓ Code
# (Match) variable Errors.RL_RESERVE_ALREADY_INITIALIZED
✓ Document
✓ Code
# (Match) variable Errors.LPC_RESERVE_LIQUIDITY_NOT_0
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ATOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_CONFIGURATION
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_PROVIDER_NOT_REGISTERED
✓ Document
✓ Code
# (Match) variable Errors.RL_STABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.LPCM_HEALTH_FACTOR_NOT_BELOW_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.LPCM_COLLATERAL_CANNOT_BE_LIQUIDATED
✓ Document
✓ Code
# (Match) variable Errors.LPCM_SPECIFIED_CURRENCY_NOT_BORROWED_BY_USER
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NOT_ENOUGH_LIQUIDITY_TO_LIQUIDATE
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NO_ERRORS
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASHLOAN_MODE
✓ Document
✓ Code
# (Match) variable Errors.MATH_MULTIPLICATION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.MATH_ADDITION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.MATH_DIVISION_BY_ZERO
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_THRESHOLD_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.STABLE_BORROWING_MASK
✓ Document
✓ Code
# (Match) AaveProtocolDataProvider(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolCollateralManager()
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.PriceOracleUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingRateOracleUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ProxyCreated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.AddressSet
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getMarketId()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setMarketId(string)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddress(bytes32,address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddressAsProxy(bytes32,address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getAddress(bytes32)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPool()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolImpl(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolConfigurator()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolConfiguratorImpl(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolCollateralManager(address)
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolConfiguratorUpdated
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPoolAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPoolAdmin(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getEmergencyAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setEmergencyAdmin(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPriceOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPriceOracle(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingRateOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingRateOracle(address)
✓ Document
✓ Code
# (Match) contract ILendingPool inherits
✓ Document
✓ Code
# (Match) event ILendingPool.Deposit
✓ Document
✓ Code
# (Match) event ILendingPool.Withdraw
✓ Document
✓ Code
# (Match) event ILendingPool.Borrow
✓ Document
✓ Code
# (Match) event ILendingPool.Repay
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolCollateralManagerUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.EmergencyAdminUpdated
✓ Document
✓ Code
# (Match) event ILendingPool.ReserveUsedAsCollateralEnabled
✓ Document
✓ Code
# (Match) function IERC20Detailed.name()
✓ Document
✓ Code
# (Match) AaveProtocolDataProvider(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) variable AaveProtocolDataProvider.MKR
✓ Document
✓ Code
# (Match) variable AaveProtocolDataProvider.ETH
✓ Document
✓ Code
# (Match) struct AaveProtocolDataProvider.TokenData
✓ Document
✓ Code
# (Match) variable AaveProtocolDataProvider.ADDRESSES_PROVIDER
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.<constructor>(contract ILendingPoolAddressesProvider)
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getAllReservesTokens()
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getAllATokens()
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getReserveConfigurationData(address)
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getReserveData(address)
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getUserReserveData(address,address)
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getReserveTokensAddresses(address)
✓ Document
✓ Code
# (Match) contract IERC20Detailed inherits
✓ Document
✓ Code
# (Match) function IERC20Detailed.symbol()
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ConfigurationAdminUpdated
✓ Document
✓ Code
# (Match) function IERC20Detailed.decimals()
✓ Document
✓ Code
# (Match) contract IERC20 inherits
✓ Document
✓ Code
# (Match) function IERC20.totalSupply()
✓ Document
✓ Code
# (Match) function IERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) function IERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.allowance(address,address)
✓ Document
✓ Code
# (Match) function IERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) event IERC20.Transfer
✓ Document
✓ Code
# (Match) event IERC20.Approval
✓ Document
✓ Code
# (Match) contract ILendingPoolAddressesProvider inherits
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.MarketIdSet
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolUpdated
✓ Document
✓ Code
# (Match) event ILendingPool.Swap
✓ Document
✓ Code
# (Match) event ILendingPool.ReserveUsedAsCollateralDisabled
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.BORROWING_MASK
✓ Document
✓ Code
# (Match) event IVariableDebtToken.Mint
✓ Document
✓ Code
# (Match) contract IStableDebtToken inherits
✓ Document
✓ Code
# (Match) event IStableDebtToken.Mint
✓ Document
✓ Code
# (Match) event IStableDebtToken.Burn
✓ Document
✓ Code
# (Match) function IStableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function IStableDebtToken.burn(address,uint256)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getAverageStableRate()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getUserStableRate(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getUserLastUpdated(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getSupplyData()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getTotalSupplyLastUpdated()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getTotalSupplyAndAvgRate()
✓ Document
✓ Code
# (Match) function IStableDebtToken.principalBalanceOf(address)
✓ Document
✓ Code
# (Match) contract IVariableDebtToken inherits
✓ Document
✓ Code
# (Match) function IVariableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) struct DataTypes.UserConfigurationMap
✓ Document
✓ Code
# (Match) event IVariableDebtToken.Burn
✓ Document
✓ Code
# (Match) function IVariableDebtToken.burn(address,uint256,uint256)
✓ Document
✓ Code
# (Match) contract IScaledBalanceToken inherits
✓ Document
✓ Code
# (Match) function IScaledBalanceToken.scaledBalanceOf(address)
✓ Document
✓ Code
# (Match) function IScaledBalanceToken.getScaledUserBalanceAndSupply(address)
✓ Document
✓ Code
# (Match) function IScaledBalanceToken.scaledTotalSupply()
✓ Document
✓ Code
# (Match) contract ReserveConfiguration inherits
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LTV_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_THRESHOLD_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_BONUS_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.DECIMALS_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.ACTIVE_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.FROZEN_MASK
✓ Document
✓ Code
# (Match) enum DataTypes.InterestRateMode
✓ Document
✓ Code
# (Match) struct DataTypes.ReserveConfigurationMap
✓ Document
✓ Code
# (Match) event ILendingPool.RebalanceStableBorrowRate
✓ Document
✓ Code
# (Match) function ILendingPool.flashLoan(address,address[],uint256[],uint256[],address,bytes,uint16)
✓ Document
✓ Code
# (Match) event ILendingPool.FlashLoan
✓ Document
✓ Code
# (Match) event ILendingPool.Paused
✓ Document
✓ Code
# (Match) event ILendingPool.Unpaused
✓ Document
✓ Code
# (Match) event ILendingPool.LiquidationCall
✓ Document
✓ Code
# (Match) event ILendingPool.ReserveDataUpdated
✓ Document
✓ Code
# (Match) function ILendingPool.deposit(address,uint256,address,uint16)
✓ Document
✓ Code
# (Match) function ILendingPool.withdraw(address,uint256,address)
✓ Document
✓ Code
# (Match) function ILendingPool.borrow(address,uint256,uint256,uint16,address)
✓ Document
✓ Code
# (Match) function ILendingPool.repay(address,uint256,uint256,address)
✓ Document
✓ Code
# (Match) function ILendingPool.swapBorrowRateMode(address,uint256)
✓ Document
✓ Code
# (Match) function ILendingPool.rebalanceStableBorrowRate(address,address)
✓ Document
✓ Code
# (Match) function ILendingPool.setUserUseReserveAsCollateral(address,bool)
✓ Document
✓ Code
# (Match) function ILendingPool.liquidationCall(address,address,address,uint256,bool)
✓ Document
✓ Code
# (Match) function ILendingPool.getUserAccountData(address)
✓ Document
✓ Code
# (Match) struct DataTypes.ReserveData
✓ Document
✓ Code
# (Match) function ILendingPool.initReserve(address,address,address,address,address)
✓ Document
✓ Code
# (Match) function ILendingPool.setReserveInterestRateStrategyAddress(address,address)
✓ Document
✓ Code
# (Match) function ILendingPool.setConfiguration(address,uint256)
✓ Document
✓ Code
# (Match) function ILendingPool.getConfiguration(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getUserConfiguration(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getReserveNormalizedIncome(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getReserveNormalizedVariableDebt(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getReserveData(address)
✓ Document
✓ Code
# (Match) function ILendingPool.finalizeTransfer(address,address,address,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function ILendingPool.getReservesList()
✓ Document
✓ Code
# (Match) function ILendingPool.getAddressesProvider()
✓ Document
✓ Code
# (Match) function ILendingPool.setPause(bool)
✓ Document
✓ Code
# (Match) function ILendingPool.paused()
✓ Document
✓ Code
# (Match) contract DataTypes inherits
✓ Document
✓ Code
# (Match) function UserConfiguration.isEmpty(struct DataTypes.UserConfigurationMap)
✓ Document
✓ Code

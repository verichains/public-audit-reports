# (Added) contract BaseUniswapAdapter
```solidity
 @title BaseUniswapAdapter
 @notice Implements the logic for performing assets swaps in Uniswap V2
 @author Aave*
```
```solidity
abstract contract BaseUniswapAdapter is FlashLoanReceiverBase, IBaseUniswapAdapter, Ownable
```
# (Added) BaseUniswapAdapter(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Added) BaseUniswapAdapter(using PercentageMath for uint256)
```solidity
using PercentageMath for uint256;
```
# (Added) BaseUniswapAdapter(using SafeERC20 for IERC20)
```solidity
using SafeERC20 for IERC20;
```
# (Added) contract IUniswapV2Router02
```solidity
interface IUniswapV2Router02
```
# (Added) contract IERC20WithPermit
```solidity
interface IERC20WithPermit is IERC20
```
# (Added) contract IBaseUniswapAdapter
```solidity
interface IBaseUniswapAdapter
```
# (Added) contract UniswapRepayAdapter
```solidity
 @title UniswapRepayAdapter
 @notice Uniswap V2 Adapter to perform a repay of a debt with collateral.
 @author Aave*
```
```solidity
contract UniswapRepayAdapter is BaseUniswapAdapter
```
# (Added) contract ChainLinkRegistry
```solidity
@title ChainLinkRegistry
 @author Aave
 @notice Proxy smart contract to get the price of an asset from a price source, with Chainlink Aggregator
         smart contracts as primary option
 - If the returned price by a Chainlink aggregator is <= 0, the call is forwarded to a fallbackOracle
 - Owned by the Aave governance system, allowed to add sources for assets, replace them
   and change the fallbackOracle
```
```solidity
contract ChainLinkRegistry is Ownable
```
# (Added) ChainLinkRegistry(using SafeERC20 for IERC20)
```solidity
using SafeERC20 for IERC20;
```
# (Added) contract Airdrop
```solidity
@title Airdrop
 @author Aave
 @notice Proxy smart contract to get the price of an asset from a price source, with Chainlink Aggregator
         smart contracts as primary option
 - If the returned price by a Chainlink aggregator is <= 0, the call is forwarded to a fallbackOracle
 - Owned by the Aave governance system, allowed to add sources for assets, replace them
   and change the fallbackOracle
```
```solidity
contract Airdrop is Ownable
```
# (Added) Airdrop(using StringUtils for )
```solidity
using StringUtils for *;
```
# (Added) contract MerkleProof
```solidity
 @dev These functions deal with verification of Merkle trees (hash trees),
```
```solidity
library MerkleProof
```
# (Added) contract StringUtils
```solidity
library StringUtils
```
# (Added) contract MockUniswapV2Router02
```solidity
contract MockUniswapV2Router02 is IUniswapV2Router02
```
# (Added) contract UniswapLiquiditySwapAdapter
```solidity
 @title UniswapLiquiditySwapAdapter
 @notice Uniswap V2 Adapter to swap liquidity.
 @author Aave*
```
```solidity
contract UniswapLiquiditySwapAdapter is BaseUniswapAdapter
```
# (Added) contract FlashLiquidationAdapter
```solidity
 @title UniswapLiquiditySwapAdapter
 @notice Uniswap V2 Adapter to swap liquidity.
 @author Aave*
```
```solidity
contract FlashLiquidationAdapter is BaseUniswapAdapter
```
# (Added) FlashLiquidationAdapter(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
```solidity
using ReserveConfiguration for DataTypes.ReserveConfigurationMap;
```
# (Added) contract PriceOracle
```solidity
contract PriceOracle is IPriceOracle
```
# (Added) PriceOracle(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Added) PriceOracle(using SafeMath for uint112)
```solidity
using SafeMath for uint112;
```
# (Added) contract IPriceOracle
```solidity
interface IPriceOracle
```
# (Added) contract AaveCollector
```solidity
 @title AaveIncentivesVault
 @notice Stores all the AAVE kept for incentives, just giving approval to the different
 systems that will pull AAVE funds for their specific use case
 @author Aave*
```
```solidity
contract AaveCollector is VersionedInitializable
```
# (Changed) function IncentivizedERC20._mint(address,uint256)
✓ Document
✘ Code
```solidity
@@ -10,6 +10,6 @@
     _balances[account] = oldAccountBalance.add(amount);
 
     if (address(_incentivesController) != address(0)) {
-      _incentivesController.handleAction(account, oldTotalSupply, oldAccountBalance);
+      _incentivesController.handleAction(account, oldAccountBalance, oldTotalSupply);
     }
   }
```
# (Changed) function LendingRateOracle.getMarketBorrowRate(address)
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function getMarketBorrowRate(address _asset) external override view returns (uint256) {
+function getMarketBorrowRate(address _asset) external view override returns (uint256) {
     return borrowRates[_asset];
   }
```
# (Changed) function ERC20.allowance(address,address)
✓ Document
✘ Code
```solidity
@@ -1,8 +1,8 @@
 function allowance(address owner, address spender)
     public
+    view
     virtual
     override
-    view
     returns (uint256)
   {
     return _allowances[owner][spender];
```
# (Changed) function ERC20.totalSupply()
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function totalSupply() public override view returns (uint256) {
+function totalSupply() public view override returns (uint256) {
     return _totalSupply;
   }
```
# (Changed) function IncentivizedERC20._burn(address,uint256)
✓ Document
✘ Code
```solidity
@@ -10,6 +10,6 @@
     _balances[account] = oldAccountBalance.sub(amount, 'ERC20: burn amount exceeds balance');
 
     if (address(_incentivesController) != address(0)) {
-      _incentivesController.handleAction(account, oldTotalSupply, oldAccountBalance);
+      _incentivesController.handleAction(account, oldAccountBalance, oldTotalSupply);
     }
   }
```
# (Changed) function BaseUpgradeabilityProxy._implementation()
✓ Document
✘ Code
```solidity
@@ -1,4 +1,4 @@
-function _implementation() internal override view returns (address impl) {
+function _implementation() internal view override returns (address impl) {
     bytes32 slot = IMPLEMENTATION_SLOT;
     //solium-disable-next-line
     assembly {
```
# (Changed) function StableDebtToken._mint(address,uint256,uint256)
✓ Document
✘ Code
```solidity
@@ -7,6 +7,6 @@
     _balances[account] = oldAccountBalance.add(amount);
 
     if (address(_incentivesController) != address(0)) {
-      _incentivesController.handleAction(account, oldTotalSupply, oldAccountBalance);
+      _incentivesController.handleAction(account, oldAccountBalance, oldTotalSupply);
     }
   }
```
# (Changed) function StableDebtToken._burn(address,uint256,uint256)
✓ Document
✘ Code
```solidity
@@ -7,6 +7,6 @@
     _balances[account] = oldAccountBalance.sub(amount, Errors.SDT_BURN_EXCEEDS_BALANCE);
 
     if (address(_incentivesController) != address(0)) {
-      _incentivesController.handleAction(account, oldTotalSupply, oldAccountBalance);
+      _incentivesController.handleAction(account, oldAccountBalance, oldTotalSupply);
     }
   }
```
# (Changed) function ERC20.balanceOf(address)
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function balanceOf(address account) public override view returns (uint256) {
+function balanceOf(address account) public view override returns (uint256) {
     return _balances[account];
   }
```
# (Changed) variable IncentivizedERC20._incentivesController
✓ Document
✘ Code
```solidity
@@ -1 +1 @@
-IAaveIncentivesController internal immutable _incentivesController
+IAaveIncentivesController internal _incentivesController
```
# (Changed) function Context._msgSender()
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function _msgSender() internal virtual view returns (address payable) {
+function _msgSender() internal view virtual returns (address payable) {
     return msg.sender;
   }
```
# (Changed) function Context._msgData()
✓ Document
✘ Code
```solidity
@@ -1,4 +1,4 @@
-function _msgData() internal virtual view returns (bytes memory) {
+function _msgData() internal view virtual returns (bytes memory) {
     this; // silence state mutability warning without generating bytecode - see https://github.com/ethereum/solidity/issues/2691
     return msg.data;
   }
```
# (Changed) function AaveOracle.getAssetPrice(address)
✓ Document
✘ Code
```solidity
@@ -1,4 +1,4 @@
-function getAssetPrice(address asset) public override view returns (uint256) {
+function getAssetPrice(address asset) public view override returns (uint256) {
     IChainlinkAggregator source = assetsSources[asset];
 
     if (asset == WETH) {
```
# (Changed) function IncentivizedERC20._transfer(address,address,uint256)
✓ Document
✘ Code
```solidity
@@ -15,9 +15,9 @@
 
     if (address(_incentivesController) != address(0)) {
       uint256 currentTotalSupply = _totalSupply;
-      _incentivesController.handleAction(sender, currentTotalSupply, oldSenderBalance);
+      _incentivesController.handleAction(sender, oldSenderBalance, currentTotalSupply);
       if (sender != recipient) {
-        _incentivesController.handleAction(recipient, currentTotalSupply, oldRecipientBalance);
+        _incentivesController.handleAction(recipient, oldRecipientBalance, currentTotalSupply);
       }
     }
   }
```
# (Changed) variable LendingPool.LENDINGPOOL_REVISION
✓ Document
✘ Code
```solidity
@@ -1 +1 @@
-uint256 public constant LENDINGPOOL_REVISION = 0x3
+uint256 public constant LENDINGPOOL_REVISION = 0x2
```
# (Changed) function Proxy._implementation()
✓ Document
✘ Code
```solidity
@@ -1 +1 @@
-function _implementation() internal virtual view returns (address);
+function _implementation() internal view virtual returns (address);
```
# (Match) function IncentivizedERC20._setDecimals(uint8)
✓ Document
✓ Code
# (Match) function IncentivizedERC20._beforeTokenTransfer(address,address,uint256)
✓ Document
✓ Code
# (Match) contract IAaveIncentivesController inherits
✓ Document
✓ Code
# (Match) function IncentivizedERC20._setSymbol(string)
✓ Document
✓ Code
# (Match) function IncentivizedERC20._setName(string)
✓ Document
✓ Code
# (Match) function IncentivizedERC20._approve(address,address,uint256)
✓ Document
✓ Code
# (Match) function IAaveIncentivesController.handleAction(address,uint256,uint256)
✓ Document
✓ Code
# (Match) contract MockAToken inherits
✓ Document
✓ Code
# (Match) contract Address inherits
✓ Document
✓ Code
# (Match) function MockAToken.<constructor>(contract LendingPool,address,address,string,string,address)
✓ Document
✓ Code
# (Match) function MockAToken.getRevision()
✓ Document
✓ Code
# (Match) function MockAToken.initialize(uint8,string,string)
✓ Document
✓ Code
# (Match) LendingPool(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) LendingPool(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) LendingPool(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) LendingPool(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) variable LendingPool.MAX_STABLE_RATE_BORROW_SIZE_PERCENT
✓ Document
✓ Code
# (Match) variable LendingPool.FLASHLOAN_PREMIUM_TOTAL
✓ Document
✓ Code
# (Match) variable LendingPool.MAX_NUMBER_RESERVES
✓ Document
✓ Code
# (Match) contract LendingPool inherits
✓ Document
✓ Code
# (Match) function IncentivizedERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.decreaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._name
✓ Document
✓ Code
# (Match) function AToken.scaledTotalSupply()
✓ Document
✓ Code
# (Match) function AToken.transferUnderlyingTo(address,uint256)
✓ Document
✓ Code
# (Match) function AToken.permit(address,address,uint256,uint256,uint8,bytes32,bytes32)
✓ Document
✓ Code
# (Match) function AToken._transfer(address,address,uint256,bool)
✓ Document
✓ Code
# (Match) function AToken._transfer(address,address,uint256)
✓ Document
✓ Code
# (Match) contract IncentivizedERC20 inherits
✓ Document
✓ Code
# (Match) IncentivizedERC20(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._balances
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._allowances
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._totalSupply
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._symbol
✓ Document
✓ Code
# (Match) function IncentivizedERC20.increaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) variable IncentivizedERC20._decimals
✓ Document
✓ Code
# (Match) function IncentivizedERC20.<constructor>(string,string,uint8,address)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.name()
✓ Document
✓ Code
# (Match) function IncentivizedERC20.symbol()
✓ Document
✓ Code
# (Match) function IncentivizedERC20.decimals()
✓ Document
✓ Code
# (Match) function IncentivizedERC20.totalSupply()
✓ Document
✓ Code
# (Match) function IncentivizedERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.allowance(address,address)
✓ Document
✓ Code
# (Match) function IncentivizedERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) modifier LendingPool.onlyLendingPoolConfigurator
✓ Document
✓ Code
# (Match) modifier LendingPool.whenNotPaused
✓ Document
✓ Code
# (Match) function LendingPool.initialize(contract ILendingPoolAddressesProvider)
✓ Document
✓ Code
# (Match) function LendingPool._whenNotPaused()
✓ Document
✓ Code
# (Match) function WETHGateway._safeTransferETH(address,uint256)
✓ Document
✓ Code
# (Match) contract WETHGateway inherits
✓ Document
✓ Code
# (Match) WETHGateway(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) WETHGateway(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) variable WETHGateway.WETH
✓ Document
✓ Code
# (Match) variable WETHGateway.POOL
✓ Document
✓ Code
# (Match) variable WETHGateway.aWETH
✓ Document
✓ Code
# (Match) function WETHGateway.<constructor>(address,address)
✓ Document
✓ Code
# (Match) function WETHGateway.depositETH(address,uint16)
✓ Document
✓ Code
# (Match) function WETHGateway.withdrawETH(uint256,address)
✓ Document
✓ Code
# (Match) function WETHGateway.repayETH(uint256,uint256,address)
✓ Document
✓ Code
# (Match) function WETHGateway.borrowETH(uint256,uint256,uint16)
✓ Document
✓ Code
# (Match) function WETHGateway.emergencyTokenTransfer(address,address,uint256)
✓ Document
✓ Code
# (Match) function LendingPool._executeBorrow(struct LendingPool.ExecuteBorrowParams)
✓ Document
✓ Code
# (Match) function WETHGateway.emergencyEtherTransfer(address,uint256)
✓ Document
✓ Code
# (Match) function WETHGateway.getWETHAddress()
✓ Document
✓ Code
# (Match) function WETHGateway.getAWETHAddress()
✓ Document
✓ Code
# (Match) function WETHGateway.getLendingPoolAddress()
✓ Document
✓ Code
# (Match) function WETHGateway.<receive>()
✓ Document
✓ Code
# (Match) function WETHGateway.<fallback>()
✓ Document
✓ Code
# (Match) contract IWETH inherits
✓ Document
✓ Code
# (Match) function IWETH.deposit()
✓ Document
✓ Code
# (Match) function IWETH.withdraw(uint256)
✓ Document
✓ Code
# (Match) function IWETH.approve(address,uint256)
✓ Document
✓ Code
# (Match) function IWETH.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) contract IWETHGateway inherits
✓ Document
✓ Code
# (Match) function LendingPool._addReserveToList(address)
✓ Document
✓ Code
# (Match) struct LendingPool.ExecuteBorrowParams
✓ Document
✓ Code
# (Match) function LendingPool._onlyLendingPoolConfigurator()
✓ Document
✓ Code
# (Match) function LendingPool.flashLoan(address,address[],uint256[],uint256[],address,bytes,uint16)
✓ Document
✓ Code
# (Match) function LendingPool.getRevision()
✓ Document
✓ Code
# (Match) function AToken.getScaledUserBalanceAndSupply(address)
✓ Document
✓ Code
# (Match) function LendingPool.deposit(address,uint256,address,uint16)
✓ Document
✓ Code
# (Match) function LendingPool.withdraw(address,uint256,address)
✓ Document
✓ Code
# (Match) function LendingPool.borrow(address,uint256,uint256,uint16,address)
✓ Document
✓ Code
# (Match) function LendingPool.repay(address,uint256,uint256,address)
✓ Document
✓ Code
# (Match) function LendingPool.swapBorrowRateMode(address,uint256)
✓ Document
✓ Code
# (Match) function LendingPool.rebalanceStableBorrowRate(address,address)
✓ Document
✓ Code
# (Match) function LendingPool.setUserUseReserveAsCollateral(address,bool)
✓ Document
✓ Code
# (Match) function LendingPool.liquidationCall(address,address,address,uint256,bool)
✓ Document
✓ Code
# (Match) struct LendingPool.FlashLoanLocalVars
✓ Document
✓ Code
# (Match) function LendingPool.getReserveData(address)
✓ Document
✓ Code
# (Match) function LendingPool.setPause(bool)
✓ Document
✓ Code
# (Match) function LendingPool.getUserAccountData(address)
✓ Document
✓ Code
# (Match) function LendingPool.getConfiguration(address)
✓ Document
✓ Code
# (Match) function LendingPool.getUserConfiguration(address)
✓ Document
✓ Code
# (Match) function LendingPool.getReserveNormalizedIncome(address)
✓ Document
✓ Code
# (Match) function LendingPool.getReserveNormalizedVariableDebt(address)
✓ Document
✓ Code
# (Match) function LendingPool.paused()
✓ Document
✓ Code
# (Match) function LendingPool.getReservesList()
✓ Document
✓ Code
# (Match) function LendingPool.getAddressesProvider()
✓ Document
✓ Code
# (Match) function LendingPool.finalizeTransfer(address,address,address,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function LendingPool.initReserve(address,address,address,address,address)
✓ Document
✓ Code
# (Match) function LendingPool.setReserveInterestRateStrategyAddress(address,address)
✓ Document
✓ Code
# (Match) function LendingPool.setConfiguration(address,uint256)
✓ Document
✓ Code
# (Match) function AToken.totalSupply()
✓ Document
✓ Code
# (Match) function AToken.mint(address,uint256,uint256)
✓ Document
✓ Code
# (Match) function AToken.scaledBalanceOf(address)
✓ Document
✓ Code
# (Match) DefaultReserveInterestRateStrategy(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) contract IERC20Detailed inherits
✓ Document
✓ Code
# (Match) function IERC20Detailed.name()
✓ Document
✓ Code
# (Match) function IERC20Detailed.symbol()
✓ Document
✓ Code
# (Match) function IERC20Detailed.decimals()
✓ Document
✓ Code
# (Match) contract IUiPoolDataProvider inherits
✓ Document
✓ Code
# (Match) struct IUiPoolDataProvider.AggregatedReserveData
✓ Document
✓ Code
# (Match) struct IUiPoolDataProvider.UserReserveData
✓ Document
✓ Code
# (Match) function IUiPoolDataProvider.getReservesData(contract ILendingPoolAddressesProvider,address)
✓ Document
✓ Code
# (Match) contract DefaultReserveInterestRateStrategy inherits
✓ Document
✓ Code
# (Match) DefaultReserveInterestRateStrategy(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) DefaultReserveInterestRateStrategy(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) variable DefaultReserveInterestRateStrategy.OPTIMAL_UTILIZATION_RATE
✓ Document
✓ Code
# (Match) function UiPoolDataProvider.getInterestRateStrategySlopes(contract DefaultReserveInterestRateStrategy)
✓ Document
✓ Code
# (Match) variable DefaultReserveInterestRateStrategy.EXCESS_UTILIZATION_RATE
✓ Document
✓ Code
# (Match) variable DefaultReserveInterestRateStrategy.addressesProvider
✓ Document
✓ Code
# (Match) variable DefaultReserveInterestRateStrategy._baseVariableBorrowRate
✓ Document
✓ Code
# (Match) variable DefaultReserveInterestRateStrategy._variableRateSlope1
✓ Document
✓ Code
# (Match) variable DefaultReserveInterestRateStrategy._variableRateSlope2
✓ Document
✓ Code
# (Match) variable DefaultReserveInterestRateStrategy._stableRateSlope1
✓ Document
✓ Code
# (Match) variable DefaultReserveInterestRateStrategy._stableRateSlope2
✓ Document
✓ Code
# (Match) function DefaultReserveInterestRateStrategy.<constructor>(contract ILendingPoolAddressesProvider,uint256,uint256,uint256,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function DefaultReserveInterestRateStrategy.variableRateSlope1()
✓ Document
✓ Code
# (Match) function DefaultReserveInterestRateStrategy.variableRateSlope2()
✓ Document
✓ Code
# (Match) function DefaultReserveInterestRateStrategy.stableRateSlope1()
✓ Document
✓ Code
# (Match) function UiPoolDataProvider.getReservesData(contract ILendingPoolAddressesProvider,address)
✓ Document
✓ Code
# (Match) variable UiPoolDataProvider.MOCK_USD_ADDRESS
✓ Document
✓ Code
# (Match) function DefaultReserveInterestRateStrategy.baseVariableBorrowRate()
✓ Document
✓ Code
# (Match) function Ownable.renounceOwnership()
✓ Document
✓ Code
# (Match) function AaveOracle._setAssetsSources(address[],address[])
✓ Document
✓ Code
# (Match) function AaveOracle._setFallbackOracle(address)
✓ Document
✓ Code
# (Match) function AaveOracle.getAssetsPrices(address[])
✓ Document
✓ Code
# (Match) function AaveOracle.getSourceOfAsset(address)
✓ Document
✓ Code
# (Match) function AaveOracle.getFallbackOracle()
✓ Document
✓ Code
# (Match) contract Ownable inherits
✓ Document
✓ Code
# (Match) variable Ownable._owner
✓ Document
✓ Code
# (Match) event Ownable.OwnershipTransferred
✓ Document
✓ Code
# (Match) function Ownable.<constructor>()
✓ Document
✓ Code
# (Match) function Ownable.owner()
✓ Document
✓ Code
# (Match) modifier Ownable.onlyOwner
✓ Document
✓ Code
# (Match) function Ownable.transferOwnership(address)
✓ Document
✓ Code
# (Match) UiPoolDataProvider(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) contract IChainlinkAggregator inherits
✓ Document
✓ Code
# (Match) function IChainlinkAggregator.latestAnswer()
✓ Document
✓ Code
# (Match) function IChainlinkAggregator.latestTimestamp()
✓ Document
✓ Code
# (Match) function IChainlinkAggregator.latestRound()
✓ Document
✓ Code
# (Match) function IChainlinkAggregator.getAnswer(uint256)
✓ Document
✓ Code
# (Match) function IChainlinkAggregator.getTimestamp(uint256)
✓ Document
✓ Code
# (Match) event IChainlinkAggregator.AnswerUpdated
✓ Document
✓ Code
# (Match) event IChainlinkAggregator.NewRound
✓ Document
✓ Code
# (Match) contract UiPoolDataProvider inherits
✓ Document
✓ Code
# (Match) UiPoolDataProvider(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) UiPoolDataProvider(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function DefaultReserveInterestRateStrategy.stableRateSlope2()
✓ Document
✓ Code
# (Match) function DefaultReserveInterestRateStrategy.getMaxVariableBorrowRate()
✓ Document
✓ Code
# (Match) function AToken.balanceOf(address)
✓ Document
✓ Code
# (Match) variable AToken.UNDERLYING_ASSET_ADDRESS
✓ Document
✓ Code
# (Match) function DelegationAwareAToken.delegateUnderlyingTo(address)
✓ Document
✓ Code
# (Match) contract IDelegationToken inherits
✓ Document
✓ Code
# (Match) function IDelegationToken.delegate(address)
✓ Document
✓ Code
# (Match) contract AToken inherits
✓ Document
✓ Code
# (Match) AToken(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) AToken(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) variable AToken.EIP712_REVISION
✓ Document
✓ Code
# (Match) variable AToken.EIP712_DOMAIN
✓ Document
✓ Code
# (Match) variable AToken.PERMIT_TYPEHASH
✓ Document
✓ Code
# (Match) variable AToken.UINT_MAX_VALUE
✓ Document
✓ Code
# (Match) variable AToken.ATOKEN_REVISION
✓ Document
✓ Code
# (Match) variable AToken.RESERVE_TREASURY_ADDRESS
✓ Document
✓ Code
# (Match) modifier DelegationAwareAToken.onlyPoolAdmin
✓ Document
✓ Code
# (Match) variable AToken.POOL
✓ Document
✓ Code
# (Match) variable AToken._nonces
✓ Document
✓ Code
# (Match) variable AToken.DOMAIN_SEPARATOR
✓ Document
✓ Code
# (Match) modifier AToken.onlyLendingPool
✓ Document
✓ Code
# (Match) function AToken.<constructor>(contract ILendingPool,address,address,string,string,address)
✓ Document
✓ Code
# (Match) function AToken.getRevision()
✓ Document
✓ Code
# (Match) function AToken.initialize(uint8,string,string)
✓ Document
✓ Code
# (Match) function AToken.burn(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function IWETHGateway.withdrawETH(uint256,address)
✓ Document
✓ Code
# (Match) function AToken.mintToTreasury(uint256,uint256)
✓ Document
✓ Code
# (Match) function AToken.transferOnLiquidation(address,address,uint256)
✓ Document
✓ Code
# (Match) function DelegationAwareAToken.<constructor>(contract ILendingPool,address,address,string,string,address)
✓ Document
✓ Code
# (Match) contract DelegationAwareAToken inherits
✓ Document
✓ Code
# (Match) struct DefaultReserveInterestRateStrategy.CalcInterestRatesLocalVars
✓ Document
✓ Code
# (Match) contract LendingPoolAddressesProviderRegistry inherits
✓ Document
✓ Code
# (Match) function DefaultReserveInterestRateStrategy.calculateInterestRates(address,uint256,uint256,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function DefaultReserveInterestRateStrategy._getOverallBorrowRate(uint256,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) contract ILendingRateOracle inherits
✓ Document
✓ Code
# (Match) function ILendingRateOracle.getMarketBorrowRate(address)
✓ Document
✓ Code
# (Match) function ILendingRateOracle.setMarketBorrowRate(address,uint256)
✓ Document
✓ Code
# (Match) contract LendingRateOracle inherits
✓ Document
✓ Code
# (Match) variable LendingRateOracle.borrowRates
✓ Document
✓ Code
# (Match) variable LendingRateOracle.liquidityRates
✓ Document
✓ Code
# (Match) function LendingRateOracle.setMarketBorrowRate(address,uint256)
✓ Document
✓ Code
# (Match) function LendingRateOracle.getMarketLiquidityRate(address)
✓ Document
✓ Code
# (Match) function LendingRateOracle.setMarketLiquidityRate(address,uint256)
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProviderRegistry._addressesProviders
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProviderRegistry.unregisterAddressesProvider(address)
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProviderRegistry._addressesProvidersList
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry.getAddressesProvidersList()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry.registerAddressesProvider(address,uint256)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry.unregisterAddressesProvider(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry.getAddressesProviderIdByAddress(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProviderRegistry._addToAddressesProvidersList(address)
✓ Document
✓ Code
# (Match) contract ILendingPoolAddressesProviderRegistry inherits
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProviderRegistry.AddressesProviderRegistered
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProviderRegistry.AddressesProviderUnregistered
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProviderRegistry.getAddressesProvidersList()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProviderRegistry.getAddressesProviderIdByAddress(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProviderRegistry.registerAddressesProvider(address,uint256)
✓ Document
✓ Code
# (Match) function IWETHGateway.depositETH(address,uint16)
✓ Document
✓ Code
# (Match) contract LendingPoolConfigurator inherits
✓ Document
✓ Code
# (Match) function IWETHGateway.repayETH(uint256,uint256,address)
✓ Document
✓ Code
# (Match) function MockStableDebtToken.getRevision()
✓ Document
✓ Code
# (Match) function StableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function StableDebtToken.burn(address,uint256)
✓ Document
✓ Code
# (Match) function StableDebtToken._calculateBalanceIncrease(address)
✓ Document
✓ Code
# (Match) function StableDebtToken.getSupplyData()
✓ Document
✓ Code
# (Match) function StableDebtToken.getTotalSupplyAndAvgRate()
✓ Document
✓ Code
# (Match) function StableDebtToken.totalSupply()
✓ Document
✓ Code
# (Match) function StableDebtToken.getTotalSupplyLastUpdated()
✓ Document
✓ Code
# (Match) function StableDebtToken.principalBalanceOf(address)
✓ Document
✓ Code
# (Match) function StableDebtToken._calcTotalSupply(uint256)
✓ Document
✓ Code
# (Match) contract MockStableDebtToken inherits
✓ Document
✓ Code
# (Match) function MockStableDebtToken.<constructor>(address,address,string,string,address)
✓ Document
✓ Code
# (Match) contract StableAndVariableTokensHelper inherits
✓ Document
✓ Code
# (Match) function StableDebtToken.balanceOf(address)
✓ Document
✓ Code
# (Match) variable StableAndVariableTokensHelper.pool
✓ Document
✓ Code
# (Match) variable StableAndVariableTokensHelper.addressesProvider
✓ Document
✓ Code
# (Match) event StableAndVariableTokensHelper.deployedContracts
✓ Document
✓ Code
# (Match) function StableAndVariableTokensHelper.<constructor>(address payable,address)
✓ Document
✓ Code
# (Match) function StableAndVariableTokensHelper.initDeployment(address[],string[],address)
✓ Document
✓ Code
# (Match) function StableAndVariableTokensHelper.setOracleBorrowRates(address[],uint256[],address)
✓ Document
✓ Code
# (Match) function StableAndVariableTokensHelper.setOracleOwnership(address,address)
✓ Document
✓ Code
# (Match) contract StringLib inherits
✓ Document
✓ Code
# (Match) function StringLib.concat(string,string)
✓ Document
✓ Code
# (Match) contract ATokensAndRatesHelper inherits
✓ Document
✓ Code
# (Match) variable ATokensAndRatesHelper.pool
✓ Document
✓ Code
# (Match) struct StableDebtToken.MintLocalVars
✓ Document
✓ Code
# (Match) function StableDebtToken.getUserStableRate(address)
✓ Document
✓ Code
# (Match) variable ATokensAndRatesHelper.poolConfigurator
✓ Document
✓ Code
# (Match) variable MintableDelegationERC20.delegatee
✓ Document
✓ Code
# (Match) event ICreditDelegationToken.BorrowAllowanceDelegated
✓ Document
✓ Code
# (Match) function ICreditDelegationToken.approveDelegation(address,uint256)
✓ Document
✓ Code
# (Match) function ICreditDelegationToken.borrowAllowance(address,address)
✓ Document
✓ Code
# (Match) contract MockVariableDebtToken inherits
✓ Document
✓ Code
# (Match) function MockVariableDebtToken.<constructor>(address,address,string,string,address)
✓ Document
✓ Code
# (Match) function MockVariableDebtToken.getRevision()
✓ Document
✓ Code
# (Match) contract IExchangeAdapter inherits
✓ Document
✓ Code
# (Match) event IExchangeAdapter.Exchange
✓ Document
✓ Code
# (Match) function IExchangeAdapter.approveExchange(contract IERC20[])
✓ Document
✓ Code
# (Match) function IExchangeAdapter.exchange(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) contract MintableDelegationERC20 inherits
✓ Document
✓ Code
# (Match) function MintableDelegationERC20.<constructor>(string,string,uint8)
✓ Document
✓ Code
# (Match) function StableDebtToken.getUserLastUpdated(address)
✓ Document
✓ Code
# (Match) function MintableDelegationERC20.mint(uint256)
✓ Document
✓ Code
# (Match) function MintableDelegationERC20.delegate(address)
✓ Document
✓ Code
# (Match) contract StableDebtToken inherits
✓ Document
✓ Code
# (Match) StableDebtToken(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) variable StableDebtToken.DEBT_TOKEN_REVISION
✓ Document
✓ Code
# (Match) variable StableDebtToken._avgStableRate
✓ Document
✓ Code
# (Match) variable StableDebtToken._timestamps
✓ Document
✓ Code
# (Match) variable StableDebtToken._usersStableRate
✓ Document
✓ Code
# (Match) variable StableDebtToken._totalSupplyTimestamp
✓ Document
✓ Code
# (Match) function StableDebtToken.<constructor>(address,address,string,string,address)
✓ Document
✓ Code
# (Match) function StableDebtToken.getRevision()
✓ Document
✓ Code
# (Match) function StableDebtToken.getAverageStableRate()
✓ Document
✓ Code
# (Match) variable ATokensAndRatesHelper.addressesProvider
✓ Document
✓ Code
# (Match) event ATokensAndRatesHelper.deployedContracts
✓ Document
✓ Code
# (Match) function DebtTokenBase._decreaseBorrowAllowance(address,address,uint256)
✓ Document
✓ Code
# (Match) modifier BaseAdminUpgradeabilityProxy.ifAdmin
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getPriceOracle()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setPriceOracle(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getLendingRateOracle()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setLendingRateOracle(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider._updateImpl(bytes32,address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider._setMarketId(string)
✓ Document
✓ Code
# (Match) contract UpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) function UpgradeabilityProxy.<constructor>(address,bytes)
✓ Document
✓ Code
# (Match) contract BaseAdminUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) event BaseAdminUpgradeabilityProxy.AdminChanged
✓ Document
✓ Code
# (Match) variable BaseAdminUpgradeabilityProxy.ADMIN_SLOT
✓ Document
✓ Code
# (Match) function BaseAdminUpgradeabilityProxy.admin()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getEmergencyAdmin()
✓ Document
✓ Code
# (Match) function BaseAdminUpgradeabilityProxy.implementation()
✓ Document
✓ Code
# (Match) function BaseAdminUpgradeabilityProxy.changeAdmin(address)
✓ Document
✓ Code
# (Match) function BaseAdminUpgradeabilityProxy.upgradeTo(address)
✓ Document
✓ Code
# (Match) function BaseAdminUpgradeabilityProxy.upgradeToAndCall(address,bytes)
✓ Document
✓ Code
# (Match) function BaseAdminUpgradeabilityProxy._admin()
✓ Document
✓ Code
# (Match) function BaseAdminUpgradeabilityProxy._setAdmin(address)
✓ Document
✓ Code
# (Match) function BaseAdminUpgradeabilityProxy._willFallback()
✓ Document
✓ Code
# (Match) contract InitializableAdminUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) function InitializableAdminUpgradeabilityProxy.initialize(address,address,bytes)
✓ Document
✓ Code
# (Match) function InitializableAdminUpgradeabilityProxy._willFallback()
✓ Document
✓ Code
# (Match) contract AdminUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) function AdminUpgradeabilityProxy.<constructor>(address,address,bytes)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setEmergencyAdmin(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setPoolAdmin(address)
✓ Document
✓ Code
# (Match) function ATokensAndRatesHelper.<constructor>(address payable,address,address)
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.PRICE_ORACLE
✓ Document
✓ Code
# (Match) function ATokensAndRatesHelper.initDeployment(address[],string[],uint256[6][],address,address)
✓ Document
✓ Code
# (Match) function ATokensAndRatesHelper.initReserve(address[],address[],address[],address[],uint8[])
✓ Document
✓ Code
# (Match) function ATokensAndRatesHelper.configureReserves(address[],uint256[],uint256[],uint256[],uint256[],bool[])
✓ Document
✓ Code
# (Match) contract LendingPoolAddressesProvider inherits
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider._marketId
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider._addresses
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.LENDING_POOL
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.LENDING_POOL_CONFIGURATOR
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.POOL_ADMIN
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.EMERGENCY_ADMIN
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.LENDING_POOL_COLLATERAL_MANAGER
✓ Document
✓ Code
# (Match) variable LendingPoolAddressesProvider.LENDING_RATE_ORACLE
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getPoolAdmin()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.<constructor>(string)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getMarketId()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setMarketId(string)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setAddressAsProxy(bytes32,address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setAddress(bytes32,address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getAddress(bytes32)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getLendingPool()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setLendingPoolImpl(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getLendingPoolConfigurator()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setLendingPoolConfiguratorImpl(address)
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.getLendingPoolCollateralManager()
✓ Document
✓ Code
# (Match) function LendingPoolAddressesProvider.setLendingPoolCollateralManager(address)
✓ Document
✓ Code
# (Match) contract ICreditDelegationToken inherits
✓ Document
✓ Code
# (Match) function DebtTokenBase.decreaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) function IWETHGateway.borrowETH(uint256,uint256,uint16)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.setReserveFactor(address,uint256)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.updateStableDebtToken(address,address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.updateVariableDebtToken(address,address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.enableBorrowingOnReserve(address,bool)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.disableBorrowingOnReserve(address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.configureReserveAsCollateral(address,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.enableReserveStableRate(address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.disableReserveStableRate(address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.activateReserve(address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.deactivateReserve(address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.freezeReserve(address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.unfreezeReserve(address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.setReserveInterestRateStrategyAddress(address,address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.initReserve(address,address,address,uint8,address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.setPoolPause(bool)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator._initTokenWithProxy(address,uint8)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator._upgradeTokenImplementation(address,address,address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator._checkNoLiquidity(address)
✓ Document
✓ Code
# (Match) contract InitializableImmutableAdminUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) function InitializableImmutableAdminUpgradeabilityProxy.<constructor>(address)
✓ Document
✓ Code
# (Match) function InitializableImmutableAdminUpgradeabilityProxy._willFallback()
✓ Document
✓ Code
# (Match) contract ITokenConfiguration inherits
✓ Document
✓ Code
# (Match) function ITokenConfiguration.UNDERLYING_ASSET_ADDRESS()
✓ Document
✓ Code
# (Match) function ITokenConfiguration.POOL()
✓ Document
✓ Code
# (Match) contract BaseImmutableAdminUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) variable BaseImmutableAdminUpgradeabilityProxy.ADMIN
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.updateAToken(address,address)
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.initialize(contract ILendingPoolAddressesProvider)
✓ Document
✓ Code
# (Match) modifier BaseImmutableAdminUpgradeabilityProxy.ifAdmin
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.ReserveDeactivated
✓ Document
✓ Code
# (Match) function AaveOracle.setAssetSources(address[],address[])
✓ Document
✓ Code
# (Match) LendingPoolConfigurator(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) LendingPoolConfigurator(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) LendingPoolConfigurator(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.ReserveInitialized
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.BorrowingEnabledOnReserve
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.BorrowingDisabledOnReserve
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.CollateralConfigurationChanged
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.StableRateEnabledOnReserve
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.StableRateDisabledOnReserve
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.ReserveActivated
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.ReserveFrozen
✓ Document
✓ Code
# (Match) function LendingPoolConfigurator.getRevision()
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.ReserveUnfrozen
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.ReserveFactorChanged
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.ReserveDecimalsChanged
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.ReserveInterestRateStrategyChanged
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.ATokenUpgraded
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.StableDebtTokenUpgraded
✓ Document
✓ Code
# (Match) event LendingPoolConfigurator.VariableDebtTokenUpgraded
✓ Document
✓ Code
# (Match) variable LendingPoolConfigurator.addressesProvider
✓ Document
✓ Code
# (Match) variable LendingPoolConfigurator.pool
✓ Document
✓ Code
# (Match) modifier LendingPoolConfigurator.onlyPoolAdmin
✓ Document
✓ Code
# (Match) modifier LendingPoolConfigurator.onlyEmergencyAdmin
✓ Document
✓ Code
# (Match) variable LendingPoolConfigurator.CONFIGURATOR_REVISION
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.<constructor>(address)
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.admin()
✓ Document
✓ Code
# (Match) function DebtTokenBase.increaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) function VariableDebtToken.getScaledUserBalanceAndSupply(address)
✓ Document
✓ Code
# (Match) contract VariableDebtToken inherits
✓ Document
✓ Code
# (Match) VariableDebtToken(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) variable VariableDebtToken.DEBT_TOKEN_REVISION
✓ Document
✓ Code
# (Match) function VariableDebtToken.<constructor>(address,address,string,string,address)
✓ Document
✓ Code
# (Match) function VariableDebtToken.getRevision()
✓ Document
✓ Code
# (Match) function VariableDebtToken.balanceOf(address)
✓ Document
✓ Code
# (Match) function VariableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function VariableDebtToken.burn(address,uint256,uint256)
✓ Document
✓ Code
# (Match) function VariableDebtToken.scaledBalanceOf(address)
✓ Document
✓ Code
# (Match) function VariableDebtToken.totalSupply()
✓ Document
✓ Code
# (Match) function VariableDebtToken.scaledTotalSupply()
✓ Document
✓ Code
# (Match) contract DebtTokenBase inherits
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getUserReserveData(address,address)
✓ Document
✓ Code
# (Match) variable DebtTokenBase.UNDERLYING_ASSET_ADDRESS
✓ Document
✓ Code
# (Match) variable DebtTokenBase.POOL
✓ Document
✓ Code
# (Match) variable DebtTokenBase._borrowAllowances
✓ Document
✓ Code
# (Match) modifier DebtTokenBase.onlyLendingPool
✓ Document
✓ Code
# (Match) function DebtTokenBase.<constructor>(address,address,string,string,address)
✓ Document
✓ Code
# (Match) function DebtTokenBase.initialize(uint8,string,string)
✓ Document
✓ Code
# (Match) function DebtTokenBase.approveDelegation(address,uint256)
✓ Document
✓ Code
# (Match) function DebtTokenBase.borrowAllowance(address,address)
✓ Document
✓ Code
# (Match) function DebtTokenBase.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function DebtTokenBase.allowance(address,address)
✓ Document
✓ Code
# (Match) function DebtTokenBase.approve(address,uint256)
✓ Document
✓ Code
# (Match) function DebtTokenBase.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getReserveTokensAddresses(address)
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getReserveData(address)
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.implementation()
✓ Document
✓ Code
# (Match) function Proxy.<fallback>()
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.upgradeTo(address)
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy.upgradeToAndCall(address,bytes)
✓ Document
✓ Code
# (Match) function BaseImmutableAdminUpgradeabilityProxy._willFallback()
✓ Document
✓ Code
# (Match) contract InitializableUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) function InitializableUpgradeabilityProxy.initialize(address,bytes)
✓ Document
✓ Code
# (Match) contract BaseUpgradeabilityProxy inherits
✓ Document
✓ Code
# (Match) event BaseUpgradeabilityProxy.Upgraded
✓ Document
✓ Code
# (Match) variable BaseUpgradeabilityProxy.IMPLEMENTATION_SLOT
✓ Document
✓ Code
# (Match) function BaseUpgradeabilityProxy._upgradeTo(address)
✓ Document
✓ Code
# (Match) function BaseUpgradeabilityProxy._setImplementation(address)
✓ Document
✓ Code
# (Match) contract Proxy inherits
✓ Document
✓ Code
# (Match) function Proxy._delegate(address)
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getReserveConfigurationData(address)
✓ Document
✓ Code
# (Match) function Proxy._willFallback()
✓ Document
✓ Code
# (Match) function Proxy._fallback()
✓ Document
✓ Code
# (Match) contract AaveProtocolDataProvider inherits
✓ Document
✓ Code
# (Match) AaveProtocolDataProvider(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) AaveProtocolDataProvider(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) variable AaveProtocolDataProvider.MKR
✓ Document
✓ Code
# (Match) variable AaveProtocolDataProvider.ETH
✓ Document
✓ Code
# (Match) struct AaveProtocolDataProvider.TokenData
✓ Document
✓ Code
# (Match) variable AaveProtocolDataProvider.ADDRESSES_PROVIDER
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.<constructor>(contract ILendingPoolAddressesProvider)
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getAllReservesTokens()
✓ Document
✓ Code
# (Match) function AaveProtocolDataProvider.getAllATokens()
✓ Document
✓ Code
# (Match) function AaveOracle.setFallbackOracle(address)
✓ Document
✓ Code
# (Match) variable AaveOracle._fallbackOracle
✓ Document
✓ Code
# (Match) function AaveOracle.<constructor>(address[],address[],address,address)
✓ Document
✓ Code
# (Match) variable Errors.BORROW_ALLOWANCE_NOT_ENOUGH
✓ Document
✓ Code
# (Match) contract SafeMath inherits
✓ Document
✓ Code
# (Match) function SafeMath.add(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.mul(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256,string)
✓ Document
✓ Code
# (Match) contract Errors inherits
✓ Document
✓ Code
# (Match) variable Errors.CALLER_NOT_POOL_ADMIN
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_AMOUNT
✓ Document
✓ Code
# (Match) struct DataTypes.UserConfigurationMap
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_ACTIVE_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_RESERVE_FROZEN
✓ Document
✓ Code
# (Match) variable Errors.VL_CURRENT_AVAILABLE_LIQUIDITY_NOT_ENOUGH
✓ Document
✓ Code
# (Match) variable Errors.VL_NOT_ENOUGH_AVAILABLE_USER_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.VL_TRANSFER_NOT_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.VL_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_INTEREST_RATE_MODE_SELECTED
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_BALANCE_IS_0
✓ Document
✓ Code
# (Match) variable Errors.VL_HEALTH_FACTOR_LOWER_THAN_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_CANNOT_COVER_NEW_BORROW
✓ Document
✓ Code
# (Match) variable Errors.VL_STABLE_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) enum DataTypes.InterestRateMode
✓ Document
✓ Code
# (Match) struct DataTypes.ReserveConfigurationMap
✓ Document
✓ Code
# (Match) variable Errors.VL_AMOUNT_BIGGER_THAN_MAX_LOAN_SIZE_STABLE
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getActive(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_DECIMALS
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_RESERVE_FACTOR
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setLtv(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getLtv(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setLiquidationThreshold(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getLiquidationThreshold(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setLiquidationBonus(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getLiquidationBonus(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setDecimals(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getDecimals(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setActive(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setFrozen(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) struct DataTypes.ReserveData
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getFrozen(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setBorrowingEnabled(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getBorrowingEnabled(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setStableRateBorrowingEnabled(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getStableRateBorrowingEnabled(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setReserveFactor(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getReserveFactor(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getFlags(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getParams(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getParamsMemory(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getFlagsMemory(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) contract DataTypes inherits
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_SAME_AS_BORROWING_CURRENCY
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_DEBT_OF_SELECTED_TYPE
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_MINT_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NOT_ENOUGH_LIQUIDITY_TO_LIQUIDATE
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NO_ERRORS
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASHLOAN_MODE
✓ Document
✓ Code
# (Match) variable Errors.MATH_MULTIPLICATION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.MATH_ADDITION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.MATH_DIVISION_BY_ZERO
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_STABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_REPAY_WITH_COLLATERAL
✓ Document
✓ Code
# (Match) variable Errors.LPCM_COLLATERAL_CANNOT_BE_LIQUIDATED
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_BURN_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_COLLATERAL_SWAP
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_EQUAL_ASSETS_TO_SWAP
✓ Document
✓ Code
# (Match) variable Errors.LP_REENTRANCY_NOT_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_MUST_BE_AN_ATOKEN
✓ Document
✓ Code
# (Match) variable Errors.LP_IS_PAUSED
✓ Document
✓ Code
# (Match) variable Errors.LP_NO_MORE_RESERVES_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASH_LOAN_EXECUTOR_RETURN
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LTV
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_BONUS
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_DECIMALS
✓ Document
✓ Code
# (Match) variable Errors.LPCM_SPECIFIED_CURRENCY_NOT_BORROWED_BY_USER
✓ Document
✓ Code
# (Match) variable Errors.LPCM_HEALTH_FACTOR_NOT_BELOW_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_EXPLICIT_AMOUNT_TO_REPAY_ON_BEHALF
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_STABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_VARIABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_UNDERLYING_BALANCE_NOT_GREATER_THAN_0
✓ Document
✓ Code
# (Match) variable Errors.VL_DEPOSIT_ALREADY_IN_USE
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_STABLE_BORROW_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.LP_INTEREST_RATE_REBALANCE_CONDITIONS_NOT_MET
✓ Document
✓ Code
# (Match) variable Errors.LP_LIQUIDATION_CALL_FAILED
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_LIQUIDITY_TO_BORROW
✓ Document
✓ Code
# (Match) variable Errors.LP_REQUESTED_AMOUNT_TOO_SMALL
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PROTOCOL_ACTUAL_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_NOT_LENDING_POOL_CONFIGURATOR
✓ Document
✓ Code
# (Match) variable Errors.CT_CALLER_MUST_BE_LENDING_POOL
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_PROVIDER_NOT_REGISTERED
✓ Document
✓ Code
# (Match) variable Errors.CT_CANNOT_GIVE_ALLOWANCE_TO_HIMSELF
✓ Document
✓ Code
# (Match) variable Errors.CT_TRANSFER_AMOUNT_NOT_GT_0
✓ Document
✓ Code
# (Match) variable Errors.RL_RESERVE_ALREADY_INITIALIZED
✓ Document
✓ Code
# (Match) variable Errors.LPC_RESERVE_LIQUIDITY_NOT_0
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ATOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_CONFIGURATION
✓ Document
✓ Code
# (Match) variable Errors.LPC_CALLER_NOT_EMERGENCY_ADMIN
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_LIQUIDATION_BONUS
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_LTV
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolCollateralManager()
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ProxyCreated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.AddressSet
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getMarketId()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setMarketId(string)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddress(bytes32,address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddressAsProxy(bytes32,address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getAddress(bytes32)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPool()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolImpl(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolConfigurator()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolConfiguratorImpl(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolCollateralManager(address)
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.PriceOracleUpdated
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPoolAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPoolAdmin(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getEmergencyAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setEmergencyAdmin(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPriceOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPriceOracle(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingRateOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingRateOracle(address)
✓ Document
✓ Code
# (Match) contract ILendingPool inherits
✓ Document
✓ Code
# (Match) event ILendingPool.Deposit
✓ Document
✓ Code
# (Match) event ILendingPool.Withdraw
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingRateOracleUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolCollateralManagerUpdated
✓ Document
✓ Code
# (Match) event ILendingPool.Repay
✓ Document
✓ Code
# (Match) contract IERC20 inherits
✓ Document
✓ Code
# (Match) function Address.sendValue(address payable,uint256)
✓ Document
✓ Code
# (Match) contract WalletBalanceProvider inherits
✓ Document
✓ Code
# (Match) WalletBalanceProvider(using Address for address payable)
✓ Document
✓ Code
# (Match) WalletBalanceProvider(using Address for address)
✓ Document
✓ Code
# (Match) WalletBalanceProvider(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) WalletBalanceProvider(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) variable WalletBalanceProvider.MOCK_ETH_ADDRESS
✓ Document
✓ Code
# (Match) function WalletBalanceProvider.<receive>()
✓ Document
✓ Code
# (Match) function WalletBalanceProvider.balanceOf(address,address)
✓ Document
✓ Code
# (Match) function WalletBalanceProvider.batchBalanceOf(address[],address[])
✓ Document
✓ Code
# (Match) function WalletBalanceProvider.getUserWalletBalances(address,address)
✓ Document
✓ Code
# (Match) function IERC20.totalSupply()
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolConfiguratorUpdated
✓ Document
✓ Code
# (Match) function IERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) function IERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.allowance(address,address)
✓ Document
✓ Code
# (Match) function IERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) event IERC20.Transfer
✓ Document
✓ Code
# (Match) event IERC20.Approval
✓ Document
✓ Code
# (Match) contract ILendingPoolAddressesProvider inherits
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.MarketIdSet
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ConfigurationAdminUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.EmergencyAdminUpdated
✓ Document
✓ Code
# (Match) event ILendingPool.Borrow
✓ Document
✓ Code
# (Match) event ILendingPool.Swap
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.RESERVE_FACTOR_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_BONUS_MASK
✓ Document
✓ Code
# (Match) function ILendingPool.paused()
✓ Document
✓ Code
# (Match) contract SafeERC20 inherits
✓ Document
✓ Code
# (Match) SafeERC20(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) SafeERC20(using Address for address)
✓ Document
✓ Code
# (Match) function SafeERC20.safeTransfer(contract IERC20,address,uint256)
✓ Document
✓ Code
# (Match) function SafeERC20.safeTransferFrom(contract IERC20,address,address,uint256)
✓ Document
✓ Code
# (Match) function SafeERC20.safeApprove(contract IERC20,address,uint256)
✓ Document
✓ Code
# (Match) function SafeERC20.callOptionalReturn(contract IERC20,bytes)
✓ Document
✓ Code
# (Match) contract ReserveConfiguration inherits
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LTV_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_THRESHOLD_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.DECIMALS_MASK
✓ Document
✓ Code
# (Match) function ILendingPool.getAddressesProvider()
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.ACTIVE_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.FROZEN_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.BORROWING_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.STABLE_BORROWING_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.RESERVE_FACTOR_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_THRESHOLD_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_BONUS_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.RESERVE_DECIMALS_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.IS_ACTIVE_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.IS_FROZEN_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.BORROWING_ENABLED_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.STABLE_BORROWING_ENABLED_START_BIT_POSITION
✓ Document
✓ Code
# (Match) function ILendingPool.setPause(bool)
✓ Document
✓ Code
# (Match) function ILendingPool.getReservesList()
✓ Document
✓ Code
# (Match) event ILendingPool.ReserveUsedAsCollateralEnabled
✓ Document
✓ Code
# (Match) function ILendingPool.swapBorrowRateMode(address,uint256)
✓ Document
✓ Code
# (Match) event ILendingPool.ReserveUsedAsCollateralDisabled
✓ Document
✓ Code
# (Match) event ILendingPool.RebalanceStableBorrowRate
✓ Document
✓ Code
# (Match) event ILendingPool.FlashLoan
✓ Document
✓ Code
# (Match) event ILendingPool.Paused
✓ Document
✓ Code
# (Match) event ILendingPool.Unpaused
✓ Document
✓ Code
# (Match) event ILendingPool.LiquidationCall
✓ Document
✓ Code
# (Match) event ILendingPool.ReserveDataUpdated
✓ Document
✓ Code
# (Match) function ILendingPool.deposit(address,uint256,address,uint16)
✓ Document
✓ Code
# (Match) function ILendingPool.withdraw(address,uint256,address)
✓ Document
✓ Code
# (Match) function ILendingPool.borrow(address,uint256,uint256,uint16,address)
✓ Document
✓ Code
# (Match) function ILendingPool.repay(address,uint256,uint256,address)
✓ Document
✓ Code
# (Match) function ILendingPool.rebalanceStableBorrowRate(address,address)
✓ Document
✓ Code
# (Match) function ILendingPool.finalizeTransfer(address,address,address,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function ILendingPool.setUserUseReserveAsCollateral(address,bool)
✓ Document
✓ Code
# (Match) function ILendingPool.liquidationCall(address,address,address,uint256,bool)
✓ Document
✓ Code
# (Match) function ILendingPool.flashLoan(address,address[],uint256[],uint256[],address,bytes,uint16)
✓ Document
✓ Code
# (Match) function ILendingPool.getUserAccountData(address)
✓ Document
✓ Code
# (Match) function ILendingPool.initReserve(address,address,address,address,address)
✓ Document
✓ Code
# (Match) function ILendingPool.setReserveInterestRateStrategyAddress(address,address)
✓ Document
✓ Code
# (Match) function ILendingPool.setConfiguration(address,uint256)
✓ Document
✓ Code
# (Match) function ILendingPool.getConfiguration(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getUserConfiguration(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getReserveNormalizedIncome(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getReserveNormalizedVariableDebt(address)
✓ Document
✓ Code
# (Match) function ILendingPool.getReserveData(address)
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_RESERVE_FACTOR
✓ Document
✓ Code
# (Match) variable Errors.VL_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable AaveOracle.WETH
✓ Document
✓ Code
# (Match) contract IReserveInterestRateStrategy inherits
✓ Document
✓ Code
# (Match) function ReserveLogic._mintToTreasury(struct DataTypes.ReserveData,uint256,uint256,uint256,uint256,uint40)
✓ Document
✓ Code
# (Match) function ReserveLogic._updateIndexes(struct DataTypes.ReserveData,uint256,uint256,uint256,uint40)
✓ Document
✓ Code
# (Match) contract UserConfiguration inherits
✓ Document
✓ Code
# (Match) variable UserConfiguration.BORROWING_MASK
✓ Document
✓ Code
# (Match) function UserConfiguration.setBorrowing(struct DataTypes.UserConfigurationMap,uint256,bool)
✓ Document
✓ Code
# (Match) function UserConfiguration.setUsingAsCollateral(struct DataTypes.UserConfigurationMap,uint256,bool)
✓ Document
✓ Code
# (Match) function UserConfiguration.isUsingAsCollateralOrBorrowing(struct DataTypes.UserConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function UserConfiguration.isBorrowing(struct DataTypes.UserConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function UserConfiguration.isUsingAsCollateral(struct DataTypes.UserConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function UserConfiguration.isBorrowingAny(struct DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) function UserConfiguration.isEmpty(struct DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) function IReserveInterestRateStrategy.baseVariableBorrowRate()
✓ Document
✓ Code
# (Match) function ReserveLogic.updateInterestRates(struct DataTypes.ReserveData,address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function IReserveInterestRateStrategy.getMaxVariableBorrowRate()
✓ Document
✓ Code
# (Match) function IReserveInterestRateStrategy.calculateInterestRates(address,uint256,uint256,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) contract MathUtils inherits
✓ Document
✓ Code
# (Match) MathUtils(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) MathUtils(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) variable MathUtils.SECONDS_PER_YEAR
✓ Document
✓ Code
# (Match) function MathUtils.calculateLinearInterest(uint256,uint40)
✓ Document
✓ Code
# (Match) function MathUtils.calculateCompoundedInterest(uint256,uint40,uint256)
✓ Document
✓ Code
# (Match) function MathUtils.calculateCompoundedInterest(uint256,uint40)
✓ Document
✓ Code
# (Match) contract MockFlashLoanReceiver inherits
✓ Document
✓ Code
# (Match) MockFlashLoanReceiver(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) struct ReserveLogic.MintToTreasuryLocalVars
✓ Document
✓ Code
# (Match) struct ReserveLogic.UpdateInterestRatesLocalVars
✓ Document
✓ Code
# (Match) event MockFlashLoanReceiver.ExecutedWithFail
✓ Document
✓ Code
# (Match) function IScaledBalanceToken.getScaledUserBalanceAndSupply(address)
✓ Document
✓ Code
# (Match) LendingPoolStorage(using ReserveLogic for DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) LendingPoolStorage(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) LendingPoolStorage(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._addressesProvider
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._reserves
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._usersConfig
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._reservesList
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._reservesCount
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._paused
✓ Document
✓ Code
# (Match) contract IScaledBalanceToken inherits
✓ Document
✓ Code
# (Match) function IScaledBalanceToken.scaledBalanceOf(address)
✓ Document
✓ Code
# (Match) function IScaledBalanceToken.scaledTotalSupply()
✓ Document
✓ Code
# (Match) function ReserveLogic.init(struct DataTypes.ReserveData,address,address,address,address)
✓ Document
✓ Code
# (Match) contract ReserveLogic inherits
✓ Document
✓ Code
# (Match) ReserveLogic(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) ReserveLogic(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) ReserveLogic(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) ReserveLogic(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) event ReserveLogic.ReserveDataUpdated
✓ Document
✓ Code
# (Match) ReserveLogic(using ReserveLogic for DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) ReserveLogic(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveLogic.getNormalizedIncome(struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) function ReserveLogic.getNormalizedDebt(struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) function ReserveLogic.updateState(struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) function ReserveLogic.cumulateToLiquidityIndex(struct DataTypes.ReserveData,uint256,uint256)
✓ Document
✓ Code
# (Match) variable MockFlashLoanReceiver._provider
✓ Document
✓ Code
# (Match) event MockFlashLoanReceiver.ExecutedWithSuccess
✓ Document
✓ Code
# (Match) function ValidationLogic.validateTransfer(address,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) function ERC20._transfer(address,address,uint256)
✓ Document
✓ Code
# (Match) variable ERC20._symbol
✓ Document
✓ Code
# (Match) variable ERC20._decimals
✓ Document
✓ Code
# (Match) function ERC20.<constructor>(string,string)
✓ Document
✓ Code
# (Match) function ERC20.name()
✓ Document
✓ Code
# (Match) function ERC20.symbol()
✓ Document
✓ Code
# (Match) function ERC20.decimals()
✓ Document
✓ Code
# (Match) function ERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function ERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) function ERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) function ERC20.increaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) function ERC20.decreaseAllowance(address,uint256)
✓ Document
✓ Code
# (Match) function ERC20._mint(address,uint256)
✓ Document
✓ Code
# (Match) variable ERC20._totalSupply
✓ Document
✓ Code
# (Match) function ERC20._burn(address,uint256)
✓ Document
✓ Code
# (Match) function ERC20._approve(address,address,uint256)
✓ Document
✓ Code
# (Match) function ERC20._setupDecimals(uint8)
✓ Document
✓ Code
# (Match) function ERC20._beforeTokenTransfer(address,address,uint256)
✓ Document
✓ Code
# (Match) contract Context inherits
✓ Document
✓ Code
# (Match) contract AaveOracle inherits
✓ Document
✓ Code
# (Match) AaveOracle(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) event AaveOracle.WethSet
✓ Document
✓ Code
# (Match) event AaveOracle.AssetSourceUpdated
✓ Document
✓ Code
# (Match) event AaveOracle.FallbackOracleUpdated
✓ Document
✓ Code
# (Match) variable AaveOracle.assetsSources
✓ Document
✓ Code
# (Match) function Address.isContract(address)
✓ Document
✓ Code
# (Match) variable ERC20._name
✓ Document
✓ Code
# (Match) variable ERC20._allowances
✓ Document
✓ Code
# (Match) variable MockFlashLoanReceiver._failExecution
✓ Document
✓ Code
# (Match) FlashLoanReceiverBase(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) variable MockFlashLoanReceiver._amountToApprove
✓ Document
✓ Code
# (Match) variable MockFlashLoanReceiver._simulateEOA
✓ Document
✓ Code
# (Match) function MockFlashLoanReceiver.<constructor>(contract ILendingPoolAddressesProvider)
✓ Document
✓ Code
# (Match) function MockFlashLoanReceiver.setFailExecutionTransfer(bool)
✓ Document
✓ Code
# (Match) function MockFlashLoanReceiver.setAmountToApprove(uint256)
✓ Document
✓ Code
# (Match) function MockFlashLoanReceiver.setSimulateEOA(bool)
✓ Document
✓ Code
# (Match) function MockFlashLoanReceiver.amountToApprove()
✓ Document
✓ Code
# (Match) function MockFlashLoanReceiver.simulateEOA()
✓ Document
✓ Code
# (Match) function MockFlashLoanReceiver.executeOperation(address[],uint256[],uint256[],address,bytes)
✓ Document
✓ Code
# (Match) contract FlashLoanReceiverBase inherits
✓ Document
✓ Code
# (Match) FlashLoanReceiverBase(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) variable FlashLoanReceiverBase.ADDRESSES_PROVIDER
✓ Document
✓ Code
# (Match) variable ERC20._balances
✓ Document
✓ Code
# (Match) variable FlashLoanReceiverBase.LENDING_POOL
✓ Document
✓ Code
# (Match) function FlashLoanReceiverBase.<constructor>(contract ILendingPoolAddressesProvider)
✓ Document
✓ Code
# (Match) contract MintableERC20 inherits
✓ Document
✓ Code
# (Match) function MintableERC20.<constructor>(string,string,uint8)
✓ Document
✓ Code
# (Match) function MintableERC20.mint(uint256)
✓ Document
✓ Code
# (Match) contract IFlashLoanReceiver inherits
✓ Document
✓ Code
# (Match) function IFlashLoanReceiver.executeOperation(address[],uint256[],uint256[],address,bytes)
✓ Document
✓ Code
# (Match) function IFlashLoanReceiver.ADDRESSES_PROVIDER()
✓ Document
✓ Code
# (Match) function IFlashLoanReceiver.LENDING_POOL()
✓ Document
✓ Code
# (Match) contract ERC20 inherits
✓ Document
✓ Code
# (Match) ERC20(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) ERC20(using Address for address)
✓ Document
✓ Code
# (Match) contract LendingPoolStorage inherits
✓ Document
✓ Code
# (Match) function ValidationLogic.validateLiquidationCall(struct DataTypes.ReserveData,struct DataTypes.ReserveData,struct DataTypes.UserConfigurationMap,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PARAMS_LENGTH
✓ Document
✓ Code
# (Match) event IVariableDebtToken.Burn
✓ Document
✓ Code
# (Match) function IStableDebtToken.burn(address,uint256)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getAverageStableRate()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getUserStableRate(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getUserLastUpdated(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getSupplyData()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getTotalSupplyLastUpdated()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getTotalSupplyAndAvgRate()
✓ Document
✓ Code
# (Match) function IStableDebtToken.principalBalanceOf(address)
✓ Document
✓ Code
# (Match) contract IVariableDebtToken inherits
✓ Document
✓ Code
# (Match) event IVariableDebtToken.Mint
✓ Document
✓ Code
# (Match) function IVariableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function IVariableDebtToken.burn(address,uint256,uint256)
✓ Document
✓ Code
# (Match) event IStableDebtToken.Burn
✓ Document
✓ Code
# (Match) contract IPriceOracleGetter inherits
✓ Document
✓ Code
# (Match) function IPriceOracleGetter.getAssetPrice(address)
✓ Document
✓ Code
# (Match) contract ILendingPoolCollateralManager inherits
✓ Document
✓ Code
# (Match) event ILendingPoolCollateralManager.LiquidationCall
✓ Document
✓ Code
# (Match) event ILendingPoolCollateralManager.ReserveUsedAsCollateralDisabled
✓ Document
✓ Code
# (Match) event ILendingPoolCollateralManager.ReserveUsedAsCollateralEnabled
✓ Document
✓ Code
# (Match) function ILendingPoolCollateralManager.liquidationCall(address,address,address,uint256,bool)
✓ Document
✓ Code
# (Match) contract VersionedInitializable inherits
✓ Document
✓ Code
# (Match) variable VersionedInitializable.lastInitializedRevision
✓ Document
✓ Code
# (Match) variable VersionedInitializable.initializing
✓ Document
✓ Code
# (Match) modifier VersionedInitializable.initializer
✓ Document
✓ Code
# (Match) function VersionedInitializable.getRevision()
✓ Document
✓ Code
# (Match) function IStableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) event IStableDebtToken.Mint
✓ Document
✓ Code
# (Match) variable VersionedInitializable.______gap
✓ Document
✓ Code
# (Match) struct LendingPoolCollateralManager.LiquidationCallLocalVars
✓ Document
✓ Code
# (Match) variable Errors.UL_INVALID_INDEX
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_CONTRACT
✓ Document
✓ Code
# (Match) variable Errors.SDT_STABLE_DEBT_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.SDT_BURN_EXCEEDS_BALANCE
✓ Document
✓ Code
# (Match) enum Errors.CollateralManagerErrors
✓ Document
✓ Code
# (Match) contract LendingPoolCollateralManager inherits
✓ Document
✓ Code
# (Match) LendingPoolCollateralManager(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) LendingPoolCollateralManager(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) LendingPoolCollateralManager(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) LendingPoolCollateralManager(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) variable LendingPoolCollateralManager.LIQUIDATION_CLOSE_FACTOR_PERCENT
✓ Document
✓ Code
# (Match) function LendingPoolCollateralManager.getRevision()
✓ Document
✓ Code
# (Match) contract IStableDebtToken inherits
✓ Document
✓ Code
# (Match) function LendingPoolCollateralManager.liquidationCall(address,address,address,uint256,bool)
✓ Document
✓ Code
# (Match) struct LendingPoolCollateralManager.AvailableCollateralToLiquidateLocalVars
✓ Document
✓ Code
# (Match) function LendingPoolCollateralManager._calculateAvailableCollateralToLiquidate(struct DataTypes.ReserveData,struct DataTypes.ReserveData,address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) contract IAToken inherits
✓ Document
✓ Code
# (Match) event IAToken.Mint
✓ Document
✓ Code
# (Match) function IAToken.mint(address,uint256,uint256)
✓ Document
✓ Code
# (Match) event IAToken.Burn
✓ Document
✓ Code
# (Match) event IAToken.BalanceTransfer
✓ Document
✓ Code
# (Match) function IAToken.burn(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function IAToken.mintToTreasury(uint256,uint256)
✓ Document
✓ Code
# (Match) function IAToken.transferOnLiquidation(address,address,uint256)
✓ Document
✓ Code
# (Match) function IAToken.transferUnderlyingTo(address,uint256)
✓ Document
✓ Code
# (Match) function VersionedInitializable.isConstructor()
✓ Document
✓ Code
# (Match) contract GenericLogic inherits
✓ Document
✓ Code
# (Match) function ValidationLogic.validateFlashloan(address[],uint256[])
✓ Document
✓ Code
# (Match) ValidationLogic(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.rayToWad(uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.wadToRay(uint256)
✓ Document
✓ Code
# (Match) contract PercentageMath inherits
✓ Document
✓ Code
# (Match) variable PercentageMath.PERCENTAGE_FACTOR
✓ Document
✓ Code
# (Match) variable PercentageMath.HALF_PERCENT
✓ Document
✓ Code
# (Match) function PercentageMath.percentMul(uint256,uint256)
✓ Document
✓ Code
# (Match) function PercentageMath.percentDiv(uint256,uint256)
✓ Document
✓ Code
# (Match) contract ValidationLogic inherits
✓ Document
✓ Code
# (Match) ValidationLogic(using ReserveLogic for DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) ValidationLogic(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) ValidationLogic(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) ValidationLogic(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) function WadRayMath.rayMul(uint256,uint256)
✓ Document
✓ Code
# (Match) ValidationLogic(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) ValidationLogic(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) variable ValidationLogic.REBALANCE_UP_LIQUIDITY_RATE_THRESHOLD
✓ Document
✓ Code
# (Match) variable ValidationLogic.REBALANCE_UP_USAGE_RATIO_THRESHOLD
✓ Document
✓ Code
# (Match) function ValidationLogic.validateDeposit(struct DataTypes.ReserveData,uint256)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateWithdraw(address,uint256,uint256,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) struct ValidationLogic.ValidateBorrowLocalVars
✓ Document
✓ Code
# (Match) function ValidationLogic.validateBorrow(address,struct DataTypes.ReserveData,address,uint256,uint256,uint256,uint256,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateRepay(struct DataTypes.ReserveData,uint256,enum DataTypes.InterestRateMode,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateSwapRateMode(struct DataTypes.ReserveData,struct DataTypes.UserConfigurationMap,uint256,uint256,enum DataTypes.InterestRateMode)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateRebalanceStableBorrowRate(struct DataTypes.ReserveData,address,contract IERC20,contract IERC20,address)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateSetUseReserveAsCollateral(struct DataTypes.ReserveData,address,bool,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) function WadRayMath.rayDiv(uint256,uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.wadDiv(uint256,uint256)
✓ Document
✓ Code
# (Match) GenericLogic(using ReserveLogic for DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) function GenericLogic.calculateAvailableBorrowsETH(uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) GenericLogic(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) GenericLogic(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) GenericLogic(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) GenericLogic(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) GenericLogic(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) variable GenericLogic.HEALTH_FACTOR_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) struct GenericLogic.balanceDecreaseAllowedLocalVars
✓ Document
✓ Code
# (Match) function GenericLogic.balanceDecreaseAllowed(address,address,uint256,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) struct GenericLogic.CalculateUserAccountDataVars
✓ Document
✓ Code
# (Match) function GenericLogic.calculateUserAccountData(address,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) function GenericLogic.calculateHealthFactorFromBalances(uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) contract Helpers inherits
✓ Document
✓ Code
# (Match) function WadRayMath.wadMul(uint256,uint256)
✓ Document
✓ Code
# (Match) function Helpers.getUserCurrentDebt(address,struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) function Helpers.getUserCurrentDebtMemory(address,struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) contract WadRayMath inherits
✓ Document
✓ Code
# (Match) variable WadRayMath.WAD
✓ Document
✓ Code
# (Match) variable WadRayMath.halfWAD
✓ Document
✓ Code
# (Match) variable WadRayMath.RAY
✓ Document
✓ Code
# (Match) variable WadRayMath.halfRAY
✓ Document
✓ Code
# (Match) variable WadRayMath.WAD_RAY_RATIO
✓ Document
✓ Code
# (Match) function WadRayMath.ray()
✓ Document
✓ Code
# (Match) function WadRayMath.wad()
✓ Document
✓ Code
# (Match) function WadRayMath.halfRay()
✓ Document
✓ Code
# (Match) function WadRayMath.halfWad()
✓ Document
✓ Code
# (Match) function AdminUpgradeabilityProxy._willFallback()
✓ Document
✓ Code

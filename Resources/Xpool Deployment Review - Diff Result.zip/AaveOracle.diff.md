# (Added) AaveOracle(using SafeERC20 for IERC20)
```solidity
using SafeERC20 for IERC20;
```
# (Added) contract IERC20
```solidity
 @dev Interface of the ERC20 standard as defined in the EIP.
```
```solidity
interface IERC20
```
# (Added) function IChainlinkAggregator.latestTimestamp()
```solidity
function latestTimestamp() external view returns (uint256);
```
# (Added) function IChainlinkAggregator.latestRound()
```solidity
function latestRound() external view returns (uint256);
```
# (Added) function IChainlinkAggregator.getAnswer(uint256)
```solidity
function getAnswer(uint256 roundId) external view returns (int256);
```
# (Added) function IChainlinkAggregator.getTimestamp(uint256)
```solidity
function getTimestamp(uint256 roundId) external view returns (uint256);
```
# (Added) event IChainlinkAggregator.AnswerUpdated
```solidity
event AnswerUpdated(int256 indexed current, uint256 indexed roundId, uint256 timestamp);
```
# (Added) event IChainlinkAggregator.NewRound
```solidity
event NewRound(uint256 indexed roundId, address indexed startedBy);
```
# (Added) contract SafeERC20
```solidity
 @title SafeERC20
 @dev Wrappers around ERC20 operations that throw on failure (when the token
 contract returns false). Tokens that return no value (and instead revert or
 throw on failure) are also supported, non-reverting calls are assumed to be
 successful.
 To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
 which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
```
```solidity
library SafeERC20
```
# (Added) SafeERC20(using SafeMath for uint256)
```solidity
using SafeMath for uint256;
```
# (Added) SafeERC20(using Address for address)
```solidity
using Address for address;
```
# (Added) contract SafeMath
```solidity
 @dev Wrappers over Solidity's arithmetic operations with added overflow
 checks.
 Arithmetic operations in Solidity wrap on overflow. This can easily result
 in bugs, because programmers usually assume that an overflow raises an
 error, which is the standard behavior in high level programming languages.
 `SafeMath` restores this intuition by reverting the transaction when an
 operation overflows.
 Using this library instead of the unchecked operations eliminates an entire
 class of bugs, so it's recommended to use it always.
```
```solidity
library SafeMath
```
# (Added) contract Address
```solidity
 @dev Collection of functions related to the address type
```
```solidity
library Address
```
# (Changed) function Context._msgData()
✓ Document
✘ Code
```solidity
@@ -1,4 +1,4 @@
-function _msgData() internal virtual view returns (bytes memory) {
+function _msgData() internal view virtual returns (bytes memory) {
     this; // silence state mutability warning without generating bytecode - see https://github.com/ethereum/solidity/issues/2691
     return msg.data;
   }
```
# (Changed) function Context._msgSender()
✓ Document
✘ Code
```solidity
@@ -1,3 +1,3 @@
-function _msgSender() internal virtual view returns (address payable) {
+function _msgSender() internal view virtual returns (address payable) {
     return msg.sender;
   }
```
# (Changed) function AaveOracle.getAssetPrice(address)
✓ Document
✘ Code
```solidity
@@ -1,4 +1,4 @@
-function getAssetPrice(address asset) public override view returns (uint256) {
+function getAssetPrice(address asset) public view override returns (uint256) {
     IChainlinkAggregator source = assetsSources[asset];
 
     if (asset == WETH) {
```
# (Changed) function IPriceOracleGetter.getAssetPrice(address)
✘ Document
```solidity
@@ -1 +1,3 @@
-
+ @dev returns the asset price in ETH
+ @param asset the address of the asset
+ @return the ETH price of the asset*
```
✓ Code
# (Changed) contract IPriceOracleGetter inherits
✘ Document
```solidity
@@ -1 +1,2 @@
-
+ @title IPriceOracleGetter interface
+ @notice Interface for the Aave price oracle.*
```
✓ Code
# (Match) contract Context inherits
✓ Document
✓ Code
# (Match) function AaveOracle.<constructor>(address[],address[],address,address)
✓ Document
✓ Code
# (Match) variable AaveOracle._fallbackOracle
✓ Document
✓ Code
# (Match) variable AaveOracle.WETH
✓ Document
✓ Code
# (Match) function AaveOracle.setFallbackOracle(address)
✓ Document
✓ Code
# (Match) function AaveOracle.setAssetSources(address[],address[])
✓ Document
✓ Code
# (Match) event AaveOracle.FallbackOracleUpdated
✓ Document
✓ Code
# (Match) function AaveOracle._setAssetsSources(address[],address[])
✓ Document
✓ Code
# (Match) function AaveOracle._setFallbackOracle(address)
✓ Document
✓ Code
# (Match) function AaveOracle.getAssetsPrices(address[])
✓ Document
✓ Code
# (Match) function AaveOracle.getSourceOfAsset(address)
✓ Document
✓ Code
# (Match) variable AaveOracle.assetsSources
✓ Document
✓ Code
# (Match) contract AaveOracle inherits
✓ Document
✓ Code
# (Match) event AaveOracle.AssetSourceUpdated
✓ Document
✓ Code
# (Match) event AaveOracle.WethSet
✓ Document
✓ Code
# (Match) function IChainlinkAggregator.latestAnswer()
✓ Document
✓ Code
# (Match) contract IChainlinkAggregator inherits
✓ Document
✓ Code
# (Match) function Ownable.transferOwnership(address)
✓ Document
✓ Code
# (Match) function Ownable.renounceOwnership()
✓ Document
✓ Code
# (Match) modifier Ownable.onlyOwner
✓ Document
✓ Code
# (Match) function Ownable.owner()
✓ Document
✓ Code
# (Match) function Ownable.<constructor>()
✓ Document
✓ Code
# (Match) event Ownable.OwnershipTransferred
✓ Document
✓ Code
# (Match) variable Ownable._owner
✓ Document
✓ Code
# (Match) contract Ownable inherits
✓ Document
✓ Code
# (Match) function AaveOracle.getFallbackOracle()
✓ Document
✓ Code

# (Changed) function ValidationLogic.validateBorrow(address,struct DataTypes.ReserveData,address,uint256,uint256,uint256,uint256,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✘ Code
```solidity
@@ -71,7 +71,7 @@
      * 3. Users will be able to borrow only a portion of the total available liquidity
      **/
 
-    if (vars.rateMode == DataTypes.InterestRateMode.STABLE) {
+    if (interestRateMode == uint256(DataTypes.InterestRateMode.STABLE)) {
       //check if the borrow mode is stable and if stable rate borrowing is enabled on this reserve
 
       require(vars.stableRateBorrowingEnabled, Errors.VL_STABLE_BORROWING_NOT_ENABLED);
```
# (Changed) struct ValidationLogic.ValidateBorrowLocalVars
✓ Document
✘ Code
```solidity
@@ -1,18 +1,11 @@
 struct ValidateBorrowLocalVars {
-    uint256 principalBorrowBalance;
     uint256 currentLtv;
     uint256 currentLiquidationThreshold;
-    uint256 requestedBorrowAmountETH;
     uint256 amountOfCollateralNeededETH;
     uint256 userCollateralBalanceETH;
     uint256 userBorrowBalanceETH;
-    uint256 borrowBalanceIncrease;
-    uint256 currentReserveStableRate;
     uint256 availableLiquidity;
-    uint256 finalUserBorrowRate;
     uint256 healthFactor;
-    DataTypes.InterestRateMode rateMode;
-    bool healthFactorBelowThreshold;
     bool isActive;
     bool isFrozen;
     bool borrowingEnabled;
```
# (Match) contract LendingPoolCollateralManager inherits
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASH_LOAN_EXECUTOR_RETURN
✓ Document
✓ Code
# (Match) variable Errors.VL_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_RESERVE_FACTOR
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_DECIMALS
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_BONUS
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LIQ_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.RC_INVALID_LTV
✓ Document
✓ Code
# (Match) variable Errors.LP_IS_PAUSED
✓ Document
✓ Code
# (Match) variable Errors.LP_NO_MORE_RESERVES_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.UL_INVALID_INDEX
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_MUST_BE_AN_ATOKEN
✓ Document
✓ Code
# (Match) variable Errors.LP_REENTRANCY_NOT_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_EQUAL_ASSETS_TO_SWAP
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_COLLATERAL_SWAP
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_BURN_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.LP_FAILED_REPAY_WITH_COLLATERAL
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PARAMS_LENGTH
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_CONTRACT
✓ Document
✓ Code
# (Match) variable Errors.RL_STABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) MathUtils(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) variable WadRayMath.RAY
✓ Document
✓ Code
# (Match) variable WadRayMath.halfWAD
✓ Document
✓ Code
# (Match) variable WadRayMath.WAD
✓ Document
✓ Code
# (Match) contract WadRayMath inherits
✓ Document
✓ Code
# (Match) function MathUtils.calculateCompoundedInterest(uint256,uint40)
✓ Document
✓ Code
# (Match) function MathUtils.calculateCompoundedInterest(uint256,uint40,uint256)
✓ Document
✓ Code
# (Match) function MathUtils.calculateLinearInterest(uint256,uint40)
✓ Document
✓ Code
# (Match) variable MathUtils.SECONDS_PER_YEAR
✓ Document
✓ Code
# (Match) MathUtils(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) variable Errors.SDT_STABLE_DEBT_OVERFLOW
✓ Document
✓ Code
# (Match) contract MathUtils inherits
✓ Document
✓ Code
# (Match) enum DataTypes.InterestRateMode
✓ Document
✓ Code
# (Match) struct DataTypes.UserConfigurationMap
✓ Document
✓ Code
# (Match) struct DataTypes.ReserveConfigurationMap
✓ Document
✓ Code
# (Match) struct DataTypes.ReserveData
✓ Document
✓ Code
# (Match) contract DataTypes inherits
✓ Document
✓ Code
# (Match) enum Errors.CollateralManagerErrors
✓ Document
✓ Code
# (Match) variable Errors.SDT_BURN_EXCEEDS_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.CT_INVALID_MINT_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable WadRayMath.WAD_RAY_RATIO
✓ Document
✓ Code
# (Match) variable Errors.LP_INTEREST_RATE_REBALANCE_CONDITIONS_NOT_MET
✓ Document
✓ Code
# (Match) variable Errors.CT_CANNOT_GIVE_ALLOWANCE_TO_HIMSELF
✓ Document
✓ Code
# (Match) variable Errors.CT_CALLER_MUST_BE_LENDING_POOL
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_FLASHLOAN_PARAMS
✓ Document
✓ Code
# (Match) variable Errors.LP_CALLER_NOT_LENDING_POOL_CONFIGURATOR
✓ Document
✓ Code
# (Match) variable Errors.LP_INCONSISTENT_PROTOCOL_ACTUAL_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.LP_REQUESTED_AMOUNT_TOO_SMALL
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_LIQUIDITY_TO_BORROW
✓ Document
✓ Code
# (Match) variable Errors.LP_LIQUIDATION_CALL_FAILED
✓ Document
✓ Code
# (Match) variable Errors.LP_NOT_ENOUGH_STABLE_BORROW_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.RL_RESERVE_ALREADY_INITIALIZED
✓ Document
✓ Code
# (Match) variable Errors.VL_DEPOSIT_ALREADY_IN_USE
✓ Document
✓ Code
# (Match) variable Errors.VL_UNDERLYING_BALANCE_NOT_GREATER_THAN_0
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_VARIABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_STABLE_RATE_LOAN_IN_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_EXPLICIT_AMOUNT_TO_REPAY_ON_BEHALF
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_DEBT_OF_SELECTED_TYPE
✓ Document
✓ Code
# (Match) variable Errors.VL_AMOUNT_BIGGER_THAN_MAX_LOAN_SIZE_STABLE
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_SAME_AS_BORROWING_CURRENCY
✓ Document
✓ Code
# (Match) variable Errors.CT_TRANSFER_AMOUNT_NOT_GT_0
✓ Document
✓ Code
# (Match) variable Errors.LPC_RESERVE_LIQUIDITY_NOT_0
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_RATE_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.LPCM_SPECIFIED_CURRENCY_NOT_BORROWED_BY_USER
✓ Document
✓ Code
# (Match) variable Errors.RL_VARIABLE_BORROW_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.RL_LIQUIDITY_INDEX_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.MATH_DIVISION_BY_ZERO
✓ Document
✓ Code
# (Match) variable Errors.MATH_ADDITION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.MATH_MULTIPLICATION_OVERFLOW
✓ Document
✓ Code
# (Match) variable Errors.LP_INVALID_FLASHLOAN_MODE
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NO_ERRORS
✓ Document
✓ Code
# (Match) variable Errors.LPCM_NOT_ENOUGH_LIQUIDITY_TO_LIQUIDATE
✓ Document
✓ Code
# (Match) variable Errors.LPCM_COLLATERAL_CANNOT_BE_LIQUIDATED
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ATOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPCM_HEALTH_FACTOR_NOT_BELOW_THRESHOLD
✓ Document
✓ Code
# (Match) variable Errors.LPAPR_PROVIDER_NOT_REGISTERED
✓ Document
✓ Code
# (Match) variable Errors.LPC_CALLER_NOT_EMERGENCY_ADMIN
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_CONFIGURATION
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_ADDRESSES_PROVIDER_ID
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_UNDERLYING_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_VARIABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable Errors.LPC_INVALID_STABLE_DEBT_TOKEN_POOL_ADDRESS
✓ Document
✓ Code
# (Match) variable WadRayMath.halfRAY
✓ Document
✓ Code
# (Match) function WadRayMath.wad()
✓ Document
✓ Code
# (Match) function WadRayMath.ray()
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._paused
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolCollateralManagerUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolConfiguratorUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.EmergencyAdminUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ConfigurationAdminUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingPoolUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.MarketIdSet
✓ Document
✓ Code
# (Match) contract ILendingPoolAddressesProvider inherits
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._reservesCount
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.LendingRateOracleUpdated
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._reservesList
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._usersConfig
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._reserves
✓ Document
✓ Code
# (Match) variable LendingPoolStorage._addressesProvider
✓ Document
✓ Code
# (Match) LendingPoolStorage(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) LendingPoolStorage(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) LendingPoolStorage(using ReserveLogic for DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) contract LendingPoolStorage inherits
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.PriceOracleUpdated
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.ProxyCreated
✓ Document
✓ Code
# (Match) function ValidationLogic.validateLiquidationCall(struct DataTypes.ReserveData,struct DataTypes.ReserveData,struct DataTypes.UserConfigurationMap,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolCollateralManager()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingRateOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPriceOracle(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPriceOracle()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setEmergencyAdmin(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getEmergencyAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setPoolAdmin(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getPoolAdmin()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolCollateralManager(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolConfiguratorImpl(address)
✓ Document
✓ Code
# (Match) event ILendingPoolAddressesProvider.AddressSet
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPoolConfigurator()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingPoolImpl(address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getLendingPool()
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getAddress(bytes32)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddressAsProxy(bytes32,address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setAddress(bytes32,address)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setMarketId(string)
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.getMarketId()
✓ Document
✓ Code
# (Match) function ValidationLogic.validateTransfer(address,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateFlashloan(address[],uint256[])
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_CANNOT_COVER_NEW_BORROW
✓ Document
✓ Code
# (Match) variable PercentageMath.PERCENTAGE_FACTOR
✓ Document
✓ Code
# (Match) function UserConfiguration.isUsingAsCollateralOrBorrowing(struct DataTypes.UserConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function UserConfiguration.setUsingAsCollateral(struct DataTypes.UserConfigurationMap,uint256,bool)
✓ Document
✓ Code
# (Match) function UserConfiguration.setBorrowing(struct DataTypes.UserConfigurationMap,uint256,bool)
✓ Document
✓ Code
# (Match) variable UserConfiguration.BORROWING_MASK
✓ Document
✓ Code
# (Match) contract UserConfiguration inherits
✓ Document
✓ Code
# (Match) function PercentageMath.percentDiv(uint256,uint256)
✓ Document
✓ Code
# (Match) function PercentageMath.percentMul(uint256,uint256)
✓ Document
✓ Code
# (Match) variable PercentageMath.HALF_PERCENT
✓ Document
✓ Code
# (Match) contract PercentageMath inherits
✓ Document
✓ Code
# (Match) function UserConfiguration.isUsingAsCollateral(struct DataTypes.UserConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.wadToRay(uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.rayToWad(uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.rayDiv(uint256,uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.rayMul(uint256,uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.wadDiv(uint256,uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.wadMul(uint256,uint256)
✓ Document
✓ Code
# (Match) function WadRayMath.halfWad()
✓ Document
✓ Code
# (Match) function WadRayMath.halfRay()
✓ Document
✓ Code
# (Match) function UserConfiguration.isBorrowing(struct DataTypes.UserConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function UserConfiguration.isBorrowingAny(struct DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateSetUseReserveAsCollateral(struct DataTypes.ReserveData,address,bool,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) ValidationLogic(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateRebalanceStableBorrowRate(struct DataTypes.ReserveData,address,contract IERC20,contract IERC20,address)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateSwapRateMode(struct DataTypes.ReserveData,struct DataTypes.UserConfigurationMap,uint256,uint256,enum DataTypes.InterestRateMode)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateRepay(struct DataTypes.ReserveData,uint256,enum DataTypes.InterestRateMode,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateWithdraw(address,uint256,uint256,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) function ValidationLogic.validateDeposit(struct DataTypes.ReserveData,uint256)
✓ Document
✓ Code
# (Match) variable ValidationLogic.REBALANCE_UP_USAGE_RATIO_THRESHOLD
✓ Document
✓ Code
# (Match) variable ValidationLogic.REBALANCE_UP_LIQUIDITY_RATE_THRESHOLD
✓ Document
✓ Code
# (Match) ValidationLogic(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) ValidationLogic(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) function UserConfiguration.isEmpty(struct DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) ValidationLogic(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) ValidationLogic(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) ValidationLogic(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) ValidationLogic(using ReserveLogic for DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) contract ValidationLogic inherits
✓ Document
✓ Code
# (Match) function Helpers.getUserCurrentDebtMemory(address,struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) function Helpers.getUserCurrentDebt(address,struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) contract Helpers inherits
✓ Document
✓ Code
# (Match) variable Errors.VL_STABLE_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) variable Errors.VL_HEALTH_FACTOR_LOWER_THAN_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) LendingPoolCollateralManager(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) event IVariableDebtToken.Mint
✓ Document
✓ Code
# (Match) event ILendingPoolCollateralManager.ReserveUsedAsCollateralDisabled
✓ Document
✓ Code
# (Match) event ILendingPoolCollateralManager.LiquidationCall
✓ Document
✓ Code
# (Match) contract ILendingPoolCollateralManager inherits
✓ Document
✓ Code
# (Match) function IPriceOracleGetter.getAssetPrice(address)
✓ Document
✓ Code
# (Match) contract IPriceOracleGetter inherits
✓ Document
✓ Code
# (Match) function IVariableDebtToken.burn(address,uint256,uint256)
✓ Document
✓ Code
# (Match) event IVariableDebtToken.Burn
✓ Document
✓ Code
# (Match) function IVariableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) contract IVariableDebtToken inherits
✓ Document
✓ Code
# (Match) function ILendingPoolCollateralManager.liquidationCall(address,address,address,uint256,bool)
✓ Document
✓ Code
# (Match) function IStableDebtToken.principalBalanceOf(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getTotalSupplyAndAvgRate()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getTotalSupplyLastUpdated()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getSupplyData()
✓ Document
✓ Code
# (Match) function IStableDebtToken.getUserLastUpdated(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getUserStableRate(address)
✓ Document
✓ Code
# (Match) function IStableDebtToken.getAverageStableRate()
✓ Document
✓ Code
# (Match) function IStableDebtToken.burn(address,uint256)
✓ Document
✓ Code
# (Match) event ILendingPoolCollateralManager.ReserveUsedAsCollateralEnabled
✓ Document
✓ Code
# (Match) contract VersionedInitializable inherits
✓ Document
✓ Code
# (Match) event IStableDebtToken.Burn
✓ Document
✓ Code
# (Match) GenericLogic(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) function GenericLogic.calculateHealthFactorFromBalances(uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function GenericLogic.calculateUserAccountData(address,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) struct GenericLogic.CalculateUserAccountDataVars
✓ Document
✓ Code
# (Match) function GenericLogic.balanceDecreaseAllowed(address,address,uint256,mapping(address => struct DataTypes.ReserveData),struct DataTypes.UserConfigurationMap,mapping(uint256 => address),uint256,address)
✓ Document
✓ Code
# (Match) struct GenericLogic.balanceDecreaseAllowedLocalVars
✓ Document
✓ Code
# (Match) variable GenericLogic.HEALTH_FACTOR_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) GenericLogic(using UserConfiguration for DataTypes.UserConfigurationMap)
✓ Document
✓ Code
# (Match) GenericLogic(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) GenericLogic(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) variable VersionedInitializable.lastInitializedRevision
✓ Document
✓ Code
# (Match) GenericLogic(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) GenericLogic(using ReserveLogic for DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) contract GenericLogic inherits
✓ Document
✓ Code
# (Match) variable VersionedInitializable.______gap
✓ Document
✓ Code
# (Match) function VersionedInitializable.isConstructor()
✓ Document
✓ Code
# (Match) function VersionedInitializable.getRevision()
✓ Document
✓ Code
# (Match) modifier VersionedInitializable.initializer
✓ Document
✓ Code
# (Match) variable VersionedInitializable.initializing
✓ Document
✓ Code
# (Match) function IStableDebtToken.mint(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) event IStableDebtToken.Mint
✓ Document
✓ Code
# (Match) contract ReserveLogic inherits
✓ Document
✓ Code
# (Match) contract SafeMath inherits
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.mod(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.div(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.mul(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256,string)
✓ Document
✓ Code
# (Match) function SafeMath.sub(uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeMath.add(uint256,uint256)
✓ Document
✓ Code
# (Match) function LendingPoolCollateralManager._calculateAvailableCollateralToLiquidate(struct DataTypes.ReserveData,struct DataTypes.ReserveData,address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) function IERC20.totalSupply()
✓ Document
✓ Code
# (Match) struct LendingPoolCollateralManager.AvailableCollateralToLiquidateLocalVars
✓ Document
✓ Code
# (Match) function LendingPoolCollateralManager.liquidationCall(address,address,address,uint256,bool)
✓ Document
✓ Code
# (Match) function LendingPoolCollateralManager.getRevision()
✓ Document
✓ Code
# (Match) struct LendingPoolCollateralManager.LiquidationCallLocalVars
✓ Document
✓ Code
# (Match) variable LendingPoolCollateralManager.LIQUIDATION_CLOSE_FACTOR_PERCENT
✓ Document
✓ Code
# (Match) LendingPoolCollateralManager(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) LendingPoolCollateralManager(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) LendingPoolCollateralManager(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) contract IERC20 inherits
✓ Document
✓ Code
# (Match) function IERC20.balanceOf(address)
✓ Document
✓ Code
# (Match) contract IStableDebtToken inherits
✓ Document
✓ Code
# (Match) event IAToken.BalanceTransfer
✓ Document
✓ Code
# (Match) function IScaledBalanceToken.scaledTotalSupply()
✓ Document
✓ Code
# (Match) function IScaledBalanceToken.getScaledUserBalanceAndSupply(address)
✓ Document
✓ Code
# (Match) function IScaledBalanceToken.scaledBalanceOf(address)
✓ Document
✓ Code
# (Match) contract IScaledBalanceToken inherits
✓ Document
✓ Code
# (Match) function IAToken.transferUnderlyingTo(address,uint256)
✓ Document
✓ Code
# (Match) function IAToken.transferOnLiquidation(address,address,uint256)
✓ Document
✓ Code
# (Match) function IAToken.mintToTreasury(uint256,uint256)
✓ Document
✓ Code
# (Match) function IAToken.burn(address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) event IAToken.Burn
✓ Document
✓ Code
# (Match) function IERC20.transfer(address,uint256)
✓ Document
✓ Code
# (Match) function IAToken.mint(address,uint256,uint256)
✓ Document
✓ Code
# (Match) event IAToken.Mint
✓ Document
✓ Code
# (Match) contract IAToken inherits
✓ Document
✓ Code
# (Match) event IERC20.Approval
✓ Document
✓ Code
# (Match) event IERC20.Transfer
✓ Document
✓ Code
# (Match) function IERC20.transferFrom(address,address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.approve(address,uint256)
✓ Document
✓ Code
# (Match) function IERC20.allowance(address,address)
✓ Document
✓ Code
# (Match) function GenericLogic.calculateAvailableBorrowsETH(uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) ReserveLogic(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) variable Errors.VL_COLLATERAL_BALANCE_IS_0
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setLiquidationThreshold(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setFrozen(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getActive(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setActive(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getDecimals(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setDecimals(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getLiquidationBonus(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setLiquidationBonus(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getLiquidationThreshold(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getLtv(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setBorrowingEnabled(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setLtv(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_RESERVE_FACTOR
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_DECIMALS
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_LIQUIDATION_BONUS
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_LIQUIDATION_THRESHOLD
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.MAX_VALID_LTV
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.RESERVE_FACTOR_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.STABLE_BORROWING_ENABLED_START_BIT_POSITION
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getFrozen(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getBorrowingEnabled(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.IS_FROZEN_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable Errors.BORROW_ALLOWANCE_NOT_ENOUGH
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_INTEREST_RATE_MODE_SELECTED
✓ Document
✓ Code
# (Match) variable Errors.VL_BORROWING_NOT_ENABLED
✓ Document
✓ Code
# (Match) variable Errors.VL_TRANSFER_NOT_ALLOWED
✓ Document
✓ Code
# (Match) variable Errors.VL_NOT_ENOUGH_AVAILABLE_USER_BALANCE
✓ Document
✓ Code
# (Match) variable Errors.VL_CURRENT_AVAILABLE_LIQUIDITY_NOT_ENOUGH
✓ Document
✓ Code
# (Match) variable Errors.VL_RESERVE_FROZEN
✓ Document
✓ Code
# (Match) variable Errors.VL_NO_ACTIVE_RESERVE
✓ Document
✓ Code
# (Match) variable Errors.VL_INVALID_AMOUNT
✓ Document
✓ Code
# (Match) variable Errors.CALLER_NOT_POOL_ADMIN
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setStableRateBorrowingEnabled(struct DataTypes.ReserveConfigurationMap,bool)
✓ Document
✓ Code
# (Match) contract Errors inherits
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getFlagsMemory(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getParamsMemory(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getParams(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getFlags(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getReserveFactor(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.setReserveFactor(struct DataTypes.ReserveConfigurationMap,uint256)
✓ Document
✓ Code
# (Match) function ReserveConfiguration.getStableRateBorrowingEnabled(struct DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.BORROWING_ENABLED_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.IS_ACTIVE_START_BIT_POSITION
✓ Document
✓ Code
# (Match) ReserveLogic(using WadRayMath for uint256)
✓ Document
✓ Code
# (Match) function ReserveLogic.init(struct DataTypes.ReserveData,address,address,address,address)
✓ Document
✓ Code
# (Match) SafeERC20(using Address for address)
✓ Document
✓ Code
# (Match) SafeERC20(using SafeMath for uint256)
✓ Document
✓ Code
# (Match) contract SafeERC20 inherits
✓ Document
✓ Code
# (Match) function ReserveLogic._updateIndexes(struct DataTypes.ReserveData,uint256,uint256,uint256,uint40)
✓ Document
✓ Code
# (Match) function ReserveLogic._mintToTreasury(struct DataTypes.ReserveData,uint256,uint256,uint256,uint256,uint40)
✓ Document
✓ Code
# (Match) struct ReserveLogic.MintToTreasuryLocalVars
✓ Document
✓ Code
# (Match) function ReserveLogic.updateInterestRates(struct DataTypes.ReserveData,address,address,uint256,uint256)
✓ Document
✓ Code
# (Match) struct ReserveLogic.UpdateInterestRatesLocalVars
✓ Document
✓ Code
# (Match) function ReserveLogic.cumulateToLiquidityIndex(struct DataTypes.ReserveData,uint256,uint256)
✓ Document
✓ Code
# (Match) function SafeERC20.safeTransferFrom(contract IERC20,address,address,uint256)
✓ Document
✓ Code
# (Match) function ReserveLogic.updateState(struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) function ReserveLogic.getNormalizedDebt(struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) function ReserveLogic.getNormalizedIncome(struct DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) ReserveLogic(using ReserveConfiguration for DataTypes.ReserveConfigurationMap)
✓ Document
✓ Code
# (Match) ReserveLogic(using ReserveLogic for DataTypes.ReserveData)
✓ Document
✓ Code
# (Match) event ReserveLogic.ReserveDataUpdated
✓ Document
✓ Code
# (Match) ReserveLogic(using SafeERC20 for IERC20)
✓ Document
✓ Code
# (Match) ReserveLogic(using PercentageMath for uint256)
✓ Document
✓ Code
# (Match) function SafeERC20.safeTransfer(contract IERC20,address,uint256)
✓ Document
✓ Code
# (Match) function SafeERC20.safeApprove(contract IERC20,address,uint256)
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.RESERVE_DECIMALS_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_BONUS_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_BONUS_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_THRESHOLD_START_BIT_POSITION
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.RESERVE_FACTOR_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.STABLE_BORROWING_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.BORROWING_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.FROZEN_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.ACTIVE_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.DECIMALS_MASK
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LIQUIDATION_THRESHOLD_MASK
✓ Document
✓ Code
# (Match) function SafeERC20.callOptionalReturn(contract IERC20,bytes)
✓ Document
✓ Code
# (Match) variable ReserveConfiguration.LTV_MASK
✓ Document
✓ Code
# (Match) contract ReserveConfiguration inherits
✓ Document
✓ Code
# (Match) function IReserveInterestRateStrategy.calculateInterestRates(address,uint256,uint256,uint256,uint256,uint256)
✓ Document
✓ Code
# (Match) function IReserveInterestRateStrategy.getMaxVariableBorrowRate()
✓ Document
✓ Code
# (Match) function IReserveInterestRateStrategy.baseVariableBorrowRate()
✓ Document
✓ Code
# (Match) contract IReserveInterestRateStrategy inherits
✓ Document
✓ Code
# (Match) function Address.sendValue(address payable,uint256)
✓ Document
✓ Code
# (Match) function Address.isContract(address)
✓ Document
✓ Code
# (Match) contract Address inherits
✓ Document
✓ Code
# (Match) function ILendingPoolAddressesProvider.setLendingRateOracle(address)
✓ Document
✓ Code
